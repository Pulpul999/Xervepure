package com.app.xervepure.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.app.xervepure.R;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.utils.FontUtils;

public class ContsctUsFragment extends BaseFragment {

    private String postUrl = "https://www.xervepure.com/app/contactus.php";
    private WebView webView;
    private ProgressBar progressBar;


    public ContsctUsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return view = inflater.inflate(R.layout.fragment_about_us, container, false);
    }

    @Override
    public void alertOkClicked() {

    }

    @Override
    protected void initViews() {
        webView = (WebView) view.findViewById(R.id.webView);
        progressBar = (ProgressBar) view.findViewById(R.id.progressBar);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl(postUrl);
        webView.setHorizontalScrollBarEnabled(false);
    }

    @Override
    protected void initContext() {
        context = getActivity();
        currentActivity = getActivity();
    }

    @Override
    protected void initListners() {

    }

    @Override
    public void onClick(View v) {

    }
}
