package com.app.xervepure.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Codeslay-03 on 10/11/2017.
 */

public class WalletHistoryModel implements Parcelable {

    private int id;
    @SerializedName("transaction_id")
    private String transactionId;
    @SerializedName("transaction_type")
    private String transactionType;
    @SerializedName("type")
    private String transactionTypeDescription;
    @SerializedName("reference_id")
    private String referenceId;
    private String amount;
    @SerializedName("payment_method")
    private String paymentMethod;
    @SerializedName("payment_method_description")
    private String paymentMethodDescription;
    @SerializedName("order_type")
    private String orderType;
    @SerializedName("description")
    private String orderTypeDescription;
    private String status;
    @SerializedName("doe")
    private String creationTimestamp;

    protected WalletHistoryModel(Parcel in) {
        id = in.readInt();
        transactionId = in.readString();
        transactionType = in.readString();
        transactionTypeDescription = in.readString();
        referenceId = in.readString();
        amount = in.readString();
        paymentMethod = in.readString();
        paymentMethodDescription = in.readString();
        orderType = in.readString();
        orderTypeDescription = in.readString();
        status = in.readString();
        creationTimestamp = in.readString();
    }

    public static final Creator<WalletHistoryModel> CREATOR = new Creator<WalletHistoryModel>() {
        @Override
        public WalletHistoryModel createFromParcel(Parcel in) {
            return new WalletHistoryModel(in);
        }

        @Override
        public WalletHistoryModel[] newArray(int size) {
            return new WalletHistoryModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(transactionId);
        dest.writeString(transactionType);
        dest.writeString(transactionTypeDescription);
        dest.writeString(referenceId);
        dest.writeString(amount);
        dest.writeString(paymentMethod);
        dest.writeString(paymentMethodDescription);
        dest.writeString(orderType);
        dest.writeString(orderTypeDescription);
        dest.writeString(status);
        dest.writeString(creationTimestamp);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getTransactionTypeDescription() {
        return transactionTypeDescription;
    }

    public void setTransactionTypeDescription(String transactionTypeDescription) {
        this.transactionTypeDescription = transactionTypeDescription;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getPaymentMethodDescription() {
        return paymentMethodDescription;
    }

    public void setPaymentMethodDescription(String paymentMethodDescription) {
        this.paymentMethodDescription = paymentMethodDescription;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getOrderTypeDescription() {
        return orderTypeDescription;
    }

    public void setOrderTypeDescription(String orderTypeDescription) {
        this.orderTypeDescription = orderTypeDescription;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreationTimestamp() {
        return creationTimestamp;
    }

    public void setCreationTimestamp(String creationTimestamp) {
        this.creationTimestamp = creationTimestamp;
    }
}
