package com.app.xervepure.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;
import com.app.xervepure.R;
import com.app.xervepure.application.VyaanApplication;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.model.AddressModel;
import com.app.xervepure.model.CityModel;
import com.app.xervepure.model.LocalityModel;
import com.app.xervepure.model.UpdateAddressModel;
import com.app.xervepure.utils.DeviceUtils;
import com.app.xervepure.utils.FontUtils;
import com.app.xervepure.utils.SharedPreferenceUtils;
import com.app.xervepure.utils.Validator;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class EditAddressActivity extends BaseActivity {

    private LinearLayout titleHomeLL;
    private LinearLayout titleWorkLL;
    private ImageView titleHomeIV;
    private ImageView titleWorkIV;
    private TextView titleHomeTV;
    private TextView titleWorkTV;

    private EditText editName;
    private EditText editAddressLine1;
    private EditText editAddressLine2;
    private EditText editCity;
    private EditText editLocaliy;

    private EditText editLandmark;
    private EditText editPhoneNo;
    private EditText editPinCode;

    private Button btnAddAddress;

    private CityModel cityModel;
    private LocalityModel localityModel;

    private String addressTitle;
    private AddressModel addressModel;

    private int cityId;
    private int localityId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_address);
    }

    @Override
    protected void initViews() {

        addressModel = getIntent().getParcelableExtra(ADDRESS_MODEL);

        titleHomeLL = (LinearLayout) findViewById(R.id.titleHomeLL);
        titleWorkLL = (LinearLayout) findViewById(R.id.titleWorkLL);
        titleHomeIV = (ImageView) findViewById(R.id.titleHomeIV);
        titleWorkIV = (ImageView) findViewById(R.id.titleWorkIV);
        titleHomeTV = (TextView) findViewById(R.id.titleHomeTV);
        titleWorkTV = (TextView) findViewById(R.id.titleWorkTV);

        cityId = addressModel.getCityId();
        localityId = addressModel.getLocalityId();

        editName = (EditText) findViewById(R.id.editName);
        editAddressLine1 = (EditText) findViewById(R.id.editAddressLine1);
        editAddressLine2 = (EditText) findViewById(R.id.editAddressLine2);

        editCity = (EditText) findViewById(R.id.editCity);
        editLocaliy = (EditText) findViewById(R.id.editLocaliy);

        editLandmark = (EditText) findViewById(R.id.editLandmark);
        editPhoneNo = (EditText) findViewById(R.id.editPhoneNo);
        btnAddAddress = (Button) findViewById(R.id.btnAddAddress);
        editPinCode = (EditText) findViewById(R.id.editPinCode);

        editName.setText(addressModel.getName());
        editAddressLine1.setText(addressModel.getAddressLine1());
        editAddressLine2.setText(addressModel.getAddressLine2());
        editCity.setText(addressModel.getCityName());
        editLocaliy.setText(addressModel.getLocalityName());
        editLandmark.setText(addressModel.getLandmark());
        editPhoneNo.setText("" + addressModel.getPhoneNumber());
        editPinCode.setText("" + addressModel.getPincode());
        addressTitle = addressModel.getAddressTitle();
        if (!TextUtils.isEmpty(addressTitle) && addressTitle.equalsIgnoreCase(getString(R.string.titleWork))) {
            titleHomeIV.setImageResource(R.drawable.radio_unselected_btn);
            titleWorkIV.setImageResource(R.drawable.radio_selected_btn);
            addressTitle = titleWorkTV.getText().toString();
        } else {
            titleHomeIV.setImageResource(R.drawable.radio_selected_btn);
            titleWorkIV.setImageResource(R.drawable.radio_unselected_btn);
            addressTitle = titleHomeTV.getText().toString();
        }
        getSupportActionBar().setTitle(R.string.title_edit_address);

        FontUtils.changeFont(currentActivity, titleHomeTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, titleWorkTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, editName, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, editAddressLine1, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, editAddressLine2, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, editCity, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, editLocaliy, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, editLandmark, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, editPhoneNo, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, editLandmark, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, editPhoneNo, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, editPinCode, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, btnAddAddress, AppConstants.FONT_ROBOTO_MEDIUM);
    }

    @Override
    protected void initContext() {
        currentActivity = EditAddressActivity.this;
        context = EditAddressActivity.this;
    }

    @Override
    protected void initListners() {
        titleHomeLL.setOnClickListener(this);
        titleWorkLL.setOnClickListener(this);
        btnAddAddress.setOnClickListener(this);
        editCity.setOnClickListener(this);
        editLocaliy.setOnClickListener(this);
    }

    @Override
    protected boolean isActionBar() {
        return true;
    }

    @Override
    protected boolean isHomeButton() {
        return true;
    }

    @Override
    public void onAlertClicked(int alertType) {

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.titleHomeLL: {
                titleHomeIV.setImageResource(R.drawable.radio_selected_btn);
                titleWorkIV.setImageResource(R.drawable.radio_unselected_btn);
                addressTitle = titleHomeTV.getText().toString();
                break;
            }
            case R.id.titleWorkLL: {
                titleHomeIV.setImageResource(R.drawable.radio_unselected_btn);
                titleWorkIV.setImageResource(R.drawable.radio_selected_btn);
                addressTitle = titleWorkTV.getText().toString();
                break;
            }
            case R.id.btnAddAddress: {

                if (Validator.isNetworkAvailable(currentActivity)) {
                    if (isMandatoryFields()) {
                        editAddress();
                    }
                } else {
                    alert(currentActivity, getString(R.string.alert_message_no_network), getString(R.string.alert_message_no_network), getString(R.string.labelOk), getString(R.string.labelCancel), false, false, ALERT_TYPE_NO_NETWORK);
                }

                break;
            }
            case R.id.editCity: {
                startActivity(currentActivity, SelectCityActivity.class, bundle, true, REQUEST_TAG_CITY_ACTIVITY, true, ANIMATION_SLIDE_LEFT);
                break;
            }
            case R.id.editLocaliy: {
                if (cityModel == null) {
                    toast(getResources().getString(R.string.error_select_city), true);
                } else {
                    if (bundle == null) {
                        bundle = new Bundle();
                    }
                    bundle.putParcelable(CITY_MODEL, cityModel);
                    startActivity(currentActivity, SelectLocalityActivity.class, bundle, true, REQUEST_TAG_LOCALITY_ACTIVITY, true, ANIMATION_SLIDE_LEFT);
                }
                break;
            }
        }
    }


    private boolean isMandatoryFields() {

        editName.setError(null);
        editAddressLine1.setError(null);
        editAddressLine2.setError(null);

        editCity.setError(null);
        editLocaliy.setError(null);

        editLandmark.setError(null);
        editPhoneNo.setError(null);

        if (editName.getText().toString().isEmpty()) {
            editName.setError(getResources().getString(R.string.error_enter_name));
            editName.requestFocus();
            return false;
        } else if (editAddressLine1.getText().toString().isEmpty()) {
            editAddressLine1.setError(getResources().getString(R.string.error_address));
            editAddressLine1.requestFocus();
            return false;
        } else if (editCity.getText().toString().isEmpty()) {
            editCity.setError(getResources().getString(R.string.error_city));
            editCity.requestFocus();
            return false;
        } else if (editLocaliy.getText().toString().isEmpty()) {
            editLocaliy.setError(getResources().getString(R.string.error_locality));
            editLocaliy.requestFocus();
            return false;
        } else if (editPinCode.getText().toString().isEmpty()) {
            editPinCode.setError(getResources().getString(R.string.error_pincode));
            editPinCode.requestFocus();
            return false;
        } else if (editPhoneNo.getText().toString().isEmpty()) {
            editPhoneNo.setError(getResources().getString(R.string.error_alternate_contact));
            editPhoneNo.requestFocus();
            return false;
        } else if (!editPhoneNo.getText().toString().isEmpty()) {
            String email = editPhoneNo.getText().toString();
            if (email.matches("[0-9]+") && email.length() > 2) {
                // phone number
                if (!Validator.getInstance().validateNumber(context, editPhoneNo.getText().toString()).equals("")) {
                    String numberError = Validator.getInstance().validateNumber(context, editPhoneNo.getText().toString());
                    editPhoneNo.setError(numberError);
                    editPhoneNo.requestFocus();
                    return false;
                }
            } else {
                // email id
                if (!Validator.getInstance().isValidEmail(context, editPhoneNo.getText().toString()).equals("")) {
                    String emailError = Validator.getInstance().isValidEmail(context, editPhoneNo.getText().toString());
                    editPhoneNo.setError(emailError);
                    editPhoneNo.requestFocus();
                    return false;
                }
            }
        }
        return true;

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case REQUEST_TAG_CITY_ACTIVITY: {
                    cityModel = data.getParcelableExtra(CITY_MODEL);
                    cityId = cityModel.getId();
                    editCity.setText(cityModel.getName());
                    localityModel = null;
                    editLocaliy.setText("");
                    break;
                }

                case REQUEST_TAG_LOCALITY_ACTIVITY: {
                    localityModel = data.getParcelableExtra(LOCALITY_MODEL);
                    editLocaliy.setText(localityModel.getName());
                    localityId = localityModel.getId();
                    break;
                }
            }
        }
    }


    private UpdateAddressModel initUpdateAddressModel() {
        if (addressModel == null) return null;
        UpdateAddressModel updateAddressModel = new UpdateAddressModel();

        updateAddressModel.setDeviceType(DEVICE_TYPE);
        updateAddressModel.setLoginId(SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_MOBILE_NO));
        updateAddressModel.setAccessToken(DeviceUtils.getDeviceKey());
        updateAddressModel.setIpAddress(DeviceUtils.getDeviceIpAddress(context));

        updateAddressModel.setAddressTitle(addressTitle);
        updateAddressModel.setUserId(SharedPreferenceUtils.getInstance(currentActivity).getInteger(AppConstants.USER_ID));
        updateAddressModel.setName(editName.getText().toString());
        updateAddressModel.setAddressLine1(editAddressLine1.getText().toString());
        updateAddressModel.setAddressLine2(editAddressLine2.getText().toString());
        updateAddressModel.setCityID(cityId);
        updateAddressModel.setLocalityID(localityId);
        updateAddressModel.setLandmark(editLandmark.getText().toString());
        updateAddressModel.setPhoneNumber(editPhoneNo.getText().toString());
        updateAddressModel.setAddressId(Integer.parseInt(addressModel.getId()));
        updateAddressModel.setPincode(editPinCode.getText().toString());

        return updateAddressModel;
    }


    public void editAddress() {

        String json = new Gson().toJson(initUpdateAddressModel());
        logTesting("editaddressrequestjson", json, Log.ERROR);
        JSONObject jsons = null;
        try {
            jsons = new JSONObject(json);
            new Gson().toJson(json);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_UPDATE_ADDRESS, jsons, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                logTesting("responce is", response.toString(), Log.ERROR);

                try {
                    logTesting("is successfull update address", "hi" + response.getBoolean(AppConstants.KEY_ERROR), Log.ERROR);
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                        setResult(RESULT_OK);
                        finish();
                    } else {
                        cancelProgressDialog();
                        logTesting("update address error", "true", Log.ERROR);
                    }

                } catch (JSONException e) {
                    logTesting("update address json exeption is", e.toString(), Log.ERROR);
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                logTesting("error is", error.toString(), Log.ERROR);
                toast(getResources().getString(R.string.errorUpdateAddress), true);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Accept", "application/json");
                params.put("Content-Type", "application/json");
                params.put("type", "M");

                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }


}
