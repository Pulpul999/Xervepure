package com.app.xervepure.activity;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.app.xervepure.R;
import com.app.xervepure.application.VyaanApplication;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.model.LoginOrSignUpModel;
import com.app.xervepure.model.ProfileDetailsModel;
import com.app.xervepure.network.BaseVolleyRequest;
import com.app.xervepure.utils.DeviceUtils;
import com.app.xervepure.utils.FontUtils;
import com.app.xervepure.utils.Helper;
import com.app.xervepure.utils.SharedPreferenceUtils;
import com.app.xervepure.utils.Validator;
import com.app.xervepure.widgets.CircularImageView;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

public class ProfileActivity extends BaseActivity {

    private EditText editName;
    private EditText editEmail;
    private EditText editPhone;
    private EditText editExtRefCode;
    private Button submitButton;
    private Button applyButton;
    private CircularImageView circularProfileImage;

    private int bytesAvailable;
    private int bytesRead;
    private String mimeType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
    }

    @Override
    protected void initViews() {
        settingTitle(getString(R.string.title_profile));
        editName = (EditText) findViewById(R.id.editName);
        editEmail = (EditText) findViewById(R.id.editEmail);
        editPhone = (EditText) findViewById(R.id.editContactNo);
        editExtRefCode = findViewById(R.id.editExtRefCode);
        applyButton = findViewById(R.id.applyButton);
        submitButton = (Button) findViewById(R.id.submitButton);
        circularProfileImage = (CircularImageView) findViewById(R.id.circularProfileImage);

        FontUtils.changeFont(context, editName, FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(context, editEmail, FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(context, editPhone, FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(context, editExtRefCode, FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(context, submitButton, FONT_ROBOTO_MEDIUM);
        toSetProfileDetails();
        getProfileDetail();
    }

    @Override
    protected void initContext() {
        context = ProfileActivity.this;
        currentActivity = ProfileActivity.this;
    }

    @Override
    protected void initListners() {
        submitButton.setOnClickListener(this);
        circularProfileImage.setOnClickListener(this);
        applyButton.setOnClickListener(this);
    }

    @Override
    protected boolean isActionBar() {
        return true;
    }

    @Override
    protected boolean isHomeButton() {
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.submitButton: {
                toHideKeyboard();
                if (Validator.isNetworkAvailable(currentActivity)) {
                    if (isMandatoryFields()) {
                        updateProfile();
                    }
                } else {
                    alert(currentActivity, getResources().getString(R.string.alert_message_no_network), getResources().getString(R.string.alert_message_no_network), getResources().getString(R.string.alert_ok_button_text_no_network), getResources().getString(R.string.alert_cancel_button_text_no_network), false, false, ALERT_TYPE_NO_NETWORK);
                }
                break;
            }
            case R.id.applyButton: {
                toHideKeyboard();
                if (Validator.isNetworkAvailable(currentActivity)) {
                    if (validateExtRefCode()) {
                        applyReferralCode();
                    }
                } else {
                    alert(currentActivity, getResources().getString(R.string.alert_message_no_network), getResources().getString(R.string.alert_message_no_network), getResources().getString(R.string.alert_ok_button_text_no_network), getResources().getString(R.string.alert_cancel_button_text_no_network), false, false, ALERT_TYPE_NO_NETWORK);
                }
                break;
            }
        }
    }

    @Override
    public void onAlertClicked(int alertType) {

    }

    private void toSetProfileDetails() {

        String extRefCode = SharedPreferenceUtils.getInstance(context).getString(USER_EXISTING_REF_CODE);
        if(!TextUtils.isEmpty(extRefCode)){
            applyButton.setVisibility(View.GONE);
            editExtRefCode.setEnabled(false);
            editExtRefCode.setFocusable(false);
        }else {
            applyButton.setVisibility(View.VISIBLE);
            editExtRefCode.setEnabled(true);
            editExtRefCode.setFocusable(true);
        }
        editName.setText(SharedPreferenceUtils.getInstance(context).getString(USER_NAME));
        editEmail.setText(SharedPreferenceUtils.getInstance(context).getString(USER_EMAIL));
        editPhone.setText(SharedPreferenceUtils.getInstance(context).getString(USER_MOBILE_NO));
        editExtRefCode.setText(extRefCode);
        String userImage = SharedPreferenceUtils.getInstance(context).getString(USER_PROFILE_IMAGE);
        if (!TextUtils.isEmpty(userImage)) {
            String imageUrl = BASE_URL_IMAGES + "/" + userImage;
            Picasso.with(currentActivity).load(imageUrl).placeholder(R.drawable.iconprofile).error(R.drawable.iconprofile).into(circularProfileImage);
            ProfileDetailsModel.getInstance().setUserImageName(userImage);
        }

    }

    private void initSignUpModel() {
        LoginOrSignUpModel.getInstance().setDeviceType(DEVICE_TYPE);
        LoginOrSignUpModel.getInstance().setLoginId(SharedPreferenceUtils.getInstance(context).getString(USER_MOBILE_NO));
        LoginOrSignUpModel.getInstance().setAccessToken(DeviceUtils.getDeviceKey());
        LoginOrSignUpModel.getInstance().setIpAddress(DeviceUtils.getDeviceIpAddress(context));
        LoginOrSignUpModel.getInstance().setPhone(SharedPreferenceUtils.getInstance(context).getString(USER_MOBILE_NO));
        String deviceUUID = DeviceUtils.getDeviceUUID(getApplicationContext());
        LoginOrSignUpModel.getInstance().setDeviceId(deviceUUID);
        LoginOrSignUpModel.getInstance().setDeviceType(DEVICE_TYPE);
        LoginOrSignUpModel.getInstance().setFcmToken(SharedPreferenceUtils.getInstance(getApplicationContext()).getString(FCM_TOKEN));
    }

    private void getProfileDetail() {
        progressDialog(context, getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);
        int userId = SharedPreferenceUtils.getInstance(currentActivity).getInteger(AppConstants.USER_ID);
        JSONObject jsonSignUpRequest = null;
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        try {
            jsonSignUpRequest = new JSONObject(gson.toJson(LoginOrSignUpModel.getInstance()));
            jsonSignUpRequest.put("user_id", userId);
            Log.e("jsonSignUpRequest", jsonSignUpRequest.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest signUpRequest = new JsonObjectRequest(Request.Method.POST, URL_GET_PROFILE, jsonSignUpRequest, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                cancelProgressDialog();
                try {
                    String message = response.getString(RESPONCE_MESSAGE);
                    if (response.getBoolean(RESPONCE_ERROR) || message.isEmpty()) {
                        //alert(currentActivity, getString(R.string.msg_reg_failed), getString(R.string.msg_reg_failed), getResources().getString(R.string.alert_add_amount), getResources().getString(R.string.alert_cancel_button_text_no_network), true, true, ALERT_TYPE_NO_NETWORK);
                    } else {
                        JSONObject messageJsonObj = new JSONObject(message);
                        SharedPreferenceUtils.getInstance(currentActivity).putString(AppConstants.USER_EMAIL, messageJsonObj.getString(USER_EMAIL));
                        SharedPreferenceUtils.getInstance(currentActivity).putString(USER_NAME, messageJsonObj.getString(USER_NAME));
                        SharedPreferenceUtils.getInstance(currentActivity).putString(AppConstants.USER_EXISTING_REF_CODE, messageJsonObj.getString(USER_EXISTING_REF_CODE));
                        toSetProfileDetails();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                logTesting(getResources().getString(R.string.nwk_error_sign_up), error.toString(), Log.ERROR);
                cancelProgressDialog();
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                return super.getHeaders();
            }
        };
        VyaanApplication.getInstance().addToRequestQueue(signUpRequest);
    }


    private boolean isMandatoryFields() {

        editName.setError(null);
        editEmail.setError(null);

        if (editName.getText().toString().isEmpty()) {
            editName.setError("Please enter name");
            editName.requestFocus();
            return false;
        } else if (!Validator.getInstance().isValidEmail(context, editEmail.getText().toString()).equals("")) {
            String emailError = Validator.getInstance().isValidEmail(context, editEmail.getText().toString());
            editEmail.setError(emailError);
            editEmail.requestFocus();
            return false;
        }
        initProfileDetailsModel();
        return true;
    }

    private boolean validateExtRefCode() {

        editExtRefCode.setError(null);
        if (editExtRefCode.getText().toString().isEmpty()) {
            editExtRefCode.setError("Please enter referred code");
            editExtRefCode.requestFocus();
            return false;
        }
        return true;
    }

    private void initProfileDetailsModel() {
        ProfileDetailsModel.getInstance().setDeviceType(DEVICE_TYPE);
        ProfileDetailsModel.getInstance().setLoginId(SharedPreferenceUtils.getInstance(context).getString(USER_MOBILE_NO));
        ProfileDetailsModel.getInstance().setAccessToken(DeviceUtils.getDeviceKey());
        ProfileDetailsModel.getInstance().setIpAddress(DeviceUtils.getDeviceIpAddress(context));
        ProfileDetailsModel.getInstance().setUserId(SharedPreferenceUtils.getInstance(context).getInteger(USER_ID));
        ProfileDetailsModel.getInstance().setName(editName.getText().toString());
        ProfileDetailsModel.getInstance().setEmailId(editEmail.getText().toString());
        if (TextUtils.isEmpty(ProfileDetailsModel.getInstance().getUserImageName())) {
            ProfileDetailsModel.getInstance().setUserImageName("");
        }
    }

    private void updateProfile() {

        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);

        JSONObject jsonUpdateUser = null;
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        try {
            jsonUpdateUser = new JSONObject(gson.toJson(ProfileDetailsModel.getInstance()));
            Log.e("jsonUpdateUser", jsonUpdateUser.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest profileUpdateRequest = new JsonObjectRequest(Request.Method.POST, UPDATE_USER_PROFILE, jsonUpdateUser, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                cancelProgressDialog();
                try {
                    logTesting(getResources().getString(R.string.nwk_response_edit_profile), response.toString(), Log.ERROR);
                    String message = response.getString(RESPONCE_MESSAGE);
                    if (response.getBoolean(RESPONCE_ERROR)) {
                        alert(currentActivity, getString(R.string.message_profile_update_fail), getString(R.string.message_profile_update_fail), getResources().getString(R.string.alert_ok_button_text_no_network), getResources().getString(R.string.alert_cancel_button_text_no_network), false, false, ALERT_TYPE_NO_NETWORK);
                    } else {
                        SharedPreferenceUtils.getInstance(currentActivity).putString(USER_NAME, editName.getText().toString());
                        SharedPreferenceUtils.getInstance(currentActivity).putString(USER_EMAIL, editEmail.getText().toString());
                        toast(getResources().getString(R.string.message_profile_updated), true);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                toast(getResources().getString(R.string.nwk_error_edit_profile), true);
                logTesting(getResources().getString(R.string.nwk_error_edit_profile), error.toString(), Log.ERROR);

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                return super.getHeaders();
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(profileUpdateRequest);
    }

    private void applyReferralCode() {

        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);

        JSONObject jsonUpdateUser = null;
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        try {
            jsonUpdateUser = new JSONObject();
            jsonUpdateUser.put("user_id", SharedPreferenceUtils.getInstance(context).getInteger(USER_ID));
            jsonUpdateUser.put("existing_ref_code", editExtRefCode.getText().toString());
            Log.e("jsonUpdateUser", jsonUpdateUser.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest profileUpdateRequest = new JsonObjectRequest(Request.Method.POST, UPDATE_APPLY_REF_CODE, jsonUpdateUser, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                cancelProgressDialog();
                try {
                    String message = response.getString(RESPONCE_MESSAGE);
                    if (response.getBoolean(RESPONCE_ERROR)) {
                        alert(currentActivity, "Alert", "Please enter a valid Referral Code", getResources().getString(R.string.alert_ok_button_text_no_network), getResources().getString(R.string.alert_cancel_button_text_no_network), false, true, ALERT_TYPE_NO_NETWORK);
                    } else {
                        SharedPreferenceUtils.getInstance(currentActivity).putString(USER_EXISTING_REF_CODE, editExtRefCode.getText().toString());
                        toast("Your referral code applied successfully.", true);
                        toSetProfileDetails();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                toast(getResources().getString(R.string.nwk_error_edit_profile), true);
                logTesting(getResources().getString(R.string.nwk_error_edit_profile), error.toString(), Log.ERROR);

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                return super.getHeaders();
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(profileUpdateRequest);
    }

    private void selectImage() {
        try {
            if (checkPermission()) {
                openChooseImageDialog();
            } else {
                requestPermission();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(currentActivity, Manifest.permission.CAMERA);
        if (result == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, RECEIVE_CAMERA_PERMISSION_REQUEST);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case RECEIVE_CAMERA_PERMISSION_REQUEST: {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    openChooseImageDialog();
                }
                break;
            }
        }
    }


    public void openChooseImageDialog() {
        final CharSequence[] options = {getString(R.string.option_take_photo), getString(R.string.option_gallery), getString(R.string.option_cancel)};
        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(currentActivity);
        builder.setTitle(getString(R.string.select_option));
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (options[item].equals(getString(R.string.option_take_photo))) {
                    dialog.dismiss();
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent, PICK_IMAGE_CAMERA);
                } else if (options[item].equals(getString(R.string.option_gallery))) {
                    dialog.dismiss();
                    Intent pickPhoto = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(pickPhoto, PICK_IMAGE_GALLERY);
                } else if (options[item].equals(getString(R.string.option_cancel))) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    public void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) {
        super.onActivityResult(requestCode, resultCode, imageReturnedIntent);
        switch (requestCode) {
            case PICK_IMAGE_CAMERA: {
                if (resultCode == RESULT_OK) {
                    Bitmap imageBitmap = (Bitmap) imageReturnedIntent.getExtras().get(KEY_DATA);
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    imageBitmap.compress(Bitmap.CompressFormat.JPEG, 70, bos);
                    circularProfileImage.setImageBitmap(imageBitmap);
                    uploadImageByVolley();
                }
                break;
            }
            case PICK_IMAGE_GALLERY: {
                if (resultCode == RESULT_OK) {
                    Uri filePath = imageReturnedIntent.getData();
                    try {
                        //Getting the Bitmap from Gallery
                        Bitmap imageBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                        imageBitmap.compress(Bitmap.CompressFormat.JPEG, 70, bos);
                        circularProfileImage.setImageBitmap(imageBitmap);
                        uploadImageByVolley();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                }
                break;
            }

        }
    }

    public void uploadImageByVolley() {

        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);


        final String lineEnd = "\r\n";
        final String twoHyphens = "--";
        final String boundary = "*****";

        final int maxBufferSize = 1 * 1024 * 1024;
        final byte[] imageBytesArray = Helper.getImageBytes(((BitmapDrawable) circularProfileImage.getDrawable()).getBitmap());
        Long timeMillis = System.currentTimeMillis();
        final String fileName = "Image_" + timeMillis.toString() + ".jpg";


        String imageUploadUrl = UPLOAD_NEW_IMAGE;
        BaseVolleyRequest uploadProfileImageRequest = new BaseVolleyRequest(1, imageUploadUrl, new Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {

                try {
                    cancelProgressDialog();
                    String jsonString = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    Log.e("image response  is", response.toString() + jsonString);
                    JSONObject jsonObject = new JSONObject(jsonString);
                    if (jsonObject.getBoolean(RESPONCE_ERROR)) {
                        alert(currentActivity, getString(R.string.message_image_upload_fail), getString(R.string.message_image_upload_fail), getResources().getString(R.string.alert_ok_button_text_no_network), getResources().getString(R.string.alert_cancel_button_text_no_network), false, false, ALERT_TYPE_NO_NETWORK);
                    } else {
                        SharedPreferenceUtils.getInstance(context).putString(USER_PROFILE_IMAGE, fileName);
                        ProfileDetailsModel.getInstance().setUserId(SharedPreferenceUtils.getInstance(context).getInteger(USER_ID));
                        ProfileDetailsModel.getInstance().setUserImageName(fileName);
                        ProfileDetailsModel.getInstance().setName(editName.getText().toString());
                        ProfileDetailsModel.getInstance().setEmailId(editEmail.getText().toString());
                        toast(getString(R.string.message_image_upload_suc), true);
                        updateProfile();
                    }
                } catch (UnsupportedEncodingException e) {
                    cancelProgressDialog();
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Log.e("image response  is", response.toString());
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                toast(getString(R.string.error_uploading_image), true);
                Log.e(getString(R.string.error_uploading_image), error.toString());
            }
        }) {
            @Override
            public String getBodyContentType() {
                mimeType = "multipart/form-data;boundary=" + boundary;
                return mimeType;
            }

            @Override
            public byte[] getBody() throws AuthFailureError {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                DataOutputStream dos = new DataOutputStream(bos);


                try {
                    dos.writeBytes(twoHyphens + boundary + lineEnd);
                    dos.writeBytes("Content-Disposition: form-data; name=\"uploaded_file\";filename=\"" + fileName + "\"" + lineEnd);

                    dos.writeBytes(lineEnd);

                    ByteArrayInputStream fileInputStream = new ByteArrayInputStream(imageBytesArray);
                    bytesAvailable = fileInputStream.available();

                    int bufferSize = Math.min(imageBytesArray.length, maxBufferSize);
                    byte[] buffer = new byte[bufferSize];

                    bytesRead = fileInputStream.read(buffer, 0, bufferSize);

                    while (bytesRead > 0) {
                        dos.write(buffer, 0, bufferSize);
                        bytesAvailable = fileInputStream.available();
                        bufferSize = Math.min(bytesAvailable, maxBufferSize);
                        bytesRead = fileInputStream.read(buffer, 0, bufferSize);
                    }


                    //    dos.write(imageBytesArray, 0, bufferSize);
                    // send multipart form data necesssary after file data...
                    dos.writeBytes(lineEnd);
                    dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

                    return bos.toByteArray();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                return imageBytesArray;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {

                Long timeMillis = System.currentTimeMillis();
                Map<String, String> params = new HashMap<String, String>();
                params.put("Connection", "Keep-Alive");
                params.put("ENCTYPE", "multipart/form-data");
                params.put("accept", "application/json");
                params.put("uploaded_file", fileName);
                params.put("Content-Type", "multipart/form-data;boundary=" + boundary);
                return params;

            }

        };

        VyaanApplication.getInstance().addToRequestQueue(uploadProfileImageRequest);
    }

}
