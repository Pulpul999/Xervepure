package com.app.xervepure.adapter;

import android.app.Activity;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.app.xervepure.R;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.model.WalletHistoryModel;
import com.app.xervepure.utils.DateTimeUtils;
import com.app.xervepure.utils.FontUtils;

import java.util.List;

/**
 * Created by Mayank on 31/08/2016.
 */
public class WalletHistoryAdapter extends RecyclerView.Adapter<WalletHistoryAdapter.ViewHolder> {


    Activity currentActivity;
    List<WalletHistoryModel> walletHistoryModelList;


    public WalletHistoryAdapter(Activity currentActivity, List<WalletHistoryModel> walletHistoryModelList) {
        this.currentActivity = currentActivity;
        this.walletHistoryModelList = walletHistoryModelList;
    }

    @Override
    public WalletHistoryAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(currentActivity).inflate(R.layout.item_wallet_history, parent, false);

        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(WalletHistoryAdapter.ViewHolder holder, int position) {

        final int pos = position;
        WalletHistoryModel walletHistoryModel = walletHistoryModelList.get(pos);
        if (walletHistoryModel == null) return;
        holder.lableDateTV.setText(DateTimeUtils.getDateInFormat(walletHistoryModel.getCreationTimestamp()));
        holder.lableRemarksTV.setText(walletHistoryModel.getOrderTypeDescription());
        holder.lableTypeTV.setText(currentActivity.getString(R.string.rupees_symbol) + " " + walletHistoryModel.getAmount());

        if (walletHistoryModel.getTransactionTypeDescription().equalsIgnoreCase("Cr")) {
            holder.lableTypeTV.setTextColor(Color.GREEN);
        } else {
            holder.lableTypeTV.setTextColor(Color.RED);
        }
    }

    @Override
    public int getItemCount() {
        return walletHistoryModelList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView lableDateTV;
        private TextView lableRemarksTV;
        private TextView lableTypeTV;

        public ViewHolder(View itemView) {
            super(itemView);
            lableDateTV = (TextView) itemView.findViewById(R.id.lableDateTV);
            lableRemarksTV = (TextView) itemView.findViewById(R.id.lableRemarksTV);
            lableTypeTV = (TextView) itemView.findViewById(R.id.lableTypeTV);

            FontUtils.changeFont(currentActivity, lableDateTV, AppConstants.FONT_ROBOTO_REGULAR);
            FontUtils.changeFont(currentActivity, lableRemarksTV, AppConstants.FONT_ROBOTO_REGULAR);
            FontUtils.changeFont(currentActivity, lableDateTV, AppConstants.FONT_ROBOTO_REGULAR);

        }
    }
}
