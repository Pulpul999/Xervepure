package com.app.xervepure.adapter;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.app.xervepure.R;
import com.app.xervepure.activity.BaseActivity;
import com.app.xervepure.activity.OrderHistoryDetailsActivity;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.interfaces.RecyclerClickListner;
import com.app.xervepure.model.OrderHistoryModel;
import com.app.xervepure.utils.DateTimeUtils;
import com.app.xervepure.utils.FontUtils;

import java.util.List;


public class MyPlanAdapter extends RecyclerView.Adapter<MyPlanAdapter.ViewHolder> {

    List<OrderHistoryModel> subscriptionModelList;
    Activity currentActivity;

    Bundle bundle;

    public MyPlanAdapter(Activity currentActivity, List<OrderHistoryModel> subscriptionModelList) {
        this.subscriptionModelList = subscriptionModelList;
        this.currentActivity = currentActivity;
    }

    @Override
    public MyPlanAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(currentActivity).inflate(R.layout.items_my_plans, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(final MyPlanAdapter.ViewHolder holder, final int position) {
        final int pos = position;
        OrderHistoryModel orderHistoryModel = null;
        if (subscriptionModelList != null && subscriptionModelList.size() > pos) {
            orderHistoryModel = subscriptionModelList.get(pos);
        }
        if (orderHistoryModel == null) return;
        holder.orderIdTV.setText("#" + orderHistoryModel.getId());
        holder.totalAmountTV.setText(currentActivity.getString(R.string.rupees_symbol) + " " + orderHistoryModel.getTotalAmount() + " /-");
        holder.dateTV.setText(DateTimeUtils.getDateInFormat(orderHistoryModel.getTimestamp()));
        int status = orderHistoryModel.getOrderStatus();
        if (status == 0 || status == 2) {
            holder.statusTV.setText("Pending");
            holder.buttonCancel.setVisibility(View.VISIBLE);
        } else if (status == 1) {
            holder.statusTV.setText("Delivered");
            holder.statusTV.setTextColor(Color.GREEN);
            holder.buttonCancel.setVisibility(View.GONE);
        } else if (status == 3) {
            holder.statusTV.setTextColor(ContextCompat.getColor(currentActivity,R.color.colorAccent));
            holder.statusTV.setText("Upcoming");
            holder.buttonCancel.setVisibility(View.VISIBLE);
        } else if (status == 4) {
            holder.statusTV.setText("Cancelled");
            holder.statusTV.setTextColor(Color.RED);
            holder.buttonCancel.setVisibility(View.GONE);
        }

        if (orderHistoryModel.getOrderType() == AppConstants.TYPE_ORDER) {
            holder.lblOrderIdTV.setText(currentActivity.getString(R.string.lblOrderId));
        } else {
            holder.lblOrderIdTV.setText(currentActivity.getString(R.string.lblSubscriptionId));
        }
        holder.buttonCancel.setTag(subscriptionModelList.get(pos).getId());
        holder.buttonExplore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bundle == null) {
                    bundle = new Bundle();
                }
                bundle.putParcelable(AppConstants.ORDERHISTORY_MODEL, subscriptionModelList.get(pos));
                ((BaseActivity) currentActivity).startActivity(currentActivity, OrderHistoryDetailsActivity.class, bundle, true, AppConstants.REQUEST_TAG_MY_PLANS, true, AppConstants.ANIMATION_SLIDE_LEFT);
            }
        });
    }

    @Override
    public int getItemCount() {
        return subscriptionModelList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        TextView lblOrderIdTV;
        TextView orderIdTV;
        TextView lblTotalAmountTV;
        TextView totalAmountTV;
        TextView lblDateTV;
        TextView dateTV;
        TextView lblStatusTV;
        TextView statusTV;
        TextView buttonExplore;
        TextView buttonCancel;

        public ViewHolder(View itemView) {
            super(itemView);

            lblOrderIdTV = (TextView) itemView.findViewById(R.id.lblOrderIdTV);
            orderIdTV = (TextView) itemView.findViewById(R.id.orderIdTV);
            lblTotalAmountTV = (TextView) itemView.findViewById(R.id.lblTotalAmountTV);
            totalAmountTV = (TextView) itemView.findViewById(R.id.totalAmountTV);
            lblDateTV = (TextView) itemView.findViewById(R.id.lblDateTV);
            dateTV = (TextView) itemView.findViewById(R.id.dateTV);
            lblStatusTV = (TextView) itemView.findViewById(R.id.lblStatusTV);
            statusTV = (TextView) itemView.findViewById(R.id.statusTV);
            buttonExplore = (TextView) itemView.findViewById(R.id.buttonExplore);
            buttonCancel = (TextView) itemView.findViewById(R.id.buttonCancel);

            FontUtils.changeFont(currentActivity, lblOrderIdTV, AppConstants.FONT_ROBOTO_MEDIUM);
            FontUtils.changeFont(currentActivity, orderIdTV, AppConstants.FONT_ROBOTO_REGULAR);
            FontUtils.changeFont(currentActivity, lblTotalAmountTV, AppConstants.FONT_ROBOTO_MEDIUM);
            FontUtils.changeFont(currentActivity, totalAmountTV, AppConstants.FONT_ROBOTO_REGULAR);
            FontUtils.changeFont(currentActivity, lblDateTV, AppConstants.FONT_ROBOTO_MEDIUM);
            FontUtils.changeFont(currentActivity, dateTV, AppConstants.FONT_ROBOTO_REGULAR);
            FontUtils.changeFont(currentActivity, lblStatusTV, AppConstants.FONT_ROBOTO_MEDIUM);
            FontUtils.changeFont(currentActivity, statusTV, AppConstants.FONT_ROBOTO_REGULAR);
            FontUtils.changeFont(currentActivity, buttonExplore, AppConstants.FONT_ROBOTO_MEDIUM);
            FontUtils.changeFont(currentActivity, buttonCancel, AppConstants.FONT_ROBOTO_MEDIUM);

            buttonCancel.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            clickListener.onItemClick(getAdapterPosition(), view);
        }
    }
    private static RecyclerClickListner clickListener;

    public void setOnItemClickListener(RecyclerClickListner clickListener) {
        MyPlanAdapter.clickListener = clickListener;
    }
}
