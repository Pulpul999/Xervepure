package com.app.xervepure.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

public class OrderHistoryModel implements Parcelable {

    private int id;
    @SerializedName("transaction_id")
    private String transactionId;
    @SerializedName("creation_timestamp")
    private String timestamp;
    @SerializedName("order_status")
    private int orderStatus;
    @SerializedName("order_type")
    private int orderType;
    @SerializedName("total_amout")
    private String totalAmount;
    @SerializedName("name")
    private String productName;
    @SerializedName("quantity")
    private String productQuantity;
    private String image;
    @SerializedName("no_quantity")
    private int quantity;
    @SerializedName("delivered_qty")
    private int deliveredQty;
    private int price;


    protected OrderHistoryModel(Parcel in) {
        id = in.readInt();
        transactionId = in.readString();
        timestamp = in.readString();
        orderStatus = in.readInt();
        orderType = in.readInt();
        totalAmount = in.readString();
        productName = in.readString();
        productQuantity = in.readString();
        image = in.readString();
        quantity = in.readInt();
        deliveredQty = in.readInt();
        price = in.readInt();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(transactionId);
        dest.writeString(timestamp);
        dest.writeInt(orderStatus);
        dest.writeInt(orderType);
        dest.writeString(totalAmount);
        dest.writeString(productName);
        dest.writeString(productQuantity);
        dest.writeString(image);
        dest.writeInt(quantity);
        dest.writeInt(deliveredQty);
        dest.writeInt(price);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<OrderHistoryModel> CREATOR = new Creator<OrderHistoryModel>() {
        @Override
        public OrderHistoryModel createFromParcel(Parcel in) {
            return new OrderHistoryModel(in);
        }

        @Override
        public OrderHistoryModel[] newArray(int size) {
            return new OrderHistoryModel[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public int getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(int orderStatus) {
        this.orderStatus = orderStatus;
    }

    public int getOrderType() {
        return orderType;
    }

    public void setOrderType(int orderType) {
        this.orderType = orderType;
    }

    public String getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductQuantity() {
        return productQuantity;
    }

    public void setProductQuantity(String productQuantity) {
        this.productQuantity = productQuantity;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getDeliveredQty() {
        return deliveredQty;
    }

    public void setDeliveredQty(int deliveredQty) {
        this.deliveredQty = deliveredQty;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
