package com.app.xervepure.activity;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.app.xervepure.R;
import com.app.xervepure.adapter.WalletHistoryAdapter;
import com.app.xervepure.application.VyaanApplication;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.model.RequestModel;
import com.app.xervepure.model.WalletHistoryModel;
import com.app.xervepure.utils.DeviceUtils;
import com.app.xervepure.utils.FontUtils;
import com.app.xervepure.utils.SharedPreferenceUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WalletHistoryActivity extends BaseActivity {

    private RecyclerView recyclerWalletHistory;
    private WalletHistoryAdapter historyAdapter;
    private ArrayList<WalletHistoryModel> historyModelArrayList;
    private LinearLayoutManager linearLayoutManager;
    private TextView lableDateTV;
    private TextView lableRemarksTV;
    private TextView lableTypeTV;
    private TextView labelwalletBalanceTV;
    private TextView currentBalanceTV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallet_history);
    }

    @Override
    protected void initViews() {
        getSupportActionBar().setTitle(getString(R.string.labelWalletHistory));
        historyModelArrayList = new ArrayList<>();
        recyclerWalletHistory = (RecyclerView) findViewById(R.id.recyclerWalletHistory);
        historyAdapter = new WalletHistoryAdapter(currentActivity, historyModelArrayList);
        linearLayoutManager = new LinearLayoutManager(currentActivity);
        recyclerWalletHistory.setLayoutManager(linearLayoutManager);
        recyclerWalletHistory.setAdapter(historyAdapter);

        lableDateTV = (TextView) findViewById(R.id.lableDateTV);
        lableRemarksTV = (TextView) findViewById(R.id.lableRemarksTV);
        lableTypeTV = (TextView) findViewById(R.id.lableTypeTV);
        labelwalletBalanceTV = (TextView) findViewById(R.id.labelwalletBalanceTV);
        currentBalanceTV = (TextView) findViewById(R.id.currentBalanceTV);

        String walletBalance = SharedPreferenceUtils.getInstance(context).getString(USER_WALLET_BALANCE);
        currentBalanceTV.setText(getString(R.string.rupees_symbol) + walletBalance);

        FontUtils.changeFont(currentActivity, lableDateTV, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, lableRemarksTV, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, lableTypeTV, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(context, labelwalletBalanceTV, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(context, currentBalanceTV, AppConstants.FONT_ROBOTO_MEDIUM);

        getWalletHistory();
    }

    @Override
    protected void initContext() {
        context = WalletHistoryActivity.this;
        currentActivity = WalletHistoryActivity.this;
    }

    @Override
    protected void initListners() {

    }

    @Override
    protected boolean isActionBar() {
        return true;
    }

    @Override
    protected boolean isHomeButton() {
        return true;
    }

    @Override
    public void onClick(View v) {

    }

    @Override
    public void onAlertClicked(int alertType) {

    }
    private void initRequestModel() {
        RequestModel.getInstance().setDeviceType(DEVICE_TYPE);
        RequestModel.getInstance().setLoginId(SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_MOBILE_NO));
        RequestModel.getInstance().setAccessToken(DeviceUtils.getDeviceKey());
        RequestModel.getInstance().setIpAddress(DeviceUtils.getDeviceIpAddress(context));
    }
    public void getWalletHistory() {

        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);
        int userId = SharedPreferenceUtils.getInstance(currentActivity).getInteger(AppConstants.USER_ID);
        initRequestModel();
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        JSONObject jsonGetBalanceRequest = null;
        try {
            jsonGetBalanceRequest = new JSONObject(gson.toJson(RequestModel.getInstance()));
            jsonGetBalanceRequest.put("user_id", userId);
            Log.e("getWalletHistory", jsonGetBalanceRequest.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_GET_WALLET_HISTORY, jsonGetBalanceRequest, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                ((BaseActivity) currentActivity).logTesting("getWalletHistory responce is", response.toString(), Log.ERROR);

                try {
                    cancelProgressDialog();
                        historyModelArrayList.clear();
                        Gson gson = new Gson();
                        List<WalletHistoryModel> historyModels = Arrays.asList(gson.fromJson(response.getJSONArray("response").toString(), WalletHistoryModel[].class));
                        historyModelArrayList.addAll(historyModels);
                        historyAdapter.notifyDataSetChanged();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                ((BaseActivity) currentActivity).logTesting("error is", error.toString(), Log.ERROR);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();

                params.put("Content-Type", "application/json");

                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }
}
