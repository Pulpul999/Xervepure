package com.app.xervepure.activity;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.app.xervepure.R;
import com.app.xervepure.adapter.OrderHistoryDetailsAdapter;
import com.app.xervepure.application.VyaanApplication;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.model.OrderHistoryModel;
import com.app.xervepure.model.RequestModel;
import com.app.xervepure.utils.DateTimeUtils;
import com.app.xervepure.utils.DeviceUtils;
import com.app.xervepure.utils.FontUtils;
import com.app.xervepure.utils.SharedPreferenceUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderHistoryDetailsActivity extends BaseActivity {

    private TextView lblOrderIdTV;
    private TextView orderIdTV;
    private TextView lblTotalAmountTV;
    private TextView totalAmountTV;
    private TextView lblDateTV;
    private TextView dateTV;
    private TextView lblStatusTV;
    private TextView statusTV;
    private OrderHistoryModel historyModel;
    private RecyclerView recyclerOrderDetails;
    private LinearLayoutManager linearLayoutManager;
    private ArrayList<OrderHistoryModel> historyModelArrayList;
    private OrderHistoryDetailsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history_details);
    }

    @Override
    protected void initViews() {
        historyModelArrayList = new ArrayList<>();
        getSupportActionBar().setTitle(getString(R.string.title_view_orders));
        if (getIntent().getExtras() != null)
            historyModel = getIntent().getExtras().getParcelable(ORDERHISTORY_MODEL);
        recyclerOrderDetails = (RecyclerView) findViewById(R.id.recyclerOrderDetails);
        linearLayoutManager = new LinearLayoutManager(currentActivity);
        lblOrderIdTV = (TextView) findViewById(R.id.lblOrderIdTV);
        orderIdTV = (TextView) findViewById(R.id.orderIdTV);
        lblTotalAmountTV = (TextView) findViewById(R.id.lblTotalAmountTV);
        totalAmountTV = (TextView) findViewById(R.id.totalAmountTV);
        lblDateTV = (TextView) findViewById(R.id.lblDateTV);
        dateTV = (TextView) findViewById(R.id.dateTV);
        lblStatusTV = (TextView) findViewById(R.id.lblStatusTV);
        statusTV = (TextView) findViewById(R.id.statusTV);

        adapter = new OrderHistoryDetailsAdapter(currentActivity, historyModelArrayList);
        recyclerOrderDetails.setAdapter(adapter);
        recyclerOrderDetails.setLayoutManager(linearLayoutManager);

        FontUtils.changeFont(currentActivity, lblOrderIdTV, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, orderIdTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, lblTotalAmountTV, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, totalAmountTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, lblDateTV, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, dateTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, lblStatusTV, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, statusTV, AppConstants.FONT_ROBOTO_REGULAR);

        setTextValues();
        myPlans();
    }

    @Override
    protected void initContext() {
        context = OrderHistoryDetailsActivity.this;
        currentActivity = OrderHistoryDetailsActivity.this;
    }

    @Override
    protected void initListners() {

    }

    @Override
    protected boolean isActionBar() {
        return true;
    }

    @Override
    protected boolean isHomeButton() {
        return true;
    }

    @Override
    public void onClick(View v) {

    }

    @Override
    public void onAlertClicked(int alertType) {

    }

    private void setTextValues() {
        if (historyModel == null) return;
        orderIdTV.setText("#" + historyModel.getId());
        totalAmountTV.setText(currentActivity.getString(R.string.rupees_symbol) + " " + historyModel.getTotalAmount() + " /-");
        dateTV.setText(DateTimeUtils.getDateInFormat(historyModel.getTimestamp()));
        //statusTV.setText(historyModel.getOrderStatus());
        if (historyModel.getOrderType() == AppConstants.TYPE_ORDER) {
            lblOrderIdTV.setText(currentActivity.getString(R.string.lblOrderId));
        } else {
            lblOrderIdTV.setText(currentActivity.getString(R.string.lblSubscriptionId));
        }
    }
    private void initRequestModel() {
        RequestModel.getInstance().setDeviceType(DEVICE_TYPE);
        RequestModel.getInstance().setLoginId(SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_MOBILE_NO));
        RequestModel.getInstance().setAccessToken(DeviceUtils.getDeviceKey());
        RequestModel.getInstance().setIpAddress(DeviceUtils.getDeviceIpAddress(context));
    }
    public void myPlans() {

        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);

        initRequestModel();
        JSONObject jsons = null;
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        try {
            jsons = new JSONObject(gson.toJson(RequestModel.getInstance()));
            jsons.put("order_id", historyModel.getId());
            Log.e("jsonGetOrderDetails", jsons.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_ORDER_HISTORY_BY_ID, jsons, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                ((BaseActivity) currentActivity).logTesting("GetOrderDetails", response.toString(), Log.ERROR);

                try {
                    cancelProgressDialog();
                    ((BaseActivity) currentActivity).logTesting("is successfull fetch subscription", "hi" + response.getBoolean(AppConstants.KEY_ERROR), Log.ERROR);
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                        historyModelArrayList.clear();
                        Gson gson = new Gson();
                        List<OrderHistoryModel> orderModelListTemp = Arrays.asList(gson.fromJson(response.getJSONArray(MESSAGE).toString(), OrderHistoryModel[].class));
                        if (orderModelListTemp.size() > 0) {
                            historyModelArrayList.addAll(orderModelListTemp);
                            adapter.notifyDataSetChanged();
                        }
                    }

                } catch (JSONException e) {
                    ((BaseActivity) currentActivity).logTesting("fetch subscription json exeption is", e.toString(), Log.ERROR);
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                ((BaseActivity) currentActivity).logTesting("error is", error.toString(), Log.ERROR);
                ((BaseActivity) currentActivity).toast(getResources().getString(R.string.errorMyPlans), true);

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();

                params.put("Content-Type", "application/json");


                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }

}
