package com.app.xervepure.model;

/**
 * Created by Codeslay-03 on 11/16/2017.
 */

public class RequestModel extends BaseRequestModel {

    private static RequestModel requestModel;

    private RequestModel() {
        super();
    }

    public static RequestModel getInstance() {
        if (requestModel == null) {
            requestModel = new RequestModel();
        }
        return requestModel;
    }
}
