package com.app.xervepure.adapter;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.app.xervepure.R;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.model.ProductDetailModel;
import com.app.xervepure.utils.FontUtils;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by GARIMA on 9/15/2017.
 */

public class ProductDetailAdapter extends RecyclerView.Adapter<ProductDetailAdapter.ViewHolder> implements AppConstants {
    Activity currentActivity;
    ArrayList<ProductDetailModel> productDetailModelArrayList;
    private int quantityCounter;
    private int minQuantity;
    private static RecyclerClickListner clickListener;
    Bundle bundle;

    public interface RecyclerClickListner {
        void onItemClick(int position, View v, TextView quantityTV, TextView rupeesTextView);

        void onItemLongClick(int position, View v);
    }

    public ProductDetailAdapter(Activity currentActivity, ArrayList<ProductDetailModel> productDetailModelArrayList) {
        this.currentActivity = currentActivity;
        this.productDetailModelArrayList = productDetailModelArrayList;
    }

    @Override
    public ProductDetailAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(currentActivity).inflate(R.layout.item_product_detail, parent, false);
        ProductDetailAdapter.ViewHolder holder = new ProductDetailAdapter.ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(ProductDetailAdapter.ViewHolder holder, int position) {
        final int pos = position;
        if (productDetailModelArrayList != null && productDetailModelArrayList.size() > pos) {
            ProductDetailModel productDetailModel = productDetailModelArrayList.get(pos);
            if (productDetailModel == null) return;
            if (productDetailModel.getIsSampleProduct().equalsIgnoreCase(IS_SAMPLE)) {
                holder.subcartLL.setVisibility(View.GONE);
                holder.sampleLL.setVisibility(View.VISIBLE);
                holder.addQuantityLL.setVisibility(View.GONE);

            } else {
                holder.sampleLL.setVisibility(View.GONE);
                holder.subcartLL.setVisibility(View.VISIBLE);
                holder.addQuantityLL.setVisibility(View.VISIBLE);
            }
            setOnClickListener(holder.plusImageView, holder.productNumberTextView, holder.rupeesTextView, productDetailModelArrayList.get(position).getPrice());
            setOnClickListener(holder.minusImageView, holder.productNumberTextView, holder.rupeesTextView, productDetailModelArrayList.get(position).getPrice());
            holder.productNameTextView.setText(productDetailModelArrayList.get(position).getName());
            holder.rupeesTextView.setText(productDetailModelArrayList.get(position).getPrice());
            holder.quantityTextView.setText(productDetailModelArrayList.get(position).getQuantity());
            String imageUrl = AppConstants.BASE_URL_IMAGES + "/" + productDetailModel.getImage();
            Picasso.with(currentActivity).load(imageUrl).placeholder(R.drawable.applogo).error(R.drawable.applogo).into(holder.image);

            if (productDetailModel.getProductType() == PRODUCT_TYPE_MILK) {
                holder.productNumberTextView.setText("" + MILK_MIN_ORDER_QTY);
                quantityCounter = MILK_MIN_ORDER_QTY;
                minQuantity = MILK_MIN_ORDER_QTY;
            } else {
                quantityCounter = OTHER_MIN_ORDER_QTY;
                minQuantity = OTHER_MIN_ORDER_QTY;
            }
        }

        FontUtils.changeFont(currentActivity, holder.productNameTextView, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, holder.quantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, holder.rupeesTextView, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, holder.subscribeTextView, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, holder.addCartTextView, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, holder.sampleButton, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, holder.productNumberTextView, AppConstants.FONT_ROBOTO_REGULAR);


    }

    @Override
    public int getItemCount() {
        return productDetailModelArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ImageView image;
        ImageView plusImageView;
        ImageView minusImageView;
        TextView productNameTextView;
        TextView productNumberTextView;
        TextView rupeesTextView;
        TextView subscribeTextView;
        TextView addCartTextView;
        TextView quantityTextView;
        Button sampleButton;
        LinearLayout subcartLL;
        LinearLayout sampleLL;
        LinearLayout addQuantityLL;


        public ViewHolder(View itemView) {
            super(itemView);

            image = (ImageView) itemView.findViewById(R.id.image);
            productNameTextView = (TextView) itemView.findViewById(R.id.productNameTextView);
            productNumberTextView = (TextView) itemView.findViewById(R.id.productNumberTextView);
            rupeesTextView = (TextView) itemView.findViewById(R.id.rupeesTextView);
            subscribeTextView = (TextView) itemView.findViewById(R.id.subscribeTextView);
            addCartTextView = (TextView) itemView.findViewById(R.id.addCartTextView);
            plusImageView = (ImageView) itemView.findViewById(R.id.plusImageView);
            minusImageView = (ImageView) itemView.findViewById(R.id.minusImageView);
            sampleButton = (Button) itemView.findViewById(R.id.sampleButton);
            quantityTextView = (TextView) itemView.findViewById(R.id.quantityTextView);
            subcartLL = (LinearLayout) itemView.findViewById(R.id.subcartLL);
            sampleLL = (LinearLayout) itemView.findViewById(R.id.sampleLL);
            addQuantityLL = (LinearLayout) itemView.findViewById(R.id.addQuantityLL);

            addCartTextView.setOnClickListener(this);
            subscribeTextView.setOnClickListener(this);
            sampleButton.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            clickListener.onItemClick(getAdapterPosition(), v, productNumberTextView, rupeesTextView);
        }
    }

    public void updateAdapter(ArrayList<ProductDetailModel> productDetailModelArrayList) {
        this.productDetailModelArrayList = productDetailModelArrayList;
        notifyDataSetChanged();
    }

    private void setOnClickListener(ImageView plushImageView, final TextView quantityTextView, final TextView rupeesTextView, final String itemPrice) {
        View.OnClickListener clickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (view.getId()) {
                    case R.id.plusImageView: {
                        if (!TextUtils.isEmpty(quantityTextView.getText().toString())) {
                            quantityCounter = Integer.parseInt(quantityTextView.getText().toString());
                        }
                        if (quantityCounter > minQuantity) {
                            double currentPrice = Double.parseDouble(rupeesTextView.getText().toString());
                            double itemValue = Double.parseDouble(itemPrice);
                            double netPrice = currentPrice + itemValue;
                            // rupeesTextView.setText(String.valueOf(netPrice));
                        }
                        quantityCounter++;
                        quantityTextView.setText(String.valueOf(quantityCounter));
                    }
                    break;
                    case R.id.minusImageView:
                        if (!TextUtils.isEmpty(quantityTextView.getText().toString())) {
                            quantityCounter = Integer.parseInt(quantityTextView.getText().toString());
                        }
                        if (quantityCounter > minQuantity) {

                            quantityCounter--;
                            double currentPrice = Double.parseDouble(rupeesTextView.getText().toString());
                            double itemValue = Double.parseDouble(itemPrice);
                            double netPrice = currentPrice + itemValue;
                            //  rupeesTextView.setText(String.valueOf(netPrice));
                            quantityTextView.setText(String.valueOf(quantityCounter));
                        }


                        break;
                }

            }
        };
        plushImageView.setOnClickListener(clickListener);

    }

    public void setOnItemClickListener(RecyclerClickListner clickListener) {
        ProductDetailAdapter.clickListener = clickListener;
    }
}

