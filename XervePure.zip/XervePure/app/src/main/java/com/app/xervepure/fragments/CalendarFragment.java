package com.app.xervepure.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.app.xervepure.R;
import com.app.xervepure.activity.BaseActivity;
import com.app.xervepure.application.VyaanApplication;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.model.CalendarProductModel;
import com.app.xervepure.utils.SharedPreferenceUtils;
import com.app.xervepure.widgets.CalendarCustomView;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 */
public class CalendarFragment extends BaseFragment {

    private ArrayList<CalendarProductModel> calendarProductModelArrayList;
    private CalendarCustomView calendarCustomView;
    private ImageView previousButton, nextButton;
    private TextView currentDate;
    private Calendar cal = Calendar.getInstance(Locale.ENGLISH);
    private SimpleDateFormat formatter = new SimpleDateFormat("MMMM yyyy", Locale.ENGLISH);
    public CalendarFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return view = inflater.inflate(R.layout.fragment_calendar_view, container, false);
    }

    @Override
    public void alertOkClicked() {

    }

    @Override
    protected void initViews() {
        calendarProductModelArrayList = new ArrayList<>();
        calendarCustomView = view.findViewById(R.id.custom_calendar);
        previousButton = (ImageView)view.findViewById(R.id.previous_month);
        nextButton = (ImageView)view.findViewById(R.id.next_month);
        currentDate = (TextView)view.findViewById(R.id.display_current_date);
        String sDate = formatter.format(cal.getTime());
        currentDate.setText(sDate);
        getCalendarData();
    }

    @Override
    protected void initContext() {
        context = getActivity();
        currentActivity = getActivity();
    }

    @Override
    protected void initListners() {
        previousButton.setOnClickListener(this);
        nextButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.previous_month:{
                cal.add(Calendar.MONTH, -1);
                String sDate = formatter.format(cal.getTime());
                currentDate.setText(sDate);
                calendarCustomView.setPreviousButtonClickEvent();
                getCalendarData();
               break;
            }
            case R.id.next_month:{
                cal.add(Calendar.MONTH, 1);
                String sDate = formatter.format(cal.getTime());
                currentDate.setText(sDate);
                calendarCustomView.setNextButtonClickEvent();
                getCalendarData();
                break;
            }
        }
    }

    public void getCalendarData() {
        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);
        int currentMonth = cal.get(Calendar.MONTH) + 1;
        int currentYear = cal.get(Calendar.YEAR);
        JSONObject jsons = null;
        try {
            jsons = new JSONObject();
            jsons.put("year", currentYear);
            jsons.put("month", currentMonth);
            jsons.put(KEY_USER_ID, SharedPreferenceUtils.getInstance(context).getInteger(USER_ID));
            Log.e("jsonGetCalendarData", jsons.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_GET_CALENDAR_DATA, jsons, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    cancelProgressDialog();
                    ((BaseActivity) currentActivity).logTesting("jsonGetCalendarData", "hi" + response.getJSONArray(MESSAGE).toString(), Log.ERROR);
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                        Gson gson = new Gson();
                        List<CalendarProductModel> calendarProductModels = Arrays.asList(gson.fromJson(response.getJSONArray(MESSAGE).toString(), CalendarProductModel[].class));
                        if (calendarProductModelArrayList == null) {
                            calendarProductModelArrayList = new ArrayList<>();
                        }else {
                            calendarProductModelArrayList.clear();
                        }
                        if (calendarProductModels != null) {
                            calendarProductModelArrayList.addAll(calendarProductModels);
                            calendarCustomView.updateCalendarView(calendarProductModelArrayList);
                        }
                    } else {
                        cancelProgressDialog();
                        ((BaseActivity) currentActivity).logTesting("fetch products error", "true", Log.ERROR);
                    }


                } catch (JSONException e) {
                    ((BaseActivity) currentActivity).logTesting("fetch products json exception is", e.toString(), Log.ERROR);
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                ((BaseActivity) currentActivity).logTesting("error is", error.toString(), Log.ERROR);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();

                params.put("Content-Type", "application/json");


                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }
}
