package com.app.xervepure.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by Codeslay-03 on 9/22/2017.
 */

public class PlaceSubscriptionModel extends BaseRequestModel implements Parcelable {

    private int id;
    @SerializedName("user_id")
    private int userId;
    @SerializedName("product_id")
    private int productId;
    @SerializedName("subscription_type")
    private int subscriptionType;
    @SerializedName("address_id")
    private int addressId;
    @SerializedName("repeat_week")
    private int isRepeatWeekly;
    @SerializedName("product_price")
    private int productPrice;
    @SerializedName("start_date")
    private String startDate;
    @SerializedName("product_image")
    private String imageName;
    @SerializedName("product_name")
    private String productName;
    @SerializedName("product_actual_quantity")
    private String productQuantity;
    @SerializedName("is_subscription_hold")
    private int subscriptionHoldType;
    @SerializedName("product_type")
    private int productType;
    @SerializedName("array_day_subscription")
    private ArrayList<DaySubscriptionModel> daySubscriptionModels;
    @SerializedName("end_date")
    private String endDate;
    public PlaceSubscriptionModel() {
        super();
    }


    protected PlaceSubscriptionModel(Parcel in) {
        id = in.readInt();
        userId = in.readInt();
        productId = in.readInt();
        subscriptionType = in.readInt();
        addressId = in.readInt();
        isRepeatWeekly = in.readInt();
        productPrice = in.readInt();
        startDate = in.readString();
        imageName = in.readString();
        productName = in.readString();
        productQuantity = in.readString();
        subscriptionHoldType = in.readInt();
        productType = in.readInt();
        daySubscriptionModels = in.createTypedArrayList(DaySubscriptionModel.CREATOR);
        endDate = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeInt(userId);
        dest.writeInt(productId);
        dest.writeInt(subscriptionType);
        dest.writeInt(addressId);
        dest.writeInt(isRepeatWeekly);
        dest.writeInt(productPrice);
        dest.writeString(startDate);
        dest.writeString(imageName);
        dest.writeString(productName);
        dest.writeString(productQuantity);
        dest.writeInt(subscriptionHoldType);
        dest.writeInt(productType);
        dest.writeTypedList(daySubscriptionModels);
        dest.writeString(endDate);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<PlaceSubscriptionModel> CREATOR = new Creator<PlaceSubscriptionModel>() {
        @Override
        public PlaceSubscriptionModel createFromParcel(Parcel in) {
            return new PlaceSubscriptionModel(in);
        }

        @Override
        public PlaceSubscriptionModel[] newArray(int size) {
            return new PlaceSubscriptionModel[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getSubscriptionType() {
        return subscriptionType;
    }

    public void setSubscriptionType(int subscriptionType) {
        this.subscriptionType = subscriptionType;
    }

    public int getAddressId() {
        return addressId;
    }

    public void setAddressId(int addressId) {
        this.addressId = addressId;
    }

    public int getIsRepeatWeekly() {
        return isRepeatWeekly;
    }

    public void setIsRepeatWeekly(int isRepeatWeekly) {
        this.isRepeatWeekly = isRepeatWeekly;
    }

    public int getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(int productPrice) {
        this.productPrice = productPrice;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public ArrayList<DaySubscriptionModel> getDaySubscriptionModels() {
        return daySubscriptionModels;
    }

    public void setDaySubscriptionModels(ArrayList<DaySubscriptionModel> daySubscriptionModels) {
        this.daySubscriptionModels = daySubscriptionModels;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductQuantity() {
        return productQuantity;
    }

    public void setProductQuantity(String productQuantity) {
        this.productQuantity = productQuantity;
    }

    public int getSubscriptionHoldType() {
        return subscriptionHoldType;
    }

    public void setSubscriptionHoldType(int subscriptionHoldType) {
        this.subscriptionHoldType = subscriptionHoldType;
    }

    public int getProductType() {
        return productType;
    }

    public void setProductType(int productType) {
        this.productType = productType;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
}
