package com.app.xervepure.dao;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.app.xervepure.constants.DbConstants;


/**
 * Created by Codeslay-03 on 6/13/2017.
 */

public class VyaanSQLiteHelper extends SQLiteOpenHelper implements DbConstants {

    public static final String TAG = "SQLite";

    public VyaanSQLiteHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        //super(context, Environment.getExternalStorageDirectory() + File.separator + "Saheli/"+DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        try {

            try {
                dropTable(database, TABLE_USER_TRANSACTION);
                database.execSQL(CREATE_TABLE_USER_TRANSACTION);
            } catch (Exception e) {
                Log.e(TAG + "" + TABLE_USER_TRANSACTION, e.getMessage());
            }

        } catch (SQLException e) {
            Log.e(TAG, e.getMessage());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(db);
    }

    private void dropTable(SQLiteDatabase db, String tableName) {
        String query;
        try {
            query = "DROP TABLE IF EXISTS " + tableName;
            db.execSQL(query);
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
    }


    // Table creation sql statement
    private static final String CREATE_TABLE_USER_TRANSACTION = "CREATE TABLE IF NOT EXISTS " + TABLE_USER_TRANSACTION + "(" +
            "transaction_id      TEXT PRIMARY KEY, " +
            "user_id             NUMBER, " +
            "balance             TEXT, " +
            "checksumhash        TEXT, " +
            "payment_method      NUMBER)";

}
