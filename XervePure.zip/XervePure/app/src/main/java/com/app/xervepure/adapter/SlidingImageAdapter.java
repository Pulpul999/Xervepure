package com.app.xervepure.adapter;

import android.app.Activity;

import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;


import com.app.xervepure.R;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.model.BannerImageModel;
import com.app.xervepure.utils.DeviceUtils;
import com.app.xervepure.widgets.RoundedCornersTransform;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by GARIMA on 9/14/2017.
 */

public class SlidingImageAdapter extends PagerAdapter implements AppConstants {
    private ArrayList<BannerImageModel> bannerImageModels;
    private LayoutInflater inflater;
    Activity currentActivity;
    Bundle bundle;


    public SlidingImageAdapter(Activity currentActivity, ArrayList<BannerImageModel> bannerImageList) {
        this.currentActivity = currentActivity;
        this.bannerImageModels = bannerImageList;
        inflater = LayoutInflater.from(currentActivity);
    }


    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public int getCount() {
        return bannerImageModels.size();
    }

    @Override
    public Object instantiateItem(ViewGroup view, final int position) {
        View imageLayout = inflater.inflate(R.layout.slidingimages_layout, view, false);

        assert imageLayout != null;
        final ImageView imageView = (ImageView) imageLayout
                .findViewById(R.id.image);


        if (bannerImageModels.get(position) != null || bannerImageModels.size() > position) {
            String imageUrl = AppConstants.BASE_URL_IMAGES + "/" + bannerImageModels.get(position).getImage();

            Picasso.with(currentActivity).load(imageUrl).transform(new RoundedCornersTransform(DeviceUtils.convertDpToPixel(3.5f,currentActivity),
                    DeviceUtils.convertDpToPixel(3.5f,currentActivity))).placeholder(R.drawable.applogo).error(R.drawable.applogo).into(imageView);

        }

        view.addView(imageLayout, 0);
        imageLayout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (bundle == null) {
                    bundle = new Bundle();
                }
                /*if (!(bannerImageModels.get(position).getIsCommingSoon().equalsIgnoreCase(IS_COMINGSOON))) {
                    bundle.putParcelable(PRODUCT_DETAILS, productList.get(position));
                    ((BaseActivity) currentActivity).startActivity(currentActivity, ProductDetailsActivity.class, bundle, true, AppConstants.REQUEST_TAG_NO_RESULT, true, ANIMATION_SLIDE_UP);
                } else {
                    ((BaseActivity) currentActivity).alert(currentActivity, ((BaseActivity) currentActivity).getString(R.string.alert_product_coming_soon), ((BaseActivity) currentActivity).getString(R.string.alert_product_coming_soon), ((BaseActivity) currentActivity).getString(R.string.labelOk), ((BaseActivity) currentActivity).getString(R.string.labelCancel), false, false, ALERT_TYPE_NO_NETWORK);
                }*/

            }
        });


        return imageLayout;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view.equals(object);
    }

    @Override
    public void restoreState(Parcelable state, ClassLoader loader) {
    }

    @Override
    public Parcelable saveState() {
        return null;
    }
}
