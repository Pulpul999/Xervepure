package com.app.xervepure.activity;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.app.xervepure.R;
import com.app.xervepure.adapter.ProductDetailAdapter;
import com.app.xervepure.application.VyaanApplication;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.model.AddCartModel;
import com.app.xervepure.model.CartModel;
import com.app.xervepure.model.DaySubscriptionModel;
import com.app.xervepure.model.PlaceSubscriptionModel;
import com.app.xervepure.model.ProductDetailModel;
import com.app.xervepure.model.ProductModel;
import com.app.xervepure.model.RequestModel;
import com.app.xervepure.utils.DeviceUtils;
import com.app.xervepure.utils.FontUtils;
import com.app.xervepure.utils.SharedPreferenceUtils;
import com.app.xervepure.utils.Validator;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class ProductDetailsActivity extends BaseActivity {

    private ProductModel productModel;
    private RecyclerView productDetailRecyclerView;
    private ProductDetailAdapter productsAdapter;
    private ArrayList<ProductDetailModel> productDetailModelArrayList;

    private int noOfItems;
    private View menuView;
    private TextView textNoOfItemsInCart;

    /* subscription dialog start*/

    private ImageView productImageView;
    private TextView productNameTextView;
    private TextView productQuantityTextView;
    private TextView rupeesTextView;

    private LinearLayout everydayLL;
    private ImageView everydayIV;
    private TextView everydayTV;

    private LinearLayout alternateDayLL;
    private ImageView alternateDayIV;
    private TextView alternateDayTV;

    private LinearLayout customizeLL;
    private ImageView customizeIV;
    private TextView customizeTV;

    private ImageView plusImageView;
    private ImageView minusImageView;
    private TextView numberOfProductTV;

    private LinearLayout repeatweeklyLL;
    private ImageView repeatweeklyIV;
    private TextView repeatweeklyTV;

    private TextView lblStartTV;
    private TextView dateTextView;
    private TextView endDateTextView;

    private CardView startDateCV;
    private CardView endDateCV;
    private LinearLayout weekDaysLL;
    private TextView sundayTextView;
    private TextView sundayQuantityTextView;
    private TextView mondayTextVIew;
    private TextView mondayQuantityTextView;
    private TextView tuesdayTextView;
    private TextView tuesdayQuantityTextView;
    private TextView wensdayTextView;
    private TextView wenesdayQuantityTextView;
    private TextView thursdayTextView;
    private TextView thrusdayQuantityTextView;
    private TextView fridayTextView;
    private TextView fridayQuantityTextView;
    private TextView saturdayTextView;
    private TextView saturdayQuantityTextView;

    private Button btnConfrimSubscription;

    /* subscription dialog end*/

    private ProductDetailModel productDetailModel;
    private int subscriptionType = TYPE_SUBSCRIPTION_EVERYDAY;
    private boolean isRepeatWeekly;
    private Calendar mCalendar;
    private Calendar tomorrowCalendar;
    private Dialog dialog;
    private String productQuantityCount;
    private int dayArray[];
    private int arrayPossition = -1;
    private PlaceSubscriptionModel subscriptionModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details2);
    }

    @Override
    protected void initViews() {
        isRepeatWeekly = true;
        mCalendar = Calendar.getInstance();
        dayArray = new int[7];
        if (getIntent().getExtras() != null)
            productModel = getIntent().getExtras().getParcelable(PRODUCT_DETAILS);
        getSupportActionBar().setTitle(productModel.getName());
        productDetailRecyclerView = (RecyclerView) findViewById(R.id.productRecyclerView);
        productDetailModelArrayList = new ArrayList<>();
        getProductDetailList(productModel.getId());
        setProductDetailRecyclerView();
    }

    @Override
    protected void initContext() {
        context = this;
        currentActivity = ProductDetailsActivity.this;


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.item_dashboard, menu);
        menuView = menu.findItem(R.id.action_cart).getActionView();
        textNoOfItemsInCart = (TextView) menuView.findViewById(R.id.textNoOfItemsInCart);
        RelativeLayout containetCartItems = (RelativeLayout) menuView.findViewById(R.id.containetCartItems);
        noOfItems = SharedPreferenceUtils.getInstance(context).getInteger(CART_ITEM_COUNT);
        if (noOfItems > 0)
            textNoOfItemsInCart.setText("" + noOfItems);

        containetCartItems.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((BaseActivity) currentActivity).startActivity(currentActivity, CartActivity.class, bundle, false, REQUEST_TAG_NO_RESULT, true, ANIMATION_SLIDE_LEFT);

            }
        });
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Log.e("cart click ", "mainboard");
        switch (item.getItemId()) {
            case R.id.action_cart: {
                Log.e("cart click ", "minboard");
                ((BaseActivity) currentActivity).startActivity(currentActivity, CartActivity.class, bundle, false, REQUEST_TAG_NO_RESULT, true, ANIMATION_SLIDE_LEFT);

                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    protected void initListners() {
        productsAdapter.setOnItemClickListener(new ProductDetailAdapter.RecyclerClickListner() {
            @Override
            public void onItemClick(int position, View v, TextView quantityTextView, TextView rupeesTextView) {
                if (productDetailModelArrayList != null && productDetailModelArrayList.size() > position) {
                    productDetailModel = productDetailModelArrayList.get(position);
                }
                switch (v.getId()) {
                    case R.id.addCartTextView: {
                        if (productDetailModel != null) {
                            productQuantityCount = quantityTextView.getText().toString();
                            AddCartModel cartModel = new AddCartModel();
                            cartModel.setUserId(SharedPreferenceUtils.getInstance(context).getInteger(AppConstants.USER_ID));
                            if (!TextUtils.isEmpty(productQuantityCount)) {
                                cartModel.setProductQuantity(Integer.parseInt(productQuantityCount));
                            }
                            cartModel.setProductId(productDetailModel.getId());
                            addProductToCart(cartModel);
                        }
                        break;
                    }
                    case R.id.sampleButton: {
                        if (productDetailModel == null) return;

                        String walletBalance = SharedPreferenceUtils.getInstance(context).getString(USER_WALLET_BALANCE);
                        if (!TextUtils.isEmpty(walletBalance) && !TextUtils.isEmpty(rupeesTextView.getText().toString())) {
                            Double totalBalance = Double.parseDouble(walletBalance);
                            if (totalBalance < Integer.parseInt(rupeesTextView.getText().toString())) {
                                alert(currentActivity, getString(R.string.alert_low_balance), getString(R.string.msg_low_balance), getResources().getString(R.string.alert_add_amount), getResources().getString(R.string.alert_cancel_button_text_no_network), true, true, ALERT_TYPE_ADD_AMOUNT);
                                return;
                            }
                        } else {
                            alert(currentActivity, getString(R.string.alert_low_balance), getString(R.string.msg_low_balance), getResources().getString(R.string.alert_add_amount), getResources().getString(R.string.alert_cancel_button_text_no_network), true, true, ALERT_TYPE_ADD_AMOUNT);
                            return;
                        }

                        CartModel cartModel = new CartModel();
                        cartModel.setProductId(productDetailModel.getId());
                        cartModel.setProductPrice(Integer.parseInt(rupeesTextView.getText().toString()));
                        cartModel.setProductQuantity(1);
                        ArrayList<CartModel> cartModelList = new ArrayList<CartModel>();
                        cartModelList.add(cartModel);
                        if (bundle == null) {
                            bundle = new Bundle();
                        }
                        bundle.putInt("order_type", TYPE_ORDER_SAMPLE);
                        bundle.putParcelableArrayList(CART_MODEL_LIST, cartModelList);
                        startActivity(currentActivity, AllAddressesActivity.class, bundle, false, REQUEST_TAG_NO_RESULT, true, ANIMATION_SLIDE_LEFT);
                        break;
                    }
                    case R.id.subscribeTextView: {
                        if (productDetailModel == null) return;
                        if (productDetailModel.getIsProductSubscribed() == 1) {
                            ((BaseActivity) currentActivity).alert(currentActivity, currentActivity.getString(R.string.titleAlreadySubscribed), currentActivity.getString(R.string.messageSubscriptionExist), currentActivity.getString(R.string.labelOk), currentActivity.getString(R.string.labelCancel), false, true, AppConstants.ALERT_TYPE_NO_NETWORK);
                            return;
                        }
                        productQuantityCount = quantityTextView.getText().toString();

                        if (bundle == null) {
                            bundle = new Bundle();
                        }
                        bundle.putParcelable(PRODUCT_MODEL, productDetailModel);
                        bundle.putString("productQuantityCount", productQuantityCount);
                        startActivity(currentActivity, SubscriptionActivity.class, bundle, false, REQUEST_TAG_NO_RESULT, true, ANIMATION_SLIDE_LEFT);


                        //showSubscriptionDialog();
                        break;
                    }
                }
            }

            @Override
            public void onItemLongClick(int position, View v) {

            }
        });
    }

    @Override
    protected boolean isActionBar() {
        return true;
    }

    @Override
    protected boolean isHomeButton() {
        return true;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.everydayLL: {

                int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.95);
                int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.67);
                dialog.getWindow().setLayout(width, height);
                isRepeatWeekly = true;
                weekDaysLL.setVisibility(View.GONE);
                repeatweeklyLL.setVisibility(View.GONE);
                subscriptionType = TYPE_SUBSCRIPTION_EVERYDAY;
                everydayIV.setImageResource(R.drawable.radio_selected_btn);
                alternateDayIV.setImageResource(R.drawable.radio_unselected_btn);
                customizeIV.setImageResource(R.drawable.radio_unselected_btn);
                numberOfProductTV.setText(productQuantityCount);
                break;
            }
            case R.id.alternateDayLL: {

                int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.95);
                int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.76);
                dialog.getWindow().setLayout(width, height);

                weekDaysLL.setVisibility(View.GONE);
                repeatweeklyLL.setVisibility(View.GONE);
                subscriptionType = TYPE_SUBSCRIPTION_ALTERNATEDAY;
                everydayIV.setImageResource(R.drawable.radio_unselected_btn);
                alternateDayIV.setImageResource(R.drawable.radio_selected_btn);
                customizeIV.setImageResource(R.drawable.radio_unselected_btn);
                numberOfProductTV.setText(productQuantityCount);
                break;
            }
            case R.id.customizeLL: {
                for (int i = 0; i < dayArray.length; i++) {
                    dayArray[i] = 0;
                }
                int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.95);
                int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.9);
                dialog.getWindow().setLayout(width, height);

                weekDaysLL.setVisibility(View.VISIBLE);
                repeatweeklyLL.setVisibility(View.GONE);
                subscriptionType = TYPE_SUBSCRIPTION_CUSTOMIZE;
                everydayIV.setImageResource(R.drawable.radio_unselected_btn);
                alternateDayIV.setImageResource(R.drawable.radio_unselected_btn);
                customizeIV.setImageResource(R.drawable.radio_selected_btn);
                numberOfProductTV.setText("0");
                break;
            }
            case R.id.repeatweeklyLL: {
                if (isRepeatWeekly) {
                    isRepeatWeekly = false;
                    repeatweeklyIV.setImageResource(R.drawable.check_box_unselected_btn);
                } else {
                    isRepeatWeekly = true;
                    repeatweeklyIV.setImageResource(R.drawable.check_box_selected_btn);
                }
                break;
            }
            case R.id.plusImageView: {
                int count = 0;
                if (!TextUtils.isEmpty(numberOfProductTV.getText().toString())) {
                    count = Integer.parseInt(numberOfProductTV.getText().toString());
                }
                ++count;
                if (subscriptionType == TYPE_SUBSCRIPTION_CUSTOMIZE) {
                    if (arrayPossition < 0) {
                        return;
                    }
                    setDayWiseQuantity(count);
                }
                numberOfProductTV.setText(count + "");
                productQuantityCount = count+"";
                break;
            }
            case R.id.minusImageView: {

                int count = 0;
                if (!TextUtils.isEmpty(numberOfProductTV.getText().toString())) {
                    count = Integer.parseInt(numberOfProductTV.getText().toString());
                }
                --count;
                if (subscriptionType == TYPE_SUBSCRIPTION_CUSTOMIZE) {
                    if (count < 0) return;
                    if (arrayPossition < 0) {
                        return;
                    }
                    setDayWiseQuantity(count);
                } else {
                    int minQuantity = 0;
                    if (productDetailModel.getProductType() == PRODUCT_TYPE_MILK) {
                        minQuantity = MILK_MIN_ORDER_QTY;
                    } else {
                        minQuantity = OTHER_MIN_ORDER_QTY;
                    }
                    if (count < minQuantity) return;
                }
                numberOfProductTV.setText(count + "");
                productQuantityCount = count+"";
                break;
            }
            case R.id.startDateCV: {
                toOpenDatePicker();
                break;
            }
            case R.id.endDateCV: {
                toOpenDatePicker();
                break;
            }
            case R.id.sundayTextView: {
                numberOfProductTV.setText("0");
                arrayPossition = 0;
                sundayTextView.setBackgroundResource(R.drawable.rounded_textview);
                sundayTextView.setTextColor(Color.WHITE);
                mondayTextVIew.setBackgroundResource(0);
                mondayTextVIew.setTextColor(mondayQuantityTextView.getTextColors());
                tuesdayTextView.setBackgroundResource(0);
                tuesdayTextView.setTextColor(tuesdayQuantityTextView.getTextColors());
                wensdayTextView.setBackgroundResource(0);
                wensdayTextView.setTextColor(wenesdayQuantityTextView.getTextColors());
                thursdayTextView.setBackgroundResource(0);
                thursdayTextView.setTextColor(thrusdayQuantityTextView.getTextColors());
                fridayTextView.setBackgroundResource(0);
                fridayTextView.setTextColor(fridayQuantityTextView.getTextColors());
                saturdayTextView.setBackgroundResource(0);
                saturdayTextView.setTextColor(saturdayQuantityTextView.getTextColors());
                break;
            }
            case R.id.mondayTextVIew: {
                numberOfProductTV.setText("0");
                arrayPossition = 1;
                sundayTextView.setBackgroundResource(0);
                sundayTextView.setTextColor(sundayQuantityTextView.getTextColors());
                mondayTextVIew.setBackgroundResource(R.drawable.rounded_textview);
                mondayTextVIew.setTextColor(Color.WHITE);
                tuesdayTextView.setBackgroundResource(0);
                tuesdayTextView.setTextColor(tuesdayQuantityTextView.getTextColors());
                wensdayTextView.setBackgroundResource(0);
                wensdayTextView.setTextColor(wenesdayQuantityTextView.getTextColors());
                thursdayTextView.setBackgroundResource(0);
                thursdayTextView.setTextColor(thrusdayQuantityTextView.getTextColors());
                fridayTextView.setBackgroundResource(0);
                fridayTextView.setTextColor(fridayQuantityTextView.getTextColors());
                saturdayTextView.setBackgroundResource(0);
                saturdayTextView.setTextColor(saturdayQuantityTextView.getTextColors());
                break;
            }
            case R.id.tuesdayTextView: {
                numberOfProductTV.setText("0");
                arrayPossition = 2;
                sundayTextView.setBackgroundResource(0);
                sundayTextView.setTextColor(sundayQuantityTextView.getTextColors());
                mondayTextVIew.setBackgroundResource(0);
                mondayTextVIew.setTextColor(mondayQuantityTextView.getTextColors());
                tuesdayTextView.setBackgroundResource(R.drawable.rounded_textview);
                tuesdayTextView.setTextColor(Color.WHITE);
                wensdayTextView.setBackgroundResource(0);
                wensdayTextView.setTextColor(wenesdayQuantityTextView.getTextColors());
                thursdayTextView.setBackgroundResource(0);
                thursdayTextView.setTextColor(thrusdayQuantityTextView.getTextColors());
                fridayTextView.setBackgroundResource(0);
                fridayTextView.setTextColor(fridayQuantityTextView.getTextColors());
                saturdayTextView.setBackgroundResource(0);
                saturdayTextView.setTextColor(saturdayQuantityTextView.getTextColors());
                break;
            }
            case R.id.wensdayTextView: {
                numberOfProductTV.setText("0");
                arrayPossition = 3;
                sundayTextView.setBackgroundResource(0);
                sundayTextView.setTextColor(sundayQuantityTextView.getTextColors());
                mondayTextVIew.setBackgroundResource(0);
                mondayTextVIew.setTextColor(mondayQuantityTextView.getTextColors());
                tuesdayTextView.setBackgroundResource(0);
                tuesdayTextView.setTextColor(tuesdayQuantityTextView.getTextColors());
                wensdayTextView.setBackgroundResource(R.drawable.rounded_textview);
                wensdayTextView.setTextColor(Color.WHITE);
                thursdayTextView.setBackgroundResource(0);
                thursdayTextView.setTextColor(thrusdayQuantityTextView.getTextColors());
                fridayTextView.setBackgroundResource(0);
                fridayTextView.setTextColor(fridayQuantityTextView.getTextColors());
                saturdayTextView.setBackgroundResource(0);
                saturdayTextView.setTextColor(saturdayQuantityTextView.getTextColors());
                break;
            }
            case R.id.thursdayTextView: {
                numberOfProductTV.setText("0");
                arrayPossition = 4;
                sundayTextView.setBackgroundResource(0);
                sundayTextView.setTextColor(sundayQuantityTextView.getTextColors());
                mondayTextVIew.setBackgroundResource(0);
                mondayTextVIew.setTextColor(mondayQuantityTextView.getTextColors());
                tuesdayTextView.setBackgroundResource(0);
                tuesdayTextView.setTextColor(tuesdayQuantityTextView.getTextColors());
                wensdayTextView.setBackgroundResource(0);
                wensdayTextView.setTextColor(wenesdayQuantityTextView.getTextColors());
                thursdayTextView.setBackgroundResource(R.drawable.rounded_textview);
                thursdayTextView.setTextColor(Color.WHITE);
                fridayTextView.setBackgroundResource(0);
                fridayTextView.setTextColor(fridayQuantityTextView.getTextColors());
                saturdayTextView.setBackgroundResource(0);
                saturdayTextView.setTextColor(saturdayQuantityTextView.getTextColors());
                break;
            }
            case R.id.fridayTextView: {
                numberOfProductTV.setText("0");
                arrayPossition = 5;
                sundayTextView.setBackgroundResource(0);
                sundayTextView.setTextColor(sundayQuantityTextView.getTextColors());
                mondayTextVIew.setBackgroundResource(0);
                mondayTextVIew.setTextColor(mondayQuantityTextView.getTextColors());
                tuesdayTextView.setBackgroundResource(0);
                tuesdayTextView.setTextColor(tuesdayQuantityTextView.getTextColors());
                wensdayTextView.setBackgroundResource(0);
                wensdayTextView.setTextColor(wenesdayQuantityTextView.getTextColors());
                thursdayTextView.setBackgroundResource(0);
                thursdayTextView.setTextColor(thrusdayQuantityTextView.getTextColors());
                fridayTextView.setBackgroundResource(R.drawable.rounded_textview);
                fridayTextView.setTextColor(Color.WHITE);
                saturdayTextView.setBackgroundResource(0);
                saturdayTextView.setTextColor(saturdayQuantityTextView.getTextColors());
                break;
            }
            case R.id.saturdayTextView: {
                numberOfProductTV.setText("0");
                arrayPossition = 6;
                sundayTextView.setBackgroundResource(0);
                sundayTextView.setTextColor(sundayQuantityTextView.getTextColors());
                mondayTextVIew.setBackgroundResource(0);
                mondayTextVIew.setTextColor(mondayQuantityTextView.getTextColors());
                tuesdayTextView.setBackgroundResource(0);
                tuesdayTextView.setTextColor(tuesdayQuantityTextView.getTextColors());
                wensdayTextView.setBackgroundResource(0);
                wensdayTextView.setTextColor(wenesdayQuantityTextView.getTextColors());
                thursdayTextView.setBackgroundResource(0);
                thursdayTextView.setTextColor(thrusdayQuantityTextView.getTextColors());
                fridayTextView.setBackgroundResource(0);
                fridayTextView.setTextColor(fridayQuantityTextView.getTextColors());
                saturdayTextView.setBackgroundResource(R.drawable.rounded_textview);
                saturdayTextView.setTextColor(Color.WHITE);
                break;
            }
            case R.id.btnConfrimSubscription: {
                if (subscriptionType == TYPE_SUBSCRIPTION_CUSTOMIZE) {
                    int minQuantity = 0;
                    if (productDetailModel.getProductType() == PRODUCT_TYPE_MILK) {
                        minQuantity = MILK_MIN_ORDER_QTY;
                    } else {
                        minQuantity = OTHER_MIN_ORDER_QTY;
                    }
                    int qtyCount = 0;
                    for (int i = 0; i < dayArray.length; i++) {
                        qtyCount = dayArray[i];
                        if (qtyCount > 0) break;
                    }

                    if (qtyCount == 0) {
                        alert(currentActivity, "", getString(R.string.message_singel_day_subscription), getResources().getString(R.string.alert_ok_button_text_no_network), getResources().getString(R.string.alert_cancel_button_text_no_network), false, false, ALERT_TYPE_NO_NETWORK);
                        return;
                    }

                    for (int i = 0; i < dayArray.length; i++) {
                        qtyCount = dayArray[i];
                        if (qtyCount < minQuantity) {
                            if (qtyCount != 0) {
                                String message = getString(R.string.message_min_qty);
                                message.replace("2", "" + minQuantity);
                                alert(currentActivity, "", message, getResources().getString(R.string.alert_ok_button_text_no_network), getResources().getString(R.string.alert_cancel_button_text_no_network), false, false, ALERT_TYPE_NO_NETWORK);
                                return;
                            }
                        }
                    }

                }

                if (Validator.isNetworkAvailable(currentActivity)) {
                    initSubscriptionModel();
                    if (bundle == null) {
                        bundle = new Bundle();
                    }
                    bundle.putParcelable(SUBSCRIPTION_MODEL, subscriptionModel);
                    bundle.putBoolean(SUBSCRIPTION, true);
                    startActivity(currentActivity, AllAddressesActivity.class, bundle, false, REQUEST_TAG_NO_RESULT, true, ANIMATION_SLIDE_LEFT);
                } else {
                    alert(currentActivity, getString(R.string.alert_message_no_network), getString(R.string.alert_message_no_network), getString(R.string.labelOk), getString(R.string.labelCancel), false, false, ALERT_TYPE_NO_NETWORK);

                }
                break;
            }
        }

    }

    @Override
    public void onAlertClicked(int alertType) {

    }

    private void setDayWiseQuantity(int count) {
        dayArray[arrayPossition] = count;
        switch (arrayPossition) {
            case 0: {
                sundayQuantityTextView.setText("" + count);
                if (count == 0) {
                    sundayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                } else {
                    sundayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                }
                break;
            }
            case 1: {
                mondayQuantityTextView.setText("" + count);
                if (count == 0) {
                    mondayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                } else {
                    mondayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                }
                break;
            }
            case 2: {
                tuesdayQuantityTextView.setText("" + count);
                if (count == 0) {
                    tuesdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                } else {
                    tuesdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                }
                break;
            }
            case 3: {
                wenesdayQuantityTextView.setText("" + count);
                if (count == 0) {
                    wenesdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                } else {
                    wenesdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                }
                break;
            }
            case 4: {
                thrusdayQuantityTextView.setText("" + count);
                if (count == 0) {
                    thrusdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                } else {
                    thrusdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                }
                break;
            }
            case 5: {
                fridayQuantityTextView.setText("" + count);
                if (count == 0) {
                    fridayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                } else {
                    fridayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                }
                break;
            }
            case 6: {
                saturdayQuantityTextView.setText("" + count);
                if (count == 0) {
                    saturdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                } else {
                    saturdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                }
                break;
            }

        }
    }


    private void showSubscriptionDialog() {

        View customView = currentActivity.getLayoutInflater().inflate(R.layout.subscription_dialog, null);
        dialog = new Dialog(currentActivity, R.style.CustomDialog);
        dialog.setContentView(customView);
        int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.95);
        int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.67);
        dialog.getWindow().setLayout(width, height);

        initSubscribeViews(customView);
        dialog.show();
    }

    private void initSubscribeViews(View customView) {
        productImageView = (ImageView) customView.findViewById(R.id.productImageView);
        productNameTextView = (TextView) customView.findViewById(R.id.productNameTextView);
        productQuantityTextView = (TextView) customView.findViewById(R.id.productQuantityTextView);
        rupeesTextView = (TextView) customView.findViewById(R.id.rupeesTextView);

        everydayLL = (LinearLayout) customView.findViewById(R.id.everydayLL);
        everydayIV = (ImageView) customView.findViewById(R.id.everydayIV);
        everydayTV = (TextView) customView.findViewById(R.id.everydayTV);

        alternateDayLL = (LinearLayout) customView.findViewById(R.id.alternateDayLL);
        alternateDayIV = (ImageView) customView.findViewById(R.id.alternateDayIV);
        alternateDayTV = (TextView) customView.findViewById(R.id.alternateDayTV);

        customizeLL = (LinearLayout) customView.findViewById(R.id.customizeLL);
        customizeIV = (ImageView) customView.findViewById(R.id.customizeIV);
        customizeTV = (TextView) customView.findViewById(R.id.customizeTV);

        plusImageView = (ImageView) customView.findViewById(R.id.plusImageView);
        minusImageView = (ImageView) customView.findViewById(R.id.minusImageView);
        numberOfProductTV = (TextView) customView.findViewById(R.id.numberOfProductTV);

        repeatweeklyLL = (LinearLayout) customView.findViewById(R.id.repeatweeklyLL);
        repeatweeklyIV = (ImageView) customView.findViewById(R.id.repeatweeklyIV);
        repeatweeklyTV = (TextView) customView.findViewById(R.id.repeatweeklyTV);

        lblStartTV = (TextView) customView.findViewById(R.id.lblStartTV);
        dateTextView = (TextView) customView.findViewById(R.id.dateTextView);
        endDateTextView = customView.findViewById(R.id.endDateTextView);
        startDateCV = (CardView) customView.findViewById(R.id.startDateCV);
        endDateCV = customView.findViewById(R.id.endDateCV);
        weekDaysLL = (LinearLayout) customView.findViewById(R.id.weekDaysLL);
        sundayTextView = (TextView) customView.findViewById(R.id.sundayTextView);
        sundayQuantityTextView = (TextView) customView.findViewById(R.id.sundayQuantityTextView);
        mondayTextVIew = (TextView) customView.findViewById(R.id.mondayTextVIew);
        mondayQuantityTextView = (TextView) customView.findViewById(R.id.mondayQuantityTextView);
        tuesdayTextView = (TextView) customView.findViewById(R.id.tuesdayTextView);
        tuesdayQuantityTextView = (TextView) customView.findViewById(R.id.tuesdayQuantityTextView);
        wensdayTextView = (TextView) customView.findViewById(R.id.wensdayTextView);
        wenesdayQuantityTextView = (TextView) customView.findViewById(R.id.wenesdayQuantityTextView);
        thursdayTextView = (TextView) customView.findViewById(R.id.thursdayTextView);
        thrusdayQuantityTextView = (TextView) customView.findViewById(R.id.thrusdayQuantityTextView);
        fridayTextView = (TextView) customView.findViewById(R.id.fridayTextView);
        fridayQuantityTextView = (TextView) customView.findViewById(R.id.fridayQuantityTextView);
        saturdayTextView = (TextView) customView.findViewById(R.id.saturdayTextView);
        saturdayQuantityTextView = (TextView) customView.findViewById(R.id.saturdayQuantityTextView);

        btnConfrimSubscription = (Button) customView.findViewById(R.id.btnConfrimSubscription);

        FontUtils.changeFont(currentActivity, productNameTextView, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, productQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, rupeesTextView, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, everydayTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, alternateDayTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, customizeTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, numberOfProductTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, repeatweeklyTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, lblStartTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, dateTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, endDateTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, sundayTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, sundayQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, mondayTextVIew, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, mondayQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, tuesdayTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, tuesdayQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, wensdayTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, wenesdayQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, thursdayTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, thrusdayQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, fridayTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, fridayQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, saturdayTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, saturdayQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, btnConfrimSubscription, AppConstants.FONT_ROBOTO_MEDIUM);

        everydayLL.setOnClickListener(this);
        alternateDayLL.setOnClickListener(this);
        customizeLL.setOnClickListener(this);
        plusImageView.setOnClickListener(this);
        minusImageView.setOnClickListener(this);
        repeatweeklyLL.setOnClickListener(this);
        startDateCV.setOnClickListener(this);
        endDateCV.setOnClickListener(this);
        weekDaysLL.setOnClickListener(this);
        sundayTextView.setOnClickListener(this);
        mondayTextVIew.setOnClickListener(this);
        tuesdayTextView.setOnClickListener(this);
        wensdayTextView.setOnClickListener(this);
        thursdayTextView.setOnClickListener(this);
        fridayTextView.setOnClickListener(this);
        saturdayTextView.setOnClickListener(this);
        btnConfrimSubscription.setOnClickListener(this);
        setTextOnViews();
    }

    private void setTextOnViews() {
        if (productDetailModel == null) return;
        String imageUrl = AppConstants.BASE_URL_IMAGES + "/" + productDetailModel.getImage();
        Picasso.with(currentActivity).load(imageUrl).into(productImageView);
        productNameTextView.setText(productDetailModel.getName());
        productQuantityTextView.setText(productDetailModel.getQuantity());
        rupeesTextView.setText(productDetailModel.getPrice());
        numberOfProductTV.setText(productQuantityCount);

        String timeToCompare = SUBSCRIPTION_MAX_TIME;
        boolean isLate = checkTimeOutOrNot(timeToCompare);

        tomorrowCalendar = Calendar.getInstance();
        if (isLate) {
            tomorrowCalendar.add(Calendar.DAY_OF_YEAR, 2);
        } else {
            tomorrowCalendar.add(Calendar.DAY_OF_YEAR, 1);
        }
        Date tomorrow = tomorrowCalendar.getTime();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String tomorrowDate = sdf.format(tomorrow);
        dateTextView.setText(tomorrowDate);

    }

    public static boolean checkTimeOutOrNot(String time) {
        boolean timeOutOrNot = false;
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(time.substring(0, 2)));
        cal.set(Calendar.MINUTE, Integer.parseInt(time.substring(3)));
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (Calendar.getInstance().after(cal)) {
            timeOutOrNot = true;
        }
        return timeOutOrNot;
    }

    private void toOpenDatePicker() {
        int year = mCalendar.get(Calendar.YEAR);
        int month = mCalendar.get(Calendar.MONTH);
        int day = mCalendar.get(Calendar.DAY_OF_MONTH);
        String selectedDate = dateTextView.getText().toString();
        if (!TextUtils.isEmpty(selectedDate)) {
            String yearString = selectedDate.substring(6, 10);
            String monthString = selectedDate.substring(3, 5);
            String dayString = selectedDate.substring(0, 2);
            year = Integer.parseInt(yearString);
            month = Integer.parseInt(monthString);
            day = Integer.parseInt(dayString);
            month--;
        }
        DatePickerDialog dpDialog = new DatePickerDialog(currentActivity, subscriptionDate, year, month, day);
        dpDialog.updateDate(year, month, day);
        dpDialog.getDatePicker().setMinDate(tomorrowCalendar.getTimeInMillis());
        dpDialog.show();
    }

    DatePickerDialog.OnDateSetListener subscriptionDate = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            Calendar mCalendar = Calendar.getInstance();
            mCalendar.set(Calendar.YEAR, year);
            mCalendar.set(Calendar.MONTH, monthOfYear);
            mCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            String myFormat = "dd/MM/yyyy";
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
            dateTextView.setText(sdf.format(mCalendar.getTime()));
        }
    };

    private void initSubscriptionModel() {
        subscriptionModel = new PlaceSubscriptionModel();
        subscriptionModel.setUserId(SharedPreferenceUtils.getInstance(context).getInteger(USER_ID));
        subscriptionModel.setProductId(productDetailModel.getId());
        subscriptionModel.setSubscriptionType(subscriptionType);
        subscriptionModel.setIsRepeatWeekly(isRepeatWeekly ? 1 : 0);
        subscriptionModel.setStartDate(dateTextView.getText().toString());
        if (!TextUtils.isEmpty(productDetailModel.getPrice())) {
            subscriptionModel.setProductPrice(Integer.parseInt(productDetailModel.getPrice()));
        } else {
            subscriptionModel.setProductPrice(0);
        }
        ArrayList<DaySubscriptionModel> daySubscriptionModels = new ArrayList<>();

        if (subscriptionType == TYPE_SUBSCRIPTION_ALTERNATEDAY) {
            int dayOfWeek = 0;
            Date date = null;
            SimpleDateFormat inFormat = new SimpleDateFormat("dd/MM/yyyy");
            try {
                date = inFormat.parse(dateTextView.getText().toString());
                Calendar c = Calendar.getInstance();
                c.setTime(date);
                dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            for (int i = 0; i < 7; i++) {
                DaySubscriptionModel daySubscriptionModel = new DaySubscriptionModel();
                int day = 0;
                if (dayOfWeek > 7) {
                    day = dayOfWeek - 7;
                } else {
                    day = dayOfWeek;
                }
                switch (day) {
                    case 1: {
                        daySubscriptionModel.setDay("Sunday");
                        break;
                    }
                    case 2: {
                        daySubscriptionModel.setDay("Monday");
                        break;
                    }
                    case 3: {
                        daySubscriptionModel.setDay("Tuesday");
                        break;
                    }
                    case 4: {
                        daySubscriptionModel.setDay("Wednesday");
                        break;
                    }
                    case 5: {
                        daySubscriptionModel.setDay("Thursday");
                        break;
                    }
                    case 6: {
                        daySubscriptionModel.setDay("Friday");
                        break;
                    }
                    case 7: {
                        daySubscriptionModel.setDay("Saturday");
                        break;
                    }
                }
                dayOfWeek++;
                if (i % 2 == 0) {
                    daySubscriptionModel.setQuantity(productQuantityCount);
                } else {
                    daySubscriptionModel.setQuantity("0");
                }
                daySubscriptionModels.add(daySubscriptionModel);
            }
            subscriptionModel.setDaySubscriptionModels(daySubscriptionModels);
            return;
        }

        for (int i = 0; i < dayArray.length; i++) {
            DaySubscriptionModel daySubscriptionModel = new DaySubscriptionModel();
            switch (i) {
                case 0: {
                    daySubscriptionModel.setDay("Sunday");
                    break;
                }
                case 1: {
                    daySubscriptionModel.setDay("Monday");
                    break;
                }
                case 2: {
                    daySubscriptionModel.setDay("Tuesday");
                    break;
                }
                case 3: {
                    daySubscriptionModel.setDay("Wednesday");
                    break;
                }
                case 4: {
                    daySubscriptionModel.setDay("Thursday");
                    break;
                }
                case 5: {
                    daySubscriptionModel.setDay("Friday");
                    break;
                }
                case 6: {
                    daySubscriptionModel.setDay("Saturday");
                    break;
                }
            }
            if (subscriptionType == TYPE_SUBSCRIPTION_CUSTOMIZE) {
                daySubscriptionModel.setQuantity(dayArray[i] + "");
            } else if (subscriptionType == TYPE_SUBSCRIPTION_EVERYDAY) {
                daySubscriptionModel.setQuantity(productQuantityCount);
            }
            daySubscriptionModels.add(daySubscriptionModel);
        }
        subscriptionModel.setDaySubscriptionModels(daySubscriptionModels);
    }

    private void toOpenAddressActivity() {

    }


    private void setProductDetailRecyclerView() {
        productsAdapter = new ProductDetailAdapter(currentActivity, productDetailModelArrayList);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        productDetailRecyclerView.setLayoutManager(linearLayoutManager);
        productDetailRecyclerView.setAdapter(productsAdapter);
    }

    private void initRequestModel() {
        RequestModel.getInstance().setDeviceType(DEVICE_TYPE);
        RequestModel.getInstance().setLoginId(SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_MOBILE_NO));
        RequestModel.getInstance().setAccessToken(DeviceUtils.getDeviceKey());
        RequestModel.getInstance().setIpAddress(DeviceUtils.getDeviceIpAddress(context));
    }

    private void getProductDetailList(int id) {

        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);

        initRequestModel();
        JSONObject jsons = null;
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        try {
            jsons = new JSONObject(gson.toJson(RequestModel.getInstance()));
            jsons.put("product_id", id);
            jsons.put("user_id", SharedPreferenceUtils.getInstance(this).getInteger(USER_ID));
            Log.e("getProductDetailList", jsons.toString());
            JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_GET_PRODUCTS_WITH_PARENT_ID, jsons, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {

                    cancelProgressDialog();
                    try {
                        if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                            productDetailModelArrayList.clear();
                            Gson gson = new Gson();
                            List<ProductDetailModel> productsModelListTemp = Arrays.asList(gson.fromJson(response.getJSONArray(MESSAGE).toString(), ProductDetailModel[].class));
                            productDetailModelArrayList.addAll(productsModelListTemp);
                            Log.e("product list size", "" + productDetailModelArrayList.toString());
                            productsAdapter.updateAdapter(productDetailModelArrayList);

                        } else {
                            cancelProgressDialog();
                            ((BaseActivity) currentActivity).logTesting("fetch products error", "true", Log.ERROR);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    cancelProgressDialog();
                    ((BaseActivity) currentActivity).logTesting("error is", error.toString(), Log.ERROR);
                }
            }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> params = new HashMap<String, String>();

                    params.put("Content-Type", "application/json");


                    return params;
                }
            };

            VyaanApplication.getInstance().addToRequestQueue(request);


        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void addProductToCart(AddCartModel addCartModel) {

        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);
        JSONObject jsonAddToCartRequest = null;
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();

        addCartModel.setDeviceType(DEVICE_TYPE);
        addCartModel.setLoginId(SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_MOBILE_NO));
        addCartModel.setAccessToken(DeviceUtils.getDeviceKey());
        addCartModel.setIpAddress(DeviceUtils.getDeviceIpAddress(context));

        try {
            jsonAddToCartRequest = new JSONObject(gson.toJson(addCartModel));
            Log.e("jsonAddToCartRequest", jsonAddToCartRequest.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_ADD_TO_CART, jsonAddToCartRequest, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                cancelProgressDialog();
                try {
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                        String message = response.getString(RESPONCE_MESSAGE);
                        JSONObject messageJson = new JSONObject(message);
                        noOfItems = messageJson.getInt(CART_ITEM_COUNT);
                        if (noOfItems > 0)
                            textNoOfItemsInCart.setText("" + noOfItems);
                        toast(getString(R.string.message_added_to_cart), true);
                        SharedPreferenceUtils.getInstance(context).putInteger(CART_ITEM_COUNT, noOfItems);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                ((BaseActivity) currentActivity).logTesting("error is", error.toString(), Log.ERROR);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json");
                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }
}

