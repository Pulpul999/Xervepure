package com.app.xervepure.adapter;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.xervepure.R;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.model.CartModel;
import com.app.xervepure.utils.FontUtils;
import com.squareup.picasso.Picasso;

import java.util.List;

public class CheckoutProductAdapter extends RecyclerView.Adapter<CheckoutProductAdapter.ViewHolder> {

    Activity currentActivity;
    List<CartModel> cartModelList;

    public CheckoutProductAdapter(Activity currentActivity, List<CartModel> cartModelList) {
        this.currentActivity = currentActivity;
        this.cartModelList = cartModelList;
    }

    @Override
    public CheckoutProductAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(currentActivity).inflate(R.layout.items_checkout_product, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(final CheckoutProductAdapter.ViewHolder holder, final int position) {
        final int pos = position;
        if (cartModelList != null && cartModelList.size() > pos) {
            CartModel cartModel = cartModelList.get(pos);
            if (cartModel == null) return;
            String imageUrl = AppConstants.BASE_URL_IMAGES + "" + cartModelList.get(pos).getProductImage();
            Picasso.with(currentActivity).load(imageUrl).placeholder(R.drawable.applogo).error(R.drawable.applogo).into(holder.image);
            holder.productNameTextView.setText(cartModel.getProductName());
            holder.rupeesTextView.setText("" + cartModel.getProductPrice());
            holder.productNumberTextView.setText("" + cartModel.getProductQuantity());
            holder.quantityTextView.setText(cartModel.getProductPackQuantity());
            int totalAmt = cartModel.getProductPrice() * cartModel.getProductQuantity();
            holder.totalAmtTV.setText(currentActivity.getString(R.string.rupees_symbol) + " " + totalAmt + "/-");
        }

    }

    @Override
    public int getItemCount() {
        return cartModelList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView image;
        ImageView plusImageView;
        ImageView minusImageView;
        TextView productNameTextView;
        TextView lblQtyTV;
        TextView productNumberTextView;
        TextView rupeesTextView;
        TextView quantityTextView;
        TextView labelAmtTV;
        TextView totalAmtTV;

        public ViewHolder(View itemView) {
            super(itemView);

            image = (ImageView) itemView.findViewById(R.id.image);
            productNameTextView = (TextView) itemView.findViewById(R.id.productNameTextView);
            productNumberTextView = (TextView) itemView.findViewById(R.id.productNumberTextView);
            lblQtyTV = (TextView) itemView.findViewById(R.id.lblQtyTV);
            rupeesTextView = (TextView) itemView.findViewById(R.id.rupeesTextView);
            plusImageView = (ImageView) itemView.findViewById(R.id.plusImageView);
            minusImageView = (ImageView) itemView.findViewById(R.id.minusImageView);
            quantityTextView = (TextView) itemView.findViewById(R.id.quantityTextView);
            labelAmtTV = (TextView) itemView.findViewById(R.id.labelAmtTV);
            totalAmtTV = (TextView) itemView.findViewById(R.id.totalAmtTV);

            FontUtils.changeFont(currentActivity, productNameTextView, AppConstants.FONT_ROBOTO_MEDIUM);
            FontUtils.changeFont(currentActivity, quantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
            FontUtils.changeFont(currentActivity, rupeesTextView, AppConstants.FONT_ROBOTO_REGULAR);
            FontUtils.changeFont(currentActivity, productNumberTextView, AppConstants.FONT_ROBOTO_REGULAR);
            FontUtils.changeFont(currentActivity, lblQtyTV, AppConstants.FONT_ROBOTO_MEDIUM);
            FontUtils.changeFont(currentActivity, labelAmtTV, AppConstants.FONT_ROBOTO_MEDIUM);
            FontUtils.changeFont(currentActivity, totalAmtTV, AppConstants.FONT_ROBOTO_REGULAR);
        }
    }
}
