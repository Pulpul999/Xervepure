package com.app.xervepure.service;

import android.util.Log;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.utils.SharedPreferenceUtils;


/**
 * Created by admin on 15-11-2016.
 */
public class VyaanFirebaseInstanceIDService extends FirebaseInstanceIdService implements AppConstants {
    private static final String TAG = VyaanFirebaseInstanceIDService.class.getSimpleName();


    @Override
    public void onTokenRefresh() {
        super.onTokenRefresh();
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        Log.e("refreshedToken = ", refreshedToken);
        SharedPreferenceUtils.getInstance(getApplicationContext()).putString(FCM_TOKEN, refreshedToken);
    }
}
