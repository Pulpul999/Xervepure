package com.app.xervepure.fragments;

import android.os.Bundle;
import android.os.Handler;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.app.xervepure.activity.Dashboard;
import com.app.xervepure.interfaces.RecyclerClickListner;
import com.app.xervepure.utils.Validator;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.app.xervepure.R;
import com.app.xervepure.activity.BaseActivity;
import com.app.xervepure.adapter.MyPlanAdapter;
import com.app.xervepure.application.VyaanApplication;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.model.OrderHistoryModel;
import com.app.xervepure.model.RequestModel;
import com.app.xervepure.utils.DeviceUtils;
import com.app.xervepure.utils.SharedPreferenceUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderHistoryFragment extends BaseFragment {


    private RecyclerView recyclerPlans;
    private LinearLayoutManager linearLayoutManager;
    private List<OrderHistoryModel> orderHistoryModelList;
    private TextView textNoPlans;
    private MyPlanAdapter myPlanAdapter;

    public OrderHistoryFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return view = inflater.inflate(R.layout.fragment_order_history, container, false);
    }

    @Override
    public void alertOkClicked() {

    }

    @Override
    protected void initViews() {
        recyclerPlans = (RecyclerView) view.findViewById(R.id.recyclerPlans);
        textNoPlans = (TextView) view.findViewById(R.id.textNoPlans);
        linearLayoutManager = new LinearLayoutManager(currentActivity);
        orderHistoryModelList = new ArrayList<>();

        myPlanAdapter = new MyPlanAdapter(currentActivity, orderHistoryModelList);

        recyclerPlans.setAdapter(myPlanAdapter);
        recyclerPlans.setLayoutManager(linearLayoutManager);
        myPlans();
    }

    @Override
    protected void initContext() {
        context = getActivity();
        currentActivity = getActivity();
    }

    @Override
    protected void initListners() {
        myPlanAdapter.setOnItemClickListener(new RecyclerClickListner() {
            @Override
            public void onItemClick(int position, View v) {
                switch (v.getId()) {
                    case R.id.buttonCancel: {
                        if (Validator.isNetworkAvailable(currentActivity)) {
                           cancelOrder((Integer) v.getTag());
                        } else {
                            ((BaseActivity) currentActivity).alert(currentActivity, getString(R.string.alert_message_no_network), getString(R.string.alert_message_no_network), getString(R.string.labelOk), getString(R.string.labelCancel), false, false, ALERT_TYPE_NO_NETWORK);
                        }
                        break;
                    }
                }
            }

            @Override
            public void onItemLongClick(int position, View v) {

            }
        });
    }

    @Override
    public void onClick(View v) {

    }
    private void initRequestModel() {
        RequestModel.getInstance().setDeviceType(DEVICE_TYPE);
        RequestModel.getInstance().setLoginId(SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_MOBILE_NO));
        RequestModel.getInstance().setAccessToken(DeviceUtils.getDeviceKey());
        RequestModel.getInstance().setIpAddress(DeviceUtils.getDeviceIpAddress(context));
    }
    public void myPlans() {

        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);

        initRequestModel();
        JSONObject jsons = null;
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        try {
            jsons = new JSONObject(gson.toJson(RequestModel.getInstance()));
            jsons.put(KEY_USER_ID, SharedPreferenceUtils.getInstance(currentActivity).getInteger(AppConstants.USER_ID));
            Log.e("jsonGetOrderList", jsons.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_ORDER_HISTORY, jsons, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                ((BaseActivity) currentActivity).logTesting("getOrderListResponce is", response.toString(), Log.ERROR);

                try {
                    cancelProgressDialog();
                    ((BaseActivity) currentActivity).logTesting("is successfull fetch subscription", "hi" + response.getBoolean(AppConstants.KEY_ERROR), Log.ERROR);
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                        orderHistoryModelList.clear();
                        Gson gson = new Gson();
                        List<OrderHistoryModel> orderModelListTemp = Arrays.asList(gson.fromJson(response.getJSONArray(MESSAGE).toString(), OrderHistoryModel[].class));
                        if (orderModelListTemp.size() > 0) {
                            recyclerPlans.setVisibility(View.VISIBLE);
                            textNoPlans.setVisibility(View.GONE);
                            orderHistoryModelList.addAll(orderModelListTemp);
                            myPlanAdapter.notifyDataSetChanged();
                        } else {
                            recyclerPlans.setVisibility(View.GONE);
                            textNoPlans.setVisibility(View.VISIBLE);
                        }

                    } else {
                        recyclerPlans.setVisibility(View.GONE);
                        textNoPlans.setVisibility(View.VISIBLE);
                        cancelProgressDialog();
                        ((BaseActivity) currentActivity).logTesting("fetch subscription error", "true", Log.ERROR);
                    }


                } catch (JSONException e) {
                    recyclerPlans.setVisibility(View.GONE);
                    textNoPlans.setVisibility(View.VISIBLE);
                    ((BaseActivity) currentActivity).logTesting("fetch subscription json exeption is", e.toString(), Log.ERROR);
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                ((BaseActivity) currentActivity).logTesting("error is", error.toString(), Log.ERROR);
                ((BaseActivity) currentActivity).toast(getResources().getString(R.string.errorMyPlans), true);

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();

                params.put("Content-Type", "application/json");


                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }

    private void cancelOrder(int id) {

        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);

        initRequestModel();
        JSONObject jsons = null;
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        try {
            jsons = new JSONObject(gson.toJson(RequestModel.getInstance()));
            jsons.put("ordid", id);
            jsons.put(KEY_USER_ID, SharedPreferenceUtils.getInstance(context).getInteger(USER_ID));
            logTesting("cancelOrderRequestjson", jsons.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_CANCEL_ORDER, jsons, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                //cancelProgressDialog();
                try {
                    myPlans();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                logTesting("error is", error.toString());
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Accept", "application/json");
                params.put("Content-Type", "application/json");
                params.put("type", "M");

                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }


}
