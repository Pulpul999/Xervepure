package com.app.xervepure.adapter;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.app.xervepure.R;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.interfaces.RecyclerClickListner;
import com.app.xervepure.model.PlaceSubscriptionModel;
import com.app.xervepure.utils.DateTimeUtils;
import com.app.xervepure.utils.FontUtils;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by GARIMA on 9/15/2017.
 */

public class SubscriptionAdapter extends RecyclerView.Adapter<SubscriptionAdapter.ViewHolder> implements AppConstants {
    Activity currentActivity;
    ArrayList<PlaceSubscriptionModel> subscriptionDetailsModels;
    private int quantityCounter = 0;
    private static RecyclerClickListner clickListener;
    Bundle bundle;
    int type;

    public SubscriptionAdapter(Activity currentActivity, ArrayList<PlaceSubscriptionModel> subscriptionDetailsModels, int type) {
        this.currentActivity = currentActivity;
        this.subscriptionDetailsModels = subscriptionDetailsModels;
        this.type = type;
    }

    @Override
    public SubscriptionAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(currentActivity).inflate(R.layout.item_subscription_detail, parent, false);
        SubscriptionAdapter.ViewHolder holder = new SubscriptionAdapter.ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(SubscriptionAdapter.ViewHolder holder, int position) {
        final int pos = position;

        holder.productNameTextView.setText(subscriptionDetailsModels.get(position).getProductName());
        holder.quantityTextView.setText(subscriptionDetailsModels.get(position).getProductQuantity());
        if (subscriptionDetailsModels.get(position).getSubscriptionType() == TYPE_SUBSCRIPTION_EVERYDAY) {
            holder.subscriptionTypeTV.setText(currentActivity.getString(R.string.everyday));
        } else if (subscriptionDetailsModels.get(position).getSubscriptionType() == TYPE_SUBSCRIPTION_ALTERNATEDAY) {
            holder.subscriptionTypeTV.setText(currentActivity.getString(R.string.alternateday));
        } else if (subscriptionDetailsModels.get(position).getSubscriptionType() == TYPE_SUBSCRIPTION_CUSTOMIZE) {
            holder.subscriptionTypeTV.setText(currentActivity.getString(R.string.customize));
        }
        if (subscriptionDetailsModels.get(position).getSubscriptionHoldType() == TYPE_SUBSCRIPTION_HOLD) {
            holder.resumeTV.setText(currentActivity.getString(R.string.btn_resume));
        } else {
            holder.resumeTV.setText(currentActivity.getString(R.string.btn_hold));
        }

        if(type != 1) {
            holder.dateTV.setText("Started On: " + DateTimeUtils.getDateInFormat(subscriptionDetailsModels.get(position).getStartDate()));
            holder.endDateTV.setText("Ending On: " + DateTimeUtils.getDateInFormat(subscriptionDetailsModels.get(position).getEndDate()));
        }else {
            holder.resumeTV.setVisibility(View.GONE);
            holder.cancelTV.setVisibility(View.GONE);
            holder.editTV.setVisibility(View.GONE);
            holder.imgLL.setBackgroundResource(0);
            holder.dateTV.setText("Started On: " + subscriptionDetailsModels.get(position).getStartDate());
            holder.endDateTV.setText("Ending On: " + subscriptionDetailsModels.get(position).getEndDate());
        }

        String imageUrl = AppConstants.BASE_URL_IMAGES + "/" + subscriptionDetailsModels.get(pos).getImageName();
        Picasso.with(currentActivity).load(imageUrl).placeholder(R.drawable.applogo).error(R.drawable.applogo).into(holder.image);
    }

    @Override
    public int getItemCount() {
        return subscriptionDetailsModels.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ImageView image;
        TextView productNameTextView;
        TextView quantityTextView;
        TextView subscriptionTypeTV;
        TextView dateTV;
        TextView endDateTV;
        TextView resumeTV;
        TextView cancelTV;
        TextView editTV;
        LinearLayout imgLL;

        public ViewHolder(View itemView) {
            super(itemView);

            image = (ImageView) itemView.findViewById(R.id.image);
            productNameTextView = (TextView) itemView.findViewById(R.id.productNameTextView);
            subscriptionTypeTV = (TextView) itemView.findViewById(R.id.subscriptionTypeTV);
            quantityTextView = (TextView) itemView.findViewById(R.id.quantityTextView);
            dateTV = (TextView) itemView.findViewById(R.id.dateTV);
            endDateTV = (TextView) itemView.findViewById(R.id.endDateTV);
            resumeTV = (TextView) itemView.findViewById(R.id.resumeTV);
            cancelTV = (TextView) itemView.findViewById(R.id.cancelTV);
            editTV = (TextView) itemView.findViewById(R.id.editTV);
            imgLL = itemView.findViewById(R.id.imgLL);

            FontUtils.changeFont(currentActivity, productNameTextView, AppConstants.FONT_ROBOTO_MEDIUM);
            FontUtils.changeFont(currentActivity, quantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
            FontUtils.changeFont(currentActivity, subscriptionTypeTV, AppConstants.FONT_ROBOTO_REGULAR);
            FontUtils.changeFont(currentActivity, dateTV, AppConstants.FONT_ROBOTO_REGULAR);
            FontUtils.changeFont(currentActivity, endDateTV, AppConstants.FONT_ROBOTO_REGULAR);
            FontUtils.changeFont(currentActivity, resumeTV, AppConstants.FONT_ROBOTO_MEDIUM);
            FontUtils.changeFont(currentActivity, cancelTV, AppConstants.FONT_ROBOTO_MEDIUM);
            FontUtils.changeFont(currentActivity, editTV, AppConstants.FONT_ROBOTO_MEDIUM);

            resumeTV.setOnClickListener(this);
            cancelTV.setOnClickListener(this);
            editTV.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            clickListener.onItemClick(getAdapterPosition(), v);
        }
    }

    public void updateAdapter(ArrayList<PlaceSubscriptionModel> subscriptionDetailsModels) {
        this.subscriptionDetailsModels = subscriptionDetailsModels;
        notifyDataSetChanged();
    }

    private void setOnClickListener(ImageView plushImageView, final TextView quantityTextView, final TextView rupeesTextView, final String itemPrice) {
        View.OnClickListener clickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (view.getId()) {
                    case R.id.plusImageView: {
                        if (quantityCounter > 1) {
                            int currentPrice = Integer.parseInt(rupeesTextView.getText().toString());
                            int itemValue = Integer.parseInt(itemPrice);
                            int netPrice = currentPrice + itemValue;
                            // rupeesTextView.setText(String.valueOf(netPrice));
                        }
                        quantityCounter++;
                        quantityTextView.setText(String.valueOf(quantityCounter));


                    }
                    break;
                    case R.id.minusImageView:
                        if (quantityCounter > 1) {

                            quantityCounter--;
                            int currentPrice = Integer.parseInt(rupeesTextView.getText().toString());
                            int itemValue = Integer.parseInt(itemPrice);
                            int netPrice = currentPrice - itemValue;
                            //  rupeesTextView.setText(String.valueOf(netPrice));
                            quantityTextView.setText(String.valueOf(quantityCounter));
                        }


                        break;
                }

            }
        };
        plushImageView.setOnClickListener(clickListener);

    }

    public void setOnItemClickListener(RecyclerClickListner clickListener) {
        SubscriptionAdapter.clickListener = clickListener;
    }
}

