package com.app.xervepure.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.app.xervepure.constants.DbConstants;
import com.app.xervepure.model.WalletModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Codeslay-03 on 6/13/2017.
 */

public class UserDataSource implements DbConstants {


    public static final String TAG = "UserDataSource";
    protected VyaanSQLiteHelper dbHelper;

    protected Context context;

    public UserDataSource(Context context) {
        this.context = context;
        dbHelper = new VyaanSQLiteHelper(context);
        dbHelper.getWritableDatabase();
    }

    public boolean addUserTransaction(WalletModel walletModel) {
        if (walletModel == null) return false;
        SQLiteDatabase database = null;
        try {
            database = dbHelper.getWritableDatabase();

            ContentValues values = new ContentValues();

            values.put(COLUMN_TRANSACTION_ID, walletModel.getTransactionId());
            values.put(COLUMN_USER_ID, walletModel.getUserId());
            values.put(COLUMN_BALANCE, walletModel.getBalance());
            values.put(COLUMN_CHECKSUMHASH,walletModel.getCheckSumHash());
            values.put(COLUMN_PAYMENT_METHOD, walletModel.getPaymentMethod());

            database.insert(TABLE_USER_TRANSACTION, null, values);

        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        } finally {
            database.close();
        }
        return true;
    }

    public List<WalletModel> getUserTransactionList() {

        SQLiteDatabase database = null;
        WalletModel walletModel = null;
        List<WalletModel> walletModelList = null;
        String selectQueryQues = "SELECT transaction_id, user_id, balance, checksumhash, payment_method FROM " + TABLE_USER_TRANSACTION;
        try {
            database = dbHelper.getWritableDatabase();
            walletModelList = new ArrayList<>();
            Cursor cursor = database.rawQuery(selectQueryQues, null);
            if (cursor.moveToFirst()) {

                do {
                    walletModel = new WalletModel();
                    walletModel.setTransactionId(cursor.getString(0));
                    walletModel.setUserId(cursor.getInt(1));
                    walletModel.setBalance(cursor.getString(2));
                    walletModel.setCheckSumHash(cursor.getString(3));
                    walletModel.setPaymentMethod(cursor.getInt(4));

                    walletModelList.add(walletModel);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        } finally {
            database.close();
        }
        return walletModelList;
    }

    public boolean deleteUserTransaction(String transactionId) {
        if (transactionId == null) return false;
        SQLiteDatabase database = null;
        try {
            database = dbHelper.getWritableDatabase();

            String where = "transaction_id=?";
            String[] whereArgs = new String[]{transactionId};
            int result = database.delete(TABLE_USER_TRANSACTION, where, whereArgs);

        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        } finally {
            database.close();
        }
        return true;
    }

}
