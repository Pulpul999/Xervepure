package com.app.xervepure.adapter;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.xervepure.R;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.model.OrderHistoryModel;
import com.app.xervepure.utils.FontUtils;
import com.squareup.picasso.Picasso;

import java.util.List;


public class OrderHistoryDetailsAdapter extends RecyclerView.Adapter<OrderHistoryDetailsAdapter.ViewHolder> {

    Activity currentActivity;
    List<OrderHistoryModel> orderHistoryModelList;

    public OrderHistoryDetailsAdapter(Activity currentActivity, List<OrderHistoryModel> orderHistoryModelList) {
        this.currentActivity = currentActivity;
        this.orderHistoryModelList = orderHistoryModelList;
    }

    @Override
    public OrderHistoryDetailsAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(currentActivity).inflate(R.layout.items_order_details, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(final OrderHistoryDetailsAdapter.ViewHolder holder, final int position) {
        final int pos = position;
        if (orderHistoryModelList != null && orderHistoryModelList.size() > pos) {
            OrderHistoryModel historyModel = orderHistoryModelList.get(pos);
            if (historyModel == null) return;
            String imageUrl = AppConstants.BASE_URL_IMAGES + "/" + orderHistoryModelList.get(pos).getImage();
            Picasso.with(currentActivity).load(imageUrl).into(holder.image);
            holder.productNameTextView.setText(historyModel.getProductName());
            holder.productNumberTextView.setText("" + historyModel.getQuantity());
            holder.quantityTextView.setText(historyModel.getProductQuantity());
            holder.deliveredQtyTV.setText(""+historyModel.getDeliveredQty());
            int totalAmt = historyModel.getPrice() * historyModel.getQuantity();
            holder.totalAmtTV.setText(currentActivity.getString(R.string.rupees_symbol) + " " + totalAmt + "/-");
        }

    }

    @Override
    public int getItemCount() {
        return orderHistoryModelList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView image;
        TextView productNameTextView;
        TextView lblQtyTV;
        TextView productNumberTextView;
        TextView quantityTextView;
        TextView labelAmtTV;
        TextView totalAmtTV;
        TextView deliveredQtyTV;
        TextView lblDeliveredQtyTV;

        public ViewHolder(View itemView) {
            super(itemView);

            image = (ImageView) itemView.findViewById(R.id.image);
            productNameTextView = (TextView) itemView.findViewById(R.id.productNameTextView);
            productNumberTextView = (TextView) itemView.findViewById(R.id.productNumberTextView);
            lblQtyTV = (TextView) itemView.findViewById(R.id.lblQtyTV);
            quantityTextView = (TextView) itemView.findViewById(R.id.quantityTextView);
            labelAmtTV = (TextView) itemView.findViewById(R.id.labelAmtTV);
            totalAmtTV = (TextView) itemView.findViewById(R.id.totalAmtTV);
            deliveredQtyTV = (TextView) itemView.findViewById(R.id.deliveredQtyTV);
            lblDeliveredQtyTV = (TextView) itemView.findViewById(R.id.lblDeliveredQtyTV);

            FontUtils.changeFont(currentActivity, productNameTextView, AppConstants.FONT_ROBOTO_MEDIUM);
            FontUtils.changeFont(currentActivity, quantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
            FontUtils.changeFont(currentActivity, productNumberTextView, AppConstants.FONT_ROBOTO_REGULAR);
            FontUtils.changeFont(currentActivity, lblQtyTV, AppConstants.FONT_ROBOTO_MEDIUM);
            FontUtils.changeFont(currentActivity, labelAmtTV, AppConstants.FONT_ROBOTO_MEDIUM);
            FontUtils.changeFont(currentActivity, totalAmtTV, AppConstants.FONT_ROBOTO_REGULAR);
            FontUtils.changeFont(currentActivity, deliveredQtyTV, AppConstants.FONT_ROBOTO_REGULAR);
            FontUtils.changeFont(currentActivity, lblDeliveredQtyTV, AppConstants.FONT_ROBOTO_MEDIUM);
        }
    }
}
