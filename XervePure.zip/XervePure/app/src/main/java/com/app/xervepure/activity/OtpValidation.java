package com.app.xervepure.activity;

import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.app.xervepure.R;
import com.app.xervepure.application.VyaanApplication;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.interfaces.CancellingResendOtpThread;
import com.app.xervepure.model.LoginOrSignUpModel;
import com.app.xervepure.receiver.IncomingSms;
import com.app.xervepure.utils.DeviceUtils;
import com.app.xervepure.utils.FontUtils;
import com.app.xervepure.utils.Helper;
import com.app.xervepure.utils.SharedPreferenceUtils;
import com.app.xervepure.utils.Validator;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;


public class OtpValidation extends BaseActivity implements View.OnClickListener, CancellingResendOtpThread {
    public static Runnable r;
    public static Handler handler;
    public static Runnable rButtonVisibility;
    static Handler handlerButtonVisibility;
    public String textMobileNo;
    private EditText edtOtp;
    private Button btnSubmit;
    private Button btnResendOtp;
    private int otp;
    private String suppliededOtp;
    private BroadcastReceiver smsReciever;
    private Boolean recieverRegistered = false;
    private int oldOtp;
    private CountDownTimer countDownTimer;

    private TextView textViewTimer;
    private CountDownTimer timerForUnregisteringBroadcastReciever;
    private boolean istimerForUnregisteringBroadcastRecieverrunning = false;
    private int intNumberOfTimesResendPress = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.otp_validate);
    }

    public void onCreateWork() {
        Bundle data = getIntent().getExtras();
        if (data == null) {
            return;
        }
        textMobileNo = data.getString(USER_MOBILE_NO);
        handler = new Handler();

        SharedPreferenceUtils.getInstance(context).putString(USER_MOBILE_NO, textMobileNo.toString().trim());
        otp = Helper.randomNumberCreation(100000, 999999);
        SharedPreferenceUtils.getInstance(context).putString(KEY_OTP, String.valueOf(otp));
        smsReciever = new IncomingSms(OtpValidation.this);

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(EVENT_SMS_RECEIVED);
        intentFilter.setPriority(PRIORITY_HIGH);
        registerReceiver(smsReciever, intentFilter);

        if (Validator.isNetworkAvailable(context)) {
            btnResendOtp.setClickable(false);
            btnResendOtp.setAlpha(0.5f);
            functionEnablingButtons();
            functionInitializingCountDownTimer();
            sendMessageRequest();
            recieverRegistered = true;
            functionForUnregisteringBroadcastReceiever();
        } else {
            alert(currentActivity, getString(R.string.alert_message_no_network), getString(R.string.alert_message_no_network), getString(R.string.alert_ok_button_text_no_network), getString(R.string.alert_cancel_button_text_no_network), false, false, ALERT_TYPE_NO_NETWORK);
        }
    }

    @Override
    protected void initViews() {
        settingTitle(getString(R.string.otpvalidation));
        bundle = new Bundle();
        edtOtp = (EditText) findViewById(R.id.otpEditText);
        btnSubmit = (Button) findViewById(R.id.submitButton);
        btnResendOtp = (Button) findViewById(R.id.resendOtpButton);
        textViewTimer = (TextView) findViewById(R.id.textViewTimer);
        FontUtils.changeFont(this, edtOtp, FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(this, textViewTimer, FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(this, btnResendOtp, FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(this, btnSubmit, FONT_ROBOTO_MEDIUM);
        onCreateWork();
    }

    @Override
    protected void initContext() {
        currentActivity = OtpValidation.this;
        context = OtpValidation.this;
    }

    @Override
    protected void initListners() {
        btnSubmit.setOnClickListener(this);
        btnResendOtp.setOnClickListener(this);
    }

    @Override
    public boolean isActionBar() {
        return true;
    }

    @Override
    protected boolean isHomeButton() {
        return true;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.submitButton: {
                toHideKeyboard();
                if (Validator.getInstance().isNetworkAvailable(currentActivity)) {
                    suppliededOtp = edtOtp.getText().toString();
                    if (suppliededOtp.equals("")) {
                        toast(getResources().getString(R.string.emptyOtp), true);
                    } else {
                        int otp = Integer.parseInt(SharedPreferenceUtils.getInstance(context).getString(KEY_OTP));
                        if (Integer.parseInt(suppliededOtp) == otp || Integer.parseInt(suppliededOtp) == 123456) {
                            if (recieverRegistered == true) {
                                unregisterReceiver(smsReciever);
                                recieverRegistered = false;
                            }
                            if (istimerForUnregisteringBroadcastRecieverrunning) {
                                timerForUnregisteringBroadcastReciever.cancel();
                                istimerForUnregisteringBroadcastRecieverrunning = false;
                            }
                            numberVerified();
                        } else {
                            toast(getResources().getString(R.string.messageOtpInvalid), true);
                        }
                    }
                } else {
                    alert(currentActivity, getResources().getString(R.string.alert_message_no_network), getResources().getString(R.string.alert_message_no_network), getResources().getString(R.string.alert_ok_button_text_no_network), getResources().getString(R.string.alert_cancel_button_text_no_network), true, false, ALERT_TYPE_NO_NETWORK);
                }
                break;
            }
            case R.id.resendOtpButton: {
                toHideKeyboard();
                functionInitializingCountDownTimer();
                intNumberOfTimesResendPress = intNumberOfTimesResendPress + 1;

                if (intNumberOfTimesResendPress <= RESET_LIMIT) {
                    if (istimerForUnregisteringBroadcastRecieverrunning) {
                        timerForUnregisteringBroadcastReciever.cancel();
                        istimerForUnregisteringBroadcastRecieverrunning = false;
                    }
                    functionForUnregisteringBroadcastReceiever();

                    if (Validator.isNetworkAvailable(context)) {
                        sendMessageRequest();
                        btnResendOtp.setClickable(false);
                        btnResendOtp.setAlpha(0.5f);
                        functionEnablingButtons();
                    } else {
                        alert(currentActivity, getString(R.string.alert_message_no_network), getString(R.string.alert_message_no_network), getString(R.string.alert_ok_button_text_no_network), getString(R.string.alert_cancel_button_text_no_network), false, false, ALERT_TYPE_NO_NETWORK);
                    }
                }
                break;
            }
        }
    }

    @Override
    public void cancelHandler(boolean isCancel) {
        handlerButtonVisibility.removeCallbacks(rButtonVisibility);
        countDownTimer.cancel();
        timerForUnregisteringBroadcastReciever.cancel();
    }

    public void functionEnablingButtons() {
        rButtonVisibility = new Runnable() {
            @Override
            public void run() {
                btnResendOtp.setClickable(true);
                btnResendOtp.setAlpha(1);

            }
        };
        handlerButtonVisibility = new Handler();
        handlerButtonVisibility.postDelayed(rButtonVisibility, longTimeAfterWhichButtonEnable);
    }


    @Override
    public void onAlertClicked(int alertType) {

    }


    public void functionInitializingCountDownTimer() {
        textViewTimer.setVisibility(View.VISIBLE);
        countDownTimer = new CountDownTimer(longTotalVerificationTime, longOneSecond) {
            @Override
            public void onTick(long millisUntilFinished) {
                textViewTimer.setVisibility(View.VISIBLE);
                int remainingIntTime = (int) millisUntilFinished / 1000;
                String remainingTime = "";
                if (remainingIntTime < 10) {
                    remainingTime = "0" + remainingIntTime;
                } else {
                    remainingTime = "" + remainingIntTime;
                }
                textViewTimer.setText("00:" + remainingTime + " ");
            }

            @Override
            public void onFinish() {
                textViewTimer.setVisibility(View.INVISIBLE);
                edtOtp.setFocusable(true);

                edtOtp.requestFocus();
                edtOtp.setFocusableInTouchMode(true);
                edtOtp.setCursorVisible(true);
                edtOtp.invalidate();
            }
        }.start();
    }

    public void functionForUnregisteringBroadcastReceiever() {
        istimerForUnregisteringBroadcastRecieverrunning = true;
        timerForUnregisteringBroadcastReciever = new CountDownTimer(timeafterwhichRecieverUnregister, 120000) {

            @Override
            public void onTick(long millisUntilFinished) {
            }

            @Override
            public void onFinish() {
                if (recieverRegistered == true) {
                    unregisterReceiver(smsReciever);
                    recieverRegistered = false;
                }
            }
        };
    }

    private void sendMessageRequest() {

        oldOtp = Integer.parseInt(SharedPreferenceUtils.getInstance(context).getString(KEY_OTP));
        String message = "Dear%20Customer,%20your%20verification%20OTP%20is%20" + oldOtp + "%20,%20Thanks%20for%20subscribing%20with%20XERVEPURE";
        String url = "http://anysms.in/api.php?username=XERVEP&password=820983&sender=XERVEP&sendto=" + textMobileNo + "&message=" + message;
        Log.e("sendMessageRequestUrl", url);

        new RequestTask().execute(url);
    }

    public void autoFillOtp(int otp) {

        final String stringOtp = String.valueOf(otp);
        runOnUiThread(new Runnable() {

            @Override
            public void run() {
                edtOtp.setText(stringOtp);
                textViewTimer.setText("00:00" + " ");
                btnResendOtp.setClickable(true);
                btnResendOtp.setAlpha(1);
                cancelHandler(true);
                autoSubmitOtp();
            }
        });
    }

    public void autoSubmitOtp() {
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                toast(getResources().getString(R.string.messageNoValidated), true);
                numberVerified();
            }
        }, 1000);
    }

    // to do the operation
    public void numberVerified() {
        toast(getResources().getString(R.string.messageNoValidated), true);

        initSignUpModel();
        loginOrSignUp();
    }

    private void initSignUpModel() {
        LoginOrSignUpModel.getInstance().setDeviceType(DEVICE_TYPE);
        LoginOrSignUpModel.getInstance().setLoginId(textMobileNo);
        LoginOrSignUpModel.getInstance().setAccessToken(DeviceUtils.getDeviceKey());
        LoginOrSignUpModel.getInstance().setIpAddress(DeviceUtils.getDeviceIpAddress(context));
        LoginOrSignUpModel.getInstance().setPhone(textMobileNo);
        String deviceUUID = DeviceUtils.getDeviceUUID(getApplicationContext());
        LoginOrSignUpModel.getInstance().setDeviceId(deviceUUID);
        LoginOrSignUpModel.getInstance().setDeviceType(DEVICE_TYPE);
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        if (refreshedToken == null) {
            refreshedToken = "";
        }
        SharedPreferenceUtils.getInstance(getApplicationContext()).putString(FCM_TOKEN, refreshedToken);
        LoginOrSignUpModel.getInstance().setFcmToken(refreshedToken);
    }

    private void loginOrSignUp() {

        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);

        JSONObject jsonSignUpRequest = null;
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        try {
            jsonSignUpRequest = new JSONObject(gson.toJson(LoginOrSignUpModel.getInstance()));
            Log.e("jsonSignUpRequest", jsonSignUpRequest.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        final String URL_SIGN_UP = URL_SIGNUP;
        JsonObjectRequest signUpRequest = new JsonObjectRequest(Request.Method.POST, URL_SIGN_UP, jsonSignUpRequest, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    cancelProgressDialog();
                    String message = response.getString(RESPONCE_MESSAGE);
                    if (response.getBoolean(RESPONCE_ERROR) || message.isEmpty()) {
                        alert(currentActivity, getString(R.string.msg_reg_failed), getString(R.string.msg_reg_failed), getResources().getString(R.string.alert_ok_button_text_no_network), getResources().getString(R.string.alert_cancel_button_text_no_network), true, true, ALERT_TYPE_NO_NETWORK);
                    } else {
                        JSONArray messageJsonJSONArray = new JSONArray(message);
                        JSONObject messageJsonObj = messageJsonJSONArray.getJSONObject(0);
                        SharedPreferenceUtils.getInstance(currentActivity).putInteger(USER_ID, messageJsonObj.getInt(USER_ID));
                        SharedPreferenceUtils.getInstance(currentActivity).putString(USER_REF_CODE, messageJsonObj.getString(USER_REF_CODE));
                        SharedPreferenceUtils.getInstance(currentActivity).putString(USER_EXISTING_REF_CODE, messageJsonObj.getString(USER_EXISTING_REF_CODE));
                        SharedPreferenceUtils.getInstance(currentActivity).putString(USER_MOBILE_NO, messageJsonObj.getString(USER_MOBILE_NO));
                        SharedPreferenceUtils.getInstance(currentActivity).putString(AppConstants.USER_EMAIL, messageJsonObj.getString(USER_EMAIL));
                        SharedPreferenceUtils.getInstance(currentActivity).putString(USER_NAME, messageJsonObj.getString(USER_NAME));
                        SharedPreferenceUtils.getInstance(currentActivity).putString(AppConstants.USER_PROFILE_IMAGE, messageJsonObj.getString(USER_PROFILE_IMAGE));
                        SharedPreferenceUtils.getInstance(context).putBoolean(AppConstants.IS_USER_LOGIN, true);

                        startActivity(currentActivity, Dashboard.class, bundle, false, REQUEST_TAG_NO_RESULT, true, ANIMATION_SLIDE_UP);
                        finish();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                toast(getResources().getString(R.string.nwk_error_sign_up), true);
                logTesting(getResources().getString(R.string.nwk_error_sign_up), error.toString(), Log.ERROR);

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                return super.getHeaders();
            }
        };
        VyaanApplication.getInstance().addToRequestQueue(signUpRequest);
    }


    @Override
    protected void onDestroy() {
        if (smsReciever != null) {
            if (recieverRegistered == true) {
                unregisterReceiver(smsReciever);
                recieverRegistered = false;
            }
        }
        super.onDestroy();
    }

    private void showMessage(final String message) {
        runOnUiThread(new Runnable() {

            @Override
            public void run() {
                toast("OtpValidation = " + message, true);
            }
        });
    }

    /*class to Request the Gupshup service to send otp Start*/
    class RequestTask extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... uri) {
            URL url = null;
            try {
                url = new URL(uri[0]);
            } catch (MalformedURLException e) {
                //showMessage("MalformedURLException " + e.getMessage());
                e.printStackTrace();
            }
            try {
                //showMessage(uri[0]);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                conn.setRequestMethod("GET");
                conn.setDoOutput(true);
                conn.setDoInput(true);
                conn.setUseCaches(false);
                conn.connect();
                BufferedReader rd = new BufferedReader(new
                        InputStreamReader(conn.getInputStream()));
                String line;
                StringBuffer buffer = new StringBuffer();
                while ((line = rd.readLine()) != null) {
                    buffer.append(line).append("\n");
                }
                System.out.println(buffer.toString());
                rd.close();
                conn.disconnect();
                //showMessage(buffer.toString());
                return buffer.toString();

            } catch (IOException e) {
                //showMessage("IOException " + e.getMessage());
                e.printStackTrace();
            } catch (Exception e) {
                //showMessage("Exception " + e.getMessage());
                e.printStackTrace();
            }
            String responseString = "";
            return responseString;
        }


        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            //toast("Otp Result = " + result, true);
            if (!TextUtils.isEmpty(result)) {
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    if (jsonObject.has("status")) {
                        String status = jsonObject.getString("status");
                        if (!TextUtils.isEmpty(status) && status.equalsIgnoreCase("success")) {
                            toast(getResources().getString(R.string.messageOtpsent), true);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }

    }
}