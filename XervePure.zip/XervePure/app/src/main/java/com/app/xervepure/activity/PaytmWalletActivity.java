package com.app.xervepure.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.app.xervepure.R;
import com.app.xervepure.application.VyaanApplication;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.utils.DateTimeUtils;
import com.app.xervepure.utils.SharedPreferenceUtils;
import com.paytm.pgsdk.PaytmOrder;
import com.paytm.pgsdk.PaytmPGService;
import com.paytm.pgsdk.PaytmPaymentTransactionCallback;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

/**
 * This is the sample app which will make use of the PG SDK. This activity will
 * show the usage of Paytm PG SDK API's.
 **/

public class PaytmWalletActivity extends BaseActivity {

    String txnid = "";
    String amount;
    String firstname;
    String email;
    String phone;
    int userId;
    String checkSumHash;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paytm_wallet);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
    }

    @Override
    protected void initViews() {
        settingTitle(getString(R.string.labelPaytm));
        txnid = String.valueOf(DateTimeUtils.currentTimeMills());
        try {
            amount = getIntent().getStringExtra("amount");
        } catch (Exception e) {
            e.printStackTrace();
        }
        firstname = SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_NAME);
        email = SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_EMAIL);
        if (TextUtils.isEmpty(email)) {
            email = "xyz@gmail.com";
        }
        phone = SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_MOBILE_NO);
        userId = SharedPreferenceUtils.getInstance(context).getInteger(AppConstants.USER_ID);
        generateCheckum();
    }

    @Override
    protected void initContext() {
        context = PaytmWalletActivity.this;
        currentActivity = PaytmWalletActivity.this;
    }

    @Override
    protected void initListners() {

    }

    @Override
    protected boolean isActionBar() {
        return true;
    }

    @Override
    protected boolean isHomeButton() {
        return true;
    }

    //This is to refresh the order id: Only for the Sample App's purpose.
    @Override
    protected void onStart() {
        super.onStart();
        //initOrderId();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
    }

    public void generateCheckum() {

        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);
        JSONObject jsons = null;
        String url = "http://vyaandairy.com/paytm/generateChecksum.php";

        //String jsonString = "{\"CUST_ID\" = \"CUST_726\",\"EMAIL\" = \"arun@codeslay.com\",\"MOBILE_NO\" = \"7669381171\",\"ORDER_ID\" = \"1510396689189\",\"TXN_AMOUNT\" = \"100\"}";

        jsons = new JSONObject();
        try {
            jsons.put("ORDER_ID", txnid);
            jsons.put("CUST_ID", "CUST_" + userId);
            jsons.put("TXN_AMOUNT", amount);
            jsons.put("EMAIL", email);
            jsons.put("MOBILE_NO", phone);
            logTesting("jsonGenerateChecksum", jsons.toString(), Log.ERROR);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, jsons, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                cancelProgressDialog();
                try {
                    JSONObject messageJson = new JSONObject(response.toString());
                    checkSumHash = messageJson.getString("CHECKSUMHASH");
                    onStartTransaction();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                ((BaseActivity) currentActivity).logTesting("error is", error.toString(), Log.ERROR);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();

                params.put("Content-Type", "application/json");


                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }

    public void onStartTransaction() {
        PaytmPGService Service = PaytmPGService.getProductionService();

        Map<String, String> paramMap = new HashMap<String, String>();
        paramMap.put("MID", "Neonin72860660685906");
        paramMap.put("ORDER_ID", txnid);
        paramMap.put("CUST_ID", "CUST_" + userId);
        paramMap.put("INDUSTRY_TYPE_ID", "Retail109");
        paramMap.put("CHANNEL_ID", "WAP");
        paramMap.put("TXN_AMOUNT", amount);
        paramMap.put("WEBSITE", "NeoninWAP");
        paramMap.put("CALLBACK_URL", "https://securegw.paytm.in/theia/paytmCallback?ORDER_ID=" + txnid);
        paramMap.put("EMAIL", email);
        paramMap.put("MOBILE_NO", phone);
        paramMap.put("CHECKSUMHASH", checkSumHash);

        logTesting("paramMap", paramMap.toString(), Log.ERROR);

        PaytmOrder Order = new PaytmOrder(paramMap);

        Service.initialize(Order, null);

        Service.startPaymentTransaction(this, true, true,
                new PaytmPaymentTransactionCallback() {

                    @Override
                    public void someUIErrorOccurred(String inErrorMessage) {
                        // Some UI Error Occurred in Payment Gateway Activity.
                        // // This may be due to initialization of views in
                        // Payment Gateway Activity or may be due to //
                        // initialization of webview. // Error Message details
                        // the error occurred.
                    }

                    @Override
                    public void onTransactionResponse(Bundle inResponse) {
                        Log.d("LOG", "PaymentTransaction : " + inResponse);
                        //Toast.makeText(getApplicationContext(), "Payment Transaction response " + inResponse.toString(), Toast.LENGTH_LONG).show();
                        String status = inResponse.getString("STATUS");
                        if (!TextUtils.isEmpty(status) && status.equalsIgnoreCase("TXN_SUCCESS")) {
                            Intent intent = new Intent();
                            intent.putExtra(TRANSACTION_ID, txnid);
                            setResult(RESULT_OK, intent);
                            finish();
                        } else {
                            alert(currentActivity, "", inResponse.toString(), getString(R.string.labelOk), getString(R.string.labelCancel), false, false, ALERT_TYPE_NO_NETWORK);
                            //alert(currentActivity, getString(R.string.message_order_not_placed_popuop), getString(R.string.message_order_not_placed_popuop), getString(R.string.labelOk), getString(R.string.labelCancel), false, false, ALERT_TYPE_NO_NETWORK);
                        }
                        //toast("onTransactionResponseSucees", true);
                        //transactionStatusAPI(inResponse);
                    }

                    @Override
                    public void networkNotAvailable() {
                        // If network is not
                        // available, then this
                        // method gets called.
                    }

                    @Override
                    public void clientAuthenticationFailed(String inErrorMessage) {
                        // This method gets called if client authentication
                        // failed. // Failure may be due to following reasons //
                        // 1. Server error or downtime. // 2. Server unable to
                        // generate checksum or checksum response is not in
                        // proper format. // 3. Server failed to authenticate
                        // that client. That is value of payt_STATUS is 2. //
                        // Error Message describes the reason for failure.
                    }

                    @Override
                    public void onErrorLoadingWebPage(int iniErrorCode,
                                                      String inErrorMessage, String inFailingUrl) {

                    }

                    // had to be added: NOTE
                    @Override
                    public void onBackPressedCancelTransaction() {
                        // TODO Auto-generated method stub
                        finish();
                    }

                    @Override
                    public void onTransactionCancel(String inErrorMessage, Bundle inResponse) {
                        Log.d("LOG", "Payment Transaction Failed " + inErrorMessage);
                        Toast.makeText(getBaseContext(), "Payment Transaction Failed ", Toast.LENGTH_LONG).show();
                    }

                });
    }

    @Override
    public void onClick(View v) {

    }

    @Override
    public void onAlertClicked(int alertType) {

    }

    public void transactionStatusAPI(Bundle bundle) {

        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);
        JSONObject jsons = null;

        jsons = new JSONObject();
        try {
            jsons.put("MID", "NeonIn08978368302072");
            jsons.put("ORDER_ID", bundle.getString("ORDER_ID"));
            jsons.put("CHECKSUMHASH", URLEncoder.encode(bundle.getString("CHECKSUMHASH"), "UTF-8"));
            logTesting("transactionStatusAPI", jsons.toString(), Log.ERROR);
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        String url = "https://pguat.paytm.com/oltp/HANDLER_INTERNAL/getTxnStatus?JsonData=" + jsons.toString();
        logTesting("PaymentTransaction", url, Log.ERROR);
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                logTesting("PaymentTransaction", response.toString(), Log.ERROR);
                cancelProgressDialog();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                ((BaseActivity) currentActivity).logTesting("error is", error.toString(), Log.ERROR);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();

                params.put("Content-Type", "application/json");


                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }
}
