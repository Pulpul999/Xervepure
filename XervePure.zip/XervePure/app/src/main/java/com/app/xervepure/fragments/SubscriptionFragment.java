package com.app.xervepure.fragments;


import android.app.DatePickerDialog;
import android.app.Dialog;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.app.xervepure.R;
import com.app.xervepure.activity.BaseActivity;
import com.app.xervepure.activity.Dashboard;
import com.app.xervepure.adapter.SubscriptionAdapter;
import com.app.xervepure.application.VyaanApplication;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.interfaces.RecyclerClickListner;
import com.app.xervepure.model.DaySubscriptionModel;
import com.app.xervepure.model.PlaceSubscriptionModel;
import com.app.xervepure.model.RequestModel;
import com.app.xervepure.utils.DateTimeUtils;
import com.app.xervepure.utils.DeviceUtils;
import com.app.xervepure.utils.FontUtils;
import com.app.xervepure.utils.SharedPreferenceUtils;
import com.app.xervepure.utils.Validator;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 */
public class SubscriptionFragment extends BaseFragment {

    private PlaceSubscriptionModel subscriptionDetailsModel;
    private RecyclerView subscriptionRecyclerView;
    private TextView noSubscriptionTV;
    private SubscriptionAdapter subscriptionAdapter;
    private ArrayList<PlaceSubscriptionModel> subscriptionDetailsModels;


    /* subscription dialog start*/
    private ImageView productImageView;
    private TextView productNameTextView;
    private TextView productQuantityTextView;
    private TextView rupeesTextView;

    private LinearLayout everydayLL;
    private ImageView everydayIV;
    private TextView everydayTV;

    private LinearLayout alternateDayLL;
    private ImageView alternateDayIV;
    private TextView alternateDayTV;

    private LinearLayout customizeLL;
    private ImageView customizeIV;
    private TextView customizeTV;

    private ImageView plusImageView;
    private ImageView minusImageView;
    private TextView numberOfProductTV;

    private LinearLayout repeatweeklyLL;
    private ImageView repeatweeklyIV;
    private TextView repeatweeklyTV;

    private TextView lblStartTV;
    private TextView lblEndTV;
    private TextView dateTextView;
    private TextView endDateTextView;
    private CardView startDateCV;
    private CardView endDateCV;

    private LinearLayout weekDaysLL;
    private TextView sundayTextView;
    private TextView sundayQuantityTextView;
    private TextView mondayTextVIew;
    private TextView mondayQuantityTextView;
    private TextView tuesdayTextView;
    private TextView tuesdayQuantityTextView;
    private TextView wensdayTextView;
    private TextView wenesdayQuantityTextView;
    private TextView thursdayTextView;
    private TextView thrusdayQuantityTextView;
    private TextView fridayTextView;
    private TextView fridayQuantityTextView;
    private TextView saturdayTextView;
    private TextView saturdayQuantityTextView;
    private TextView holdSubscriptionTV;
    private Button btnConfrimSubscription;

    /* subscription dialog end*/
    private int subscriptionType;
    private boolean isRepeatWeekly;
    private Calendar mCalendar;
    private Calendar tomorrowCalendar;
    private Dialog dialog;
    private int dayArray[];
    private int arrayPossition = -1;
    private int subscriptionHoldType;
    private String productQty;

    public SubscriptionFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return view = inflater.inflate(R.layout.fragment_subscription, container, false);
    }

    @Override
    public void alertOkClicked() {

    }

    @Override
    protected void initViews() {
        dayArray = new int[7];
        subscriptionDetailsModels = new ArrayList<>();
        noSubscriptionTV = (TextView) view.findViewById(R.id.noSubscriptionTV);
        subscriptionRecyclerView = (RecyclerView) view.findViewById(R.id.subscriptionRecyclerView);
        subscriptionAdapter = new SubscriptionAdapter(currentActivity, subscriptionDetailsModels,0);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context);
        subscriptionRecyclerView.setLayoutManager(linearLayoutManager);
        subscriptionRecyclerView.setAdapter(subscriptionAdapter);
        holdSubscriptionTV = view.findViewById(R.id.holdSubscriptionTV);
        FontUtils.changeFont(context,holdSubscriptionTV,FONT_ROBOTO_MEDIUM);
        getSubscriptionList();
    }

    @Override
    protected void initContext() {
        context = getActivity();
        currentActivity = getActivity();
    }

    @Override
    protected void initListners() {
        subscriptionAdapter.setOnItemClickListener(new RecyclerClickListner() {
            @Override
            public void onItemClick(int position, View v) {
                if (subscriptionDetailsModels != null && subscriptionDetailsModels.size() > position) {
                    subscriptionDetailsModel = subscriptionDetailsModels.get(position);
                }
                if (subscriptionDetailsModel == null) return;
                switch (v.getId()) {
                    case R.id.resumeTV: {
                        if (Validator.isNetworkAvailable(currentActivity)) {
                            if (subscriptionDetailsModel.getSubscriptionHoldType() == TYPE_SUBSCRIPTION_HOLD) {
                                subscriptionHoldType = TYPE_SUBSCRIPTION_UNHOLD;
                            } else {
                                subscriptionHoldType = TYPE_SUBSCRIPTION_HOLD;
                            }
                            holdResumeSubscription();
                        } else {
                            ((BaseActivity) currentActivity).alert(currentActivity, getString(R.string.alert_message_no_network), getString(R.string.alert_message_no_network), getString(R.string.labelOk), getString(R.string.labelCancel), false, false, ALERT_TYPE_NO_NETWORK);
                        }
                        break;
                    }
                    case R.id.cancelTV: {
                        if (Validator.isNetworkAvailable(currentActivity)) {
                            cancelSubscription();
                        } else {
                            ((BaseActivity) currentActivity).alert(currentActivity, getString(R.string.alert_message_no_network), getString(R.string.alert_message_no_network), getString(R.string.labelOk), getString(R.string.labelCancel), false, false, ALERT_TYPE_NO_NETWORK);
                        }
                        break;
                    }
                    case R.id.editTV: {
                        showSubscriptionDialog();
                        break;
                    }
                }
            }

            @Override
            public void onItemLongClick(int position, View v) {

            }
        });

    }

    private void everyDayAction() {
        int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.95);
        int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.76);
        dialog.getWindow().setLayout(width, height);
        //isRepeatWeekly = true;
        weekDaysLL.setVisibility(View.GONE);
        //repeatweeklyLL.setVisibility(View.GONE);
        subscriptionType = TYPE_SUBSCRIPTION_EVERYDAY;
        everydayIV.setImageResource(R.drawable.radio_selected_btn);
        alternateDayIV.setImageResource(R.drawable.radio_unselected_btn);
        customizeIV.setImageResource(R.drawable.radio_unselected_btn);
        numberOfProductTV.setText(productQty);
    }

    private void alternateDayAction() {
        int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.95);
        int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.76);
        dialog.getWindow().setLayout(width, height);

        weekDaysLL.setVisibility(View.GONE);
        repeatweeklyLL.setVisibility(View.VISIBLE);
        subscriptionType = TYPE_SUBSCRIPTION_ALTERNATEDAY;
        everydayIV.setImageResource(R.drawable.radio_unselected_btn);
        alternateDayIV.setImageResource(R.drawable.radio_selected_btn);
        customizeIV.setImageResource(R.drawable.radio_unselected_btn);
        numberOfProductTV.setText(productQty);
    }

    private void customizedAction() {
        int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.95);
        int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.9);
        dialog.getWindow().setLayout(width, height);

        weekDaysLL.setVisibility(View.VISIBLE);
        repeatweeklyLL.setVisibility(View.VISIBLE);
        subscriptionType = TYPE_SUBSCRIPTION_CUSTOMIZE;
        everydayIV.setImageResource(R.drawable.radio_unselected_btn);
        alternateDayIV.setImageResource(R.drawable.radio_unselected_btn);
        customizeIV.setImageResource(R.drawable.radio_selected_btn);
        numberOfProductTV.setText("0");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.everydayLL: {
                everyDayAction();
                break;
            }
            case R.id.alternateDayLL: {
                alternateDayAction();
                break;
            }
            case R.id.customizeLL: {
                customizedAction();
                for (int i = 0; i < dayArray.length; i++) {
                    dayArray[i] = 0;
                }
                sundayTextView.setBackgroundResource(0);
                sundayTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                sundayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                sundayQuantityTextView.setText("0");
                mondayTextVIew.setBackgroundResource(0);
                mondayTextVIew.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                mondayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                mondayQuantityTextView.setText("0");
                tuesdayTextView.setBackgroundResource(0);
                tuesdayTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                tuesdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                tuesdayQuantityTextView.setText("0");
                wensdayTextView.setBackgroundResource(0);
                wensdayTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                wenesdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                wenesdayQuantityTextView.setText("0");
                thursdayTextView.setBackgroundResource(0);
                thursdayTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                thrusdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                thrusdayQuantityTextView.setText("0");
                fridayTextView.setBackgroundResource(0);
                fridayTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                fridayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                fridayQuantityTextView.setText("0");
                saturdayTextView.setBackgroundResource(0);
                saturdayTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                saturdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                saturdayQuantityTextView.setText("0");
                setCustomizeDay();
                break;
            }
            case R.id.repeatweeklyLL: {
                if (isRepeatWeekly) {
                    isRepeatWeekly = false;
                    repeatweeklyIV.setImageResource(R.drawable.check_box_unselected_btn);
                } else {
                    isRepeatWeekly = true;
                    repeatweeklyIV.setImageResource(R.drawable.check_box_selected_btn);
                }
                break;
            }
            case R.id.plusImageView: {
                int count = 0;
                if (!TextUtils.isEmpty(numberOfProductTV.getText().toString())) {
                    count = Integer.parseInt(numberOfProductTV.getText().toString());
                }
                ++count;
                if (subscriptionType == TYPE_SUBSCRIPTION_CUSTOMIZE) {
                    if (arrayPossition < 0) {
                        return;
                    }
                    setDayWiseQuantity(count);
                }
                numberOfProductTV.setText(count + "");
                break;
            }
            case R.id.minusImageView: {

                int count = 0;
                if (!TextUtils.isEmpty(numberOfProductTV.getText().toString())) {
                    count = Integer.parseInt(numberOfProductTV.getText().toString());
                }
                --count;
                if (subscriptionType == TYPE_SUBSCRIPTION_CUSTOMIZE) {
                    if (count < 0) return;
                    if (arrayPossition < 0) {
                        return;
                    }
                    setDayWiseQuantity(count);
                } else {
                    int minQuantity = 0;
                    if (subscriptionDetailsModel.getProductType() == PRODUCT_TYPE_MILK) {
                        minQuantity = MILK_MIN_ORDER_QTY;
                    } else {
                        minQuantity = OTHER_MIN_ORDER_QTY;
                    }
                    if (count < minQuantity) return;
                }
                numberOfProductTV.setText(count + "");
                break;
            }

            case R.id.sundayTextView: {
                arrayPossition = 0;
                numberOfProductTV.setText("" + dayArray[arrayPossition]);
                sundayTextView.setBackgroundResource(R.drawable.rounded_textview);
                sundayTextView.setTextColor(Color.WHITE);
                mondayTextVIew.setBackgroundResource(0);
                mondayTextVIew.setTextColor(mondayQuantityTextView.getTextColors());
                tuesdayTextView.setBackgroundResource(0);
                tuesdayTextView.setTextColor(tuesdayQuantityTextView.getTextColors());
                wensdayTextView.setBackgroundResource(0);
                wensdayTextView.setTextColor(wenesdayQuantityTextView.getTextColors());
                thursdayTextView.setBackgroundResource(0);
                thursdayTextView.setTextColor(thrusdayQuantityTextView.getTextColors());
                fridayTextView.setBackgroundResource(0);
                fridayTextView.setTextColor(fridayQuantityTextView.getTextColors());
                saturdayTextView.setBackgroundResource(0);
                saturdayTextView.setTextColor(saturdayQuantityTextView.getTextColors());
                break;
            }
            case R.id.mondayTextVIew: {
                arrayPossition = 1;
                numberOfProductTV.setText("" + dayArray[arrayPossition]);
                sundayTextView.setBackgroundResource(0);
                sundayTextView.setTextColor(sundayQuantityTextView.getTextColors());
                mondayTextVIew.setBackgroundResource(R.drawable.rounded_textview);
                mondayTextVIew.setTextColor(Color.WHITE);
                tuesdayTextView.setBackgroundResource(0);
                tuesdayTextView.setTextColor(tuesdayQuantityTextView.getTextColors());
                wensdayTextView.setBackgroundResource(0);
                wensdayTextView.setTextColor(wenesdayQuantityTextView.getTextColors());
                thursdayTextView.setBackgroundResource(0);
                thursdayTextView.setTextColor(thrusdayQuantityTextView.getTextColors());
                fridayTextView.setBackgroundResource(0);
                fridayTextView.setTextColor(fridayQuantityTextView.getTextColors());
                saturdayTextView.setBackgroundResource(0);
                saturdayTextView.setTextColor(saturdayQuantityTextView.getTextColors());
                break;
            }
            case R.id.tuesdayTextView: {
                arrayPossition = 2;
                numberOfProductTV.setText("" + dayArray[arrayPossition]);
                sundayTextView.setBackgroundResource(0);
                sundayTextView.setTextColor(sundayQuantityTextView.getTextColors());
                mondayTextVIew.setBackgroundResource(0);
                mondayTextVIew.setTextColor(mondayQuantityTextView.getTextColors());
                tuesdayTextView.setBackgroundResource(R.drawable.rounded_textview);
                tuesdayTextView.setTextColor(Color.WHITE);
                wensdayTextView.setBackgroundResource(0);
                wensdayTextView.setTextColor(wenesdayQuantityTextView.getTextColors());
                thursdayTextView.setBackgroundResource(0);
                thursdayTextView.setTextColor(thrusdayQuantityTextView.getTextColors());
                fridayTextView.setBackgroundResource(0);
                fridayTextView.setTextColor(fridayQuantityTextView.getTextColors());
                saturdayTextView.setBackgroundResource(0);
                saturdayTextView.setTextColor(saturdayQuantityTextView.getTextColors());
                break;
            }
            case R.id.wensdayTextView: {
                arrayPossition = 3;
                numberOfProductTV.setText("" + dayArray[arrayPossition]);
                sundayTextView.setBackgroundResource(0);
                sundayTextView.setTextColor(sundayQuantityTextView.getTextColors());
                mondayTextVIew.setBackgroundResource(0);
                mondayTextVIew.setTextColor(mondayQuantityTextView.getTextColors());
                tuesdayTextView.setBackgroundResource(0);
                tuesdayTextView.setTextColor(tuesdayQuantityTextView.getTextColors());
                wensdayTextView.setBackgroundResource(R.drawable.rounded_textview);
                wensdayTextView.setTextColor(Color.WHITE);
                thursdayTextView.setBackgroundResource(0);
                thursdayTextView.setTextColor(thrusdayQuantityTextView.getTextColors());
                fridayTextView.setBackgroundResource(0);
                fridayTextView.setTextColor(fridayQuantityTextView.getTextColors());
                saturdayTextView.setBackgroundResource(0);
                saturdayTextView.setTextColor(saturdayQuantityTextView.getTextColors());
                break;
            }
            case R.id.thursdayTextView: {
                arrayPossition = 4;
                numberOfProductTV.setText("" + dayArray[arrayPossition]);
                sundayTextView.setBackgroundResource(0);
                sundayTextView.setTextColor(sundayQuantityTextView.getTextColors());
                mondayTextVIew.setBackgroundResource(0);
                mondayTextVIew.setTextColor(mondayQuantityTextView.getTextColors());
                tuesdayTextView.setBackgroundResource(0);
                tuesdayTextView.setTextColor(tuesdayQuantityTextView.getTextColors());
                wensdayTextView.setBackgroundResource(0);
                wensdayTextView.setTextColor(wenesdayQuantityTextView.getTextColors());
                thursdayTextView.setBackgroundResource(R.drawable.rounded_textview);
                thursdayTextView.setTextColor(Color.WHITE);
                fridayTextView.setBackgroundResource(0);
                fridayTextView.setTextColor(fridayQuantityTextView.getTextColors());
                saturdayTextView.setBackgroundResource(0);
                saturdayTextView.setTextColor(saturdayQuantityTextView.getTextColors());
                break;
            }
            case R.id.fridayTextView: {
                arrayPossition = 5;
                numberOfProductTV.setText("" + dayArray[arrayPossition]);
                sundayTextView.setBackgroundResource(0);
                sundayTextView.setTextColor(sundayQuantityTextView.getTextColors());
                mondayTextVIew.setBackgroundResource(0);
                mondayTextVIew.setTextColor(mondayQuantityTextView.getTextColors());
                tuesdayTextView.setBackgroundResource(0);
                tuesdayTextView.setTextColor(tuesdayQuantityTextView.getTextColors());
                wensdayTextView.setBackgroundResource(0);
                wensdayTextView.setTextColor(wenesdayQuantityTextView.getTextColors());
                thursdayTextView.setBackgroundResource(0);
                thursdayTextView.setTextColor(thrusdayQuantityTextView.getTextColors());
                fridayTextView.setBackgroundResource(R.drawable.rounded_textview);
                fridayTextView.setTextColor(Color.WHITE);
                saturdayTextView.setBackgroundResource(0);
                saturdayTextView.setTextColor(saturdayQuantityTextView.getTextColors());
                break;
            }
            case R.id.saturdayTextView: {
                arrayPossition = 6;
                numberOfProductTV.setText("" + dayArray[arrayPossition]);
                sundayTextView.setBackgroundResource(0);
                sundayTextView.setTextColor(sundayQuantityTextView.getTextColors());
                mondayTextVIew.setBackgroundResource(0);
                mondayTextVIew.setTextColor(mondayQuantityTextView.getTextColors());
                tuesdayTextView.setBackgroundResource(0);
                tuesdayTextView.setTextColor(tuesdayQuantityTextView.getTextColors());
                wensdayTextView.setBackgroundResource(0);
                wensdayTextView.setTextColor(wenesdayQuantityTextView.getTextColors());
                thursdayTextView.setBackgroundResource(0);
                thursdayTextView.setTextColor(thrusdayQuantityTextView.getTextColors());
                fridayTextView.setBackgroundResource(0);
                fridayTextView.setTextColor(fridayQuantityTextView.getTextColors());
                saturdayTextView.setBackgroundResource(R.drawable.rounded_textview);
                saturdayTextView.setTextColor(Color.WHITE);
                break;
            }
            case R.id.btnConfrimSubscription: {
                if (Validator.isNetworkAvailable(currentActivity)) {
                    if (subscriptionType == TYPE_SUBSCRIPTION_CUSTOMIZE) {
                        int minQuantity = 0;
                        if (subscriptionDetailsModel.getProductType() == PRODUCT_TYPE_MILK) {
                            minQuantity = MILK_MIN_ORDER_QTY;
                        } else {
                            minQuantity = OTHER_MIN_ORDER_QTY;
                        }
                        int qtyCount = 0;
                        for (int i = 0; i < dayArray.length; i++) {
                            qtyCount = dayArray[i];
                            if (qtyCount > 0) break;
                        }

                        if (qtyCount == 0) {
                            alert(currentActivity, "", getString(R.string.message_singel_day_subscription), getResources().getString(R.string.alert_ok_button_text_no_network), getResources().getString(R.string.alert_cancel_button_text_no_network), false, false);
                            return;
                        }

                        for (int i = 0; i < dayArray.length; i++) {
                            qtyCount = dayArray[i];
                            if (qtyCount < minQuantity) {
                                if (qtyCount != 0) {
                                    String message = getString(R.string.message_min_qty);
                                    message.replace("2", "" + minQuantity);
                                    alert(currentActivity, "", message, getResources().getString(R.string.alert_ok_button_text_no_network), getResources().getString(R.string.alert_cancel_button_text_no_network), false, false);
                                    return;
                                }
                            }
                        }

                    }
                    initSubscriptionModel();
                    editSubscription();
                } else {
                    ((BaseActivity) currentActivity).alert(currentActivity, getString(R.string.alert_message_no_network), getString(R.string.alert_message_no_network), getString(R.string.labelOk), getString(R.string.labelCancel), false, false, ALERT_TYPE_NO_NETWORK);
                }
                break;
            }
            case R.id.endDateCV: {
                toOpenEndDatePicker();
                break;
            }
        }

    }
    private void toOpenEndDatePicker() {
        mCalendar = Calendar.getInstance();
        int year = mCalendar.get(Calendar.YEAR);
        int month = mCalendar.get(Calendar.MONTH);
        int day = mCalendar.get(Calendar.DAY_OF_MONTH);
        String selectedDate = endDateTextView.getText().toString();
        if (!TextUtils.isEmpty(selectedDate)) {
            String yearString = selectedDate.substring(6, 10);
            String monthString = selectedDate.substring(3, 5);
            String dayString = selectedDate.substring(0, 2);
            year = Integer.parseInt(yearString);
            month = Integer.parseInt(monthString);
            day = Integer.parseInt(dayString);
            month--;
        }
        DatePickerDialog dpDialog = new DatePickerDialog(currentActivity, subscriptionEndDate, year, month, day);
        dpDialog.updateDate(year, month, day);
        dpDialog.getDatePicker().setMinDate(mCalendar.getTimeInMillis());
        dpDialog.show();
    }

    DatePickerDialog.OnDateSetListener subscriptionEndDate = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            Calendar mCalendar = Calendar.getInstance();
            mCalendar.set(Calendar.YEAR, year);
            mCalendar.set(Calendar.MONTH, monthOfYear);
            mCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            String myFormat = "dd/MM/yyyy";
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
            endDateTextView.setText(sdf.format(mCalendar.getTime()));
        }
    };
    private void setDayWiseQuantity(int count) {
        dayArray[arrayPossition] = count;
        switch (arrayPossition) {
            case 0: {
                sundayQuantityTextView.setText("" + count);
                if (count == 0) {
                    sundayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                } else {
                    sundayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                }
                break;
            }
            case 1: {
                mondayQuantityTextView.setText("" + count);
                if (count == 0) {
                    mondayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                } else {
                    mondayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                }
                break;
            }
            case 2: {
                tuesdayQuantityTextView.setText("" + count);
                if (count == 0) {
                    tuesdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                } else {
                    tuesdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                }
                break;
            }
            case 3: {
                wenesdayQuantityTextView.setText("" + count);
                if (count == 0) {
                    wenesdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                } else {
                    wenesdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                }
                break;
            }
            case 4: {
                thrusdayQuantityTextView.setText("" + count);
                if (count == 0) {
                    thrusdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                } else {
                    thrusdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                }
                break;
            }
            case 5: {
                fridayQuantityTextView.setText("" + count);
                if (count == 0) {
                    fridayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                } else {
                    fridayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                }
                break;
            }
            case 6: {
                saturdayQuantityTextView.setText("" + count);
                if (count == 0) {
                    saturdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                } else {
                    saturdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                }
                break;
            }

        }
    }

    private void initRequestModel() {
        RequestModel.getInstance().setDeviceType(DEVICE_TYPE);
        RequestModel.getInstance().setLoginId(SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_MOBILE_NO));
        RequestModel.getInstance().setAccessToken(DeviceUtils.getDeviceKey());
        RequestModel.getInstance().setIpAddress(DeviceUtils.getDeviceIpAddress(context));
    }

    private void getSubscriptionList() {

        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);
        initRequestModel();
        JSONObject jsons = null;
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        try {
            jsons = new JSONObject(gson.toJson(RequestModel.getInstance()));
            jsons.put(KEY_USER_ID, SharedPreferenceUtils.getInstance(context).getInteger(USER_ID));
            Log.e("getSubscriptionList", jsons.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_GET_SUBSCRIPTION, jsons, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                ((BaseActivity) context).logTesting("getSubscriptionresp", response.toString(), Log.ERROR);
                cancelProgressDialog();
                try {
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                        subscriptionDetailsModels.clear();
                        Gson gson = new Gson();
                        List<PlaceSubscriptionModel> productsModelListTemp = Arrays.asList(gson.fromJson(response.getJSONArray(MESSAGE).toString(), PlaceSubscriptionModel[].class));
                        if (productsModelListTemp != null && productsModelListTemp.size() > 0) {
                            noSubscriptionTV.setVisibility(View.GONE);
                            subscriptionRecyclerView.setVisibility(View.VISIBLE);
                            holdSubscriptionTV.setVisibility(View.VISIBLE);
                        } else {
                            noSubscriptionTV.setVisibility(View.VISIBLE);
                            subscriptionRecyclerView.setVisibility(View.GONE);
                            holdSubscriptionTV.setVisibility(View.GONE);
                        }
                        subscriptionDetailsModels.addAll(productsModelListTemp);
                        subscriptionAdapter.notifyDataSetChanged();
                    } else {
                        noSubscriptionTV.setVisibility(View.VISIBLE);
                        subscriptionRecyclerView.setVisibility(View.GONE);
                        holdSubscriptionTV.setVisibility(View.GONE);
                        cancelProgressDialog();
                        ((BaseActivity) currentActivity).logTesting("fetchproductserror", "true", Log.ERROR);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                noSubscriptionTV.setVisibility(View.VISIBLE);
                subscriptionRecyclerView.setVisibility(View.GONE);
                holdSubscriptionTV.setVisibility(View.GONE);
                ((BaseActivity) currentActivity).logTesting("error is", error.toString(), Log.ERROR);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json");
                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);

    }

    private void showSubscriptionDialog() {

        View customView = currentActivity.getLayoutInflater().inflate(R.layout.activity_subscription, null);
        dialog = new Dialog(currentActivity, R.style.CustomDialog);
        dialog.setContentView(customView);
        int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.95);
        int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.76);
        dialog.getWindow().setLayout(width, height);

        initSubscribeViews(customView);
        dialog.show();
    }

    private void initSubscribeViews(View customView) {
        productImageView = (ImageView) customView.findViewById(R.id.productImageView);
        productNameTextView = (TextView) customView.findViewById(R.id.productNameTextView);
        productQuantityTextView = (TextView) customView.findViewById(R.id.productQuantityTextView);
        rupeesTextView = (TextView) customView.findViewById(R.id.rupeesTextView);

        everydayLL = (LinearLayout) customView.findViewById(R.id.everydayLL);
        everydayIV = (ImageView) customView.findViewById(R.id.everydayIV);
        everydayTV = (TextView) customView.findViewById(R.id.everydayTV);

        alternateDayLL = (LinearLayout) customView.findViewById(R.id.alternateDayLL);
        alternateDayIV = (ImageView) customView.findViewById(R.id.alternateDayIV);
        alternateDayTV = (TextView) customView.findViewById(R.id.alternateDayTV);

        customizeLL = (LinearLayout) customView.findViewById(R.id.customizeLL);
        customizeIV = (ImageView) customView.findViewById(R.id.customizeIV);
        customizeTV = (TextView) customView.findViewById(R.id.customizeTV);

        plusImageView = (ImageView) customView.findViewById(R.id.plusImageView);
        minusImageView = (ImageView) customView.findViewById(R.id.minusImageView);
        numberOfProductTV = (TextView) customView.findViewById(R.id.numberOfProductTV);

        repeatweeklyLL = (LinearLayout) customView.findViewById(R.id.repeatweeklyLL);
        repeatweeklyIV = (ImageView) customView.findViewById(R.id.repeatweeklyIV);
        repeatweeklyTV = (TextView) customView.findViewById(R.id.repeatweeklyTV);

        lblStartTV = (TextView) customView.findViewById(R.id.lblStartTV);
        lblEndTV = (TextView) customView.findViewById(R.id.lblEndTV);
        dateTextView = (TextView) customView.findViewById(R.id.dateTextView);
        endDateTextView = customView.findViewById(R.id.endDateTextView);
        startDateCV = (CardView) customView.findViewById(R.id.startDateCV);
        endDateCV = customView.findViewById(R.id.endDateCV);

        weekDaysLL = (LinearLayout) customView.findViewById(R.id.weekDaysLL);
        sundayTextView = (TextView) customView.findViewById(R.id.sundayTextView);
        sundayQuantityTextView = (TextView) customView.findViewById(R.id.sundayQuantityTextView);
        mondayTextVIew = (TextView) customView.findViewById(R.id.mondayTextVIew);
        mondayQuantityTextView = (TextView) customView.findViewById(R.id.mondayQuantityTextView);
        tuesdayTextView = (TextView) customView.findViewById(R.id.tuesdayTextView);
        tuesdayQuantityTextView = (TextView) customView.findViewById(R.id.tuesdayQuantityTextView);
        wensdayTextView = (TextView) customView.findViewById(R.id.wensdayTextView);
        wenesdayQuantityTextView = (TextView) customView.findViewById(R.id.wenesdayQuantityTextView);
        thursdayTextView = (TextView) customView.findViewById(R.id.thursdayTextView);
        thrusdayQuantityTextView = (TextView) customView.findViewById(R.id.thrusdayQuantityTextView);
        fridayTextView = (TextView) customView.findViewById(R.id.fridayTextView);
        fridayQuantityTextView = (TextView) customView.findViewById(R.id.fridayQuantityTextView);
        saturdayTextView = (TextView) customView.findViewById(R.id.saturdayTextView);
        saturdayQuantityTextView = (TextView) customView.findViewById(R.id.saturdayQuantityTextView);

        btnConfrimSubscription = (Button) customView.findViewById(R.id.btnConfrimSubscription);

        FontUtils.changeFont(currentActivity, productNameTextView, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, productQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, rupeesTextView, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, everydayTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, alternateDayTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, customizeTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, numberOfProductTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, repeatweeklyTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, lblStartTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, lblEndTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, dateTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, endDateTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, sundayTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, sundayQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, mondayTextVIew, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, mondayQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, tuesdayTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, tuesdayQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, wensdayTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, wenesdayQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, thursdayTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, thrusdayQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, fridayTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, fridayQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, saturdayTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, saturdayQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, btnConfrimSubscription, AppConstants.FONT_ROBOTO_MEDIUM);

        everydayLL.setOnClickListener(this);
        alternateDayLL.setOnClickListener(this);
        customizeLL.setOnClickListener(this);
        plusImageView.setOnClickListener(this);
        minusImageView.setOnClickListener(this);
        repeatweeklyLL.setOnClickListener(this);
        startDateCV.setOnClickListener(this);
        endDateCV.setOnClickListener(this);
        weekDaysLL.setOnClickListener(this);
        sundayTextView.setOnClickListener(this);
        mondayTextVIew.setOnClickListener(this);
        tuesdayTextView.setOnClickListener(this);
        wensdayTextView.setOnClickListener(this);
        thursdayTextView.setOnClickListener(this);
        fridayTextView.setOnClickListener(this);
        saturdayTextView.setOnClickListener(this);
        btnConfrimSubscription.setOnClickListener(this);
        endDateCV.setOnClickListener(this);
        setTextOnViews();
    }

    private void setTextOnViews() {
        if (subscriptionDetailsModel == null) return;
        String imageUrl = AppConstants.BASE_URL_IMAGES + "/" + subscriptionDetailsModel.getImageName();
        Picasso.with(currentActivity).load(imageUrl).into(productImageView);
        productNameTextView.setText(subscriptionDetailsModel.getProductName());
        productQuantityTextView.setText(subscriptionDetailsModel.getProductQuantity());
        rupeesTextView.setText(subscriptionDetailsModel.getProductPrice() + "");
        dateTextView.setText(DateTimeUtils.getDateInFormat(subscriptionDetailsModel.getStartDate()));
        endDateTextView.setText(DateTimeUtils.getDateInFormat(subscriptionDetailsModel.getEndDate()));

        ArrayList<DaySubscriptionModel> daySubscriptionModels = subscriptionDetailsModel.getDaySubscriptionModels();
        if (subscriptionDetailsModel.getSubscriptionType() == TYPE_SUBSCRIPTION_EVERYDAY) {
            everyDayAction();
            subscriptionType = TYPE_SUBSCRIPTION_EVERYDAY;
            if (daySubscriptionModels != null && daySubscriptionModels.size() > 0) {
                DaySubscriptionModel daySubscriptionModel = daySubscriptionModels.get(0);
                if (daySubscriptionModel != null) {
                    productQty = daySubscriptionModel.getQuantity();
                    numberOfProductTV.setText(daySubscriptionModel.getQuantity());
                }
                for (int i = 0; i < daySubscriptionModels.size(); i++) {
                    daySubscriptionModel = daySubscriptionModels.get(i);
                    if (daySubscriptionModel == null) {
                        continue;
                    }
                    if (!TextUtils.isEmpty(daySubscriptionModel.getQuantity())) {
                        int count = Integer.parseInt(daySubscriptionModel.getQuantity());
                        dayArray[i] = count;
                    }
                }
            }

        } else if (subscriptionDetailsModel.getSubscriptionType() == TYPE_SUBSCRIPTION_ALTERNATEDAY) {
            alternateDayAction();
            subscriptionType = TYPE_SUBSCRIPTION_ALTERNATEDAY;
            if (daySubscriptionModels != null && daySubscriptionModels.size() > 0) {
                for (int i = 0; i < daySubscriptionModels.size(); i++) {
                    DaySubscriptionModel daySubscriptionModel = daySubscriptionModels.get(i);
                    if (daySubscriptionModel == null) {
                        continue;
                    }
                    if (!TextUtils.isEmpty(daySubscriptionModel.getQuantity())) {
                        int count = Integer.parseInt(daySubscriptionModel.getQuantity());
                        dayArray[i] = count;
                        if (count > 0) {
                            productQty = daySubscriptionModel.getQuantity();
                            numberOfProductTV.setText(daySubscriptionModel.getQuantity());
                        }
                    }
                }

            }
        } else if (subscriptionDetailsModel.getSubscriptionType() == TYPE_SUBSCRIPTION_CUSTOMIZE) {
            customizedAction();
            subscriptionType = TYPE_SUBSCRIPTION_CUSTOMIZE;
            setCustomizeDay();
        }
        isRepeatWeekly = subscriptionDetailsModel.getIsRepeatWeekly() == 1 ? true : false;
        if (isRepeatWeekly) {
            repeatweeklyIV.setImageResource(R.drawable.check_box_selected_btn);
        } else {
            repeatweeklyIV.setImageResource(R.drawable.check_box_unselected_btn);
        }

    }

    private void setCustomizeDay() {
        if (subscriptionDetailsModel.getSubscriptionType() != TYPE_SUBSCRIPTION_CUSTOMIZE) {
            return;
        }

        ArrayList<DaySubscriptionModel> daySubscriptionModels = subscriptionDetailsModel.getDaySubscriptionModels();
        if (daySubscriptionModels == null) return;

        for (int i = 0; i < daySubscriptionModels.size(); i++) {
            DaySubscriptionModel daySubscriptionModel = daySubscriptionModels.get(i);
            if (daySubscriptionModel == null) {
                continue;
            }
            int count = 0;
            numberOfProductTV.setText(daySubscriptionModel.getQuantity());
            if (!TextUtils.isEmpty(daySubscriptionModel.getQuantity())) {
                count = Integer.parseInt(daySubscriptionModel.getQuantity());
            }
            dayArray[i] = count;
            switch (i) {
                case 0: {
                    sundayQuantityTextView.setText("" + count);
                    if (count == 0) {
                        sundayTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                        sundayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                    } else {
                        sundayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                        sundayTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                    }
                    break;
                }
                case 1: {
                    mondayQuantityTextView.setText("" + count);
                    if (count == 0) {
                        mondayTextVIew.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                        mondayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                    } else {
                        mondayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                        mondayTextVIew.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                    }
                    break;
                }
                case 2: {
                    tuesdayQuantityTextView.setText("" + count);
                    if (count == 0) {
                        tuesdayTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                        tuesdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                    } else {
                        tuesdayTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                        tuesdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                    }
                    break;
                }
                case 3: {
                    wenesdayQuantityTextView.setText("" + count);
                    if (count == 0) {
                        wensdayTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                        wenesdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                    } else {
                        wensdayTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                        wenesdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                    }
                    break;
                }
                case 4: {
                    thrusdayQuantityTextView.setText("" + count);
                    if (count == 0) {
                        thursdayTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                        thrusdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                    } else {
                        thursdayTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                        thrusdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                    }
                    break;
                }
                case 5: {
                    fridayQuantityTextView.setText("" + count);
                    if (count == 0) {
                        fridayTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                        fridayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                    } else {
                        fridayTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                        fridayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                    }
                    break;
                }
                case 6: {
                    saturdayQuantityTextView.setText("" + count);
                    if (count == 0) {
                        saturdayTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                        saturdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                    } else {
                        saturdayTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                        saturdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                    }
                    break;
                }
            }
        }
    }

    private void initSubscriptionModel() {
        if (subscriptionDetailsModel == null) return;
        subscriptionDetailsModel.setSubscriptionType(subscriptionType);
        subscriptionDetailsModel.setIsRepeatWeekly(isRepeatWeekly ? 1 : 0);
        subscriptionDetailsModel.setEndDate(endDateTextView.getText().toString());
        ArrayList<DaySubscriptionModel> daySubscriptionModels = new ArrayList<>();

        if (subscriptionType == TYPE_SUBSCRIPTION_ALTERNATEDAY) {
            int dayOfWeek = 0;
            Date date = null;
            SimpleDateFormat inFormat = new SimpleDateFormat("dd/MM/yyyy");
            try {
                date = inFormat.parse(dateTextView.getText().toString());
                Calendar c = Calendar.getInstance();
                c.setTime(date);
                dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            for (int i = 0; i < 7; i++) {
                DaySubscriptionModel daySubscriptionModel = new DaySubscriptionModel();
                int day = 0;
                if (dayOfWeek > 7) {
                    day = dayOfWeek - 7;
                } else {
                    day = dayOfWeek;
                }
                switch (day) {
                    case 1: {
                        daySubscriptionModel.setDay("Sunday");
                        break;
                    }
                    case 2: {
                        daySubscriptionModel.setDay("Monday");
                        break;
                    }
                    case 3: {
                        daySubscriptionModel.setDay("Tuesday");
                        break;
                    }
                    case 4: {
                        daySubscriptionModel.setDay("Wednesday");
                        break;
                    }
                    case 5: {
                        daySubscriptionModel.setDay("Thursday");
                        break;
                    }
                    case 6: {
                        daySubscriptionModel.setDay("Friday");
                        break;
                    }
                    case 7: {
                        daySubscriptionModel.setDay("Saturday");
                        break;
                    }
                }
                dayOfWeek++;
                if (i % 2 == 0) {
                    daySubscriptionModel.setQuantity(numberOfProductTV.getText().toString());
                } else {
                    daySubscriptionModel.setQuantity("0");
                }
                daySubscriptionModels.add(daySubscriptionModel);
            }
            subscriptionDetailsModel.setDaySubscriptionModels(daySubscriptionModels);
            return;
        }

        for (int i = 0; i < dayArray.length; i++) {
            DaySubscriptionModel daySubscriptionModel = new DaySubscriptionModel();
            switch (i) {
                case 0: {
                    daySubscriptionModel.setDay("Sunday");
                    break;
                }
                case 1: {
                    daySubscriptionModel.setDay("Monday");
                    break;
                }
                case 2: {
                    daySubscriptionModel.setDay("Tuesday");
                    break;
                }
                case 3: {
                    daySubscriptionModel.setDay("Wednesday");
                    break;
                }
                case 4: {
                    daySubscriptionModel.setDay("Thursday");
                    break;
                }
                case 5: {
                    daySubscriptionModel.setDay("Friday");
                    break;
                }
                case 6: {
                    daySubscriptionModel.setDay("Saturday");
                    break;
                }
            }
            if (subscriptionType == TYPE_SUBSCRIPTION_CUSTOMIZE) {
                daySubscriptionModel.setQuantity(dayArray[i] + "");
            } else if (subscriptionType == TYPE_SUBSCRIPTION_EVERYDAY) {
                daySubscriptionModel.setQuantity(numberOfProductTV.getText().toString());
            }
            daySubscriptionModels.add(daySubscriptionModel);
        }
        subscriptionDetailsModel.setDaySubscriptionModels(daySubscriptionModels);
    }

    public void editSubscription() {
        if (subscriptionDetailsModel == null) return;
        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);

        subscriptionDetailsModel.setDeviceType(DEVICE_TYPE);
        subscriptionDetailsModel.setLoginId(SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_MOBILE_NO));
        subscriptionDetailsModel.setAccessToken(DeviceUtils.getDeviceKey());
        subscriptionDetailsModel.setIpAddress(DeviceUtils.getDeviceIpAddress(context));

        String json = new Gson().toJson(subscriptionDetailsModel);
        logTesting("editSubscriptionrequestjson", json);
        JSONObject jsons = null;
        try {
            jsons = new JSONObject(json);
            new Gson().toJson(json);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_UPDATE_SUSCRIPTION, jsons, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                logTesting("editSubscription is", response.toString());
                try {
                    logTesting("is successfull edit Subscription", "hi" + response.getBoolean(AppConstants.KEY_ERROR));
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                        toast(context, getResources().getString(R.string.sucess_edit_subscription));
                        dialog.dismiss();
                        getSubscriptionList();
                    } else {
                        cancelProgressDialog();
                        ((BaseActivity) currentActivity).alert(currentActivity, currentActivity.getString(R.string.error_edit_subscription), currentActivity.getString(R.string.error_edit_subscription), currentActivity.getString(R.string.labelOk), currentActivity.getString(R.string.labelCancel), false, false, AppConstants.ALERT_TYPE_NO_NETWORK);
                        logTesting("place Subscription error", "true");
                    }


                } catch (JSONException e) {
                    logTesting("editSubscription json exeption is", e.toString());
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                logTesting("error is", error.toString());
                toast(context, getResources().getString(R.string.errorEditSubscription));

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Accept", "application/json");
                params.put("Content-Type", "application/json");
                params.put("type", "M");

                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }


    public void holdResumeSubscription() {
        if (subscriptionDetailsModel == null) return;
        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);

        initRequestModel();
        JSONObject jsons = null;
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        try {
            jsons = new JSONObject(gson.toJson(RequestModel.getInstance()));
            jsons.put("id", subscriptionDetailsModel.getId());
            jsons.put(KEY_USER_ID, SharedPreferenceUtils.getInstance(context).getInteger(USER_ID));
            jsons.put("is_subscription_hold", subscriptionHoldType);
            logTesting("holdSubscriptionrequestjson", jsons.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_HOLD_RESUME_SUSCRIPTION, jsons, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                logTesting("holsSubscription is", response.toString());

                try {
                    logTesting("is successfull hold Subscription", "hi" + response.getBoolean(AppConstants.KEY_ERROR));
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                        if (subscriptionDetailsModel.getSubscriptionHoldType() == TYPE_SUBSCRIPTION_HOLD) {
                            toast(context, getResources().getString(R.string.sucess_resume_subscription));
                        } else {
                            toast(context, getResources().getString(R.string.sucess_hold_subscription));
                        }
                        getSubscriptionList();
                    } else {
                        cancelProgressDialog();
                        if (subscriptionDetailsModel.getSubscriptionHoldType() == TYPE_SUBSCRIPTION_HOLD) {
                            ((BaseActivity) currentActivity).alert(currentActivity, currentActivity.getString(R.string.failed_resume_subscription), currentActivity.getString(R.string.failed_resume_subscription), currentActivity.getString(R.string.labelOk), currentActivity.getString(R.string.labelCancel), false, false, AppConstants.ALERT_TYPE_NO_NETWORK);
                        } else {
                            ((BaseActivity) currentActivity).alert(currentActivity, currentActivity.getString(R.string.failed_hold_subscription), currentActivity.getString(R.string.failed_hold_subscription), currentActivity.getString(R.string.labelOk), currentActivity.getString(R.string.labelCancel), false, false, AppConstants.ALERT_TYPE_NO_NETWORK);
                        }

                        logTesting("hold Subscription error", "true");
                    }


                } catch (JSONException e) {
                    logTesting("holdSubscription json exeption is", e.toString());
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                logTesting("error is", error.toString());
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Accept", "application/json");
                params.put("Content-Type", "application/json");
                params.put("type", "M");

                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }


    public void cancelSubscription() {
        if (subscriptionDetailsModel == null) return;
        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);

        initRequestModel();
        JSONObject jsons = null;
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        try {
            jsons = new JSONObject(gson.toJson(RequestModel.getInstance()));
            jsons.put("id", subscriptionDetailsModel.getId());
            jsons.put(KEY_USER_ID, SharedPreferenceUtils.getInstance(context).getInteger(USER_ID));
            logTesting("cancelSubscriptionrequestjson", jsons.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_CANCEL_RESUME_SUSCRIPTION, jsons, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                cancelProgressDialog();
                logTesting("cancelSubscription is", response.toString());

                try {
                    logTesting("is successfull cancel Subscription", "hi" + response.getBoolean(AppConstants.KEY_ERROR));
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                        toast(context, getResources().getString(R.string.sucess_cancel_subscription));
                        //getSubscriptionList();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (currentActivity != null) {
                                    ((Dashboard) currentActivity).setSelection(AppConstants.FEEDBACK);
                                }
                            }
                        }, 100);

                    } else {

                        ((BaseActivity) currentActivity).alert(currentActivity, currentActivity.getString(R.string.failed_cancel_subscription), currentActivity.getString(R.string.failed_cancel_subscription), currentActivity.getString(R.string.labelOk), currentActivity.getString(R.string.labelCancel), false, false, AppConstants.ALERT_TYPE_NO_NETWORK);

                        logTesting("cancel Subscription error", "true");
                    }


                } catch (JSONException e) {
                    logTesting("cancelSubscription json exeption is", e.toString());
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                logTesting("error is", error.toString());
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Accept", "application/json");
                params.put("Content-Type", "application/json");
                params.put("type", "M");

                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }

}
