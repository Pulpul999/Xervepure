package com.app.xervepure.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import com.app.xervepure.R;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.utils.DateTimeUtils;
import com.app.xervepure.utils.SharedPreferenceUtils;
import com.paytm.pgsdk.PaytmOrder;
import com.paytm.pgsdk.PaytmPGService;
import com.paytm.pgsdk.PaytmPaymentTransactionCallback;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * This is the sample app which will make use of the PG SDK. This activity will
 * show the usage of Paytm PG SDK API's.
 **/

public class RazorpayWalletActivity extends BaseActivity implements PaymentResultListener {

    String txnid = "";
    String amount;
    String firstname;
    String email;
    String phone;
    int userId;
    String checkSumHash;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paytm_wallet);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        Checkout.preload(context);
    }

    @Override
    protected void initViews() {
        settingTitle("Payment");
        txnid = String.valueOf(DateTimeUtils.currentTimeMills());
        try {
            amount = getIntent().getStringExtra("amount");
            int amt = Integer.parseInt(amount);
            amount = String.valueOf(amt * 100);
        } catch (Exception e) {
            e.printStackTrace();
        }
        firstname = SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_NAME);
        email = SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_EMAIL);
        if (TextUtils.isEmpty(email)) {
            email = "xyz@gmail.com";
        }
        phone = SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_MOBILE_NO);
        userId = SharedPreferenceUtils.getInstance(context).getInteger(AppConstants.USER_ID);
        startPayment();
    }

    @Override
    protected void initContext() {
        context = RazorpayWalletActivity.this;
        currentActivity = RazorpayWalletActivity.this;
    }

    @Override
    protected void initListners() {

    }

    @Override
    protected boolean isActionBar() {
        return true;
    }

    @Override
    protected boolean isHomeButton() {
        return true;
    }

    //This is to refresh the order id: Only for the Sample App's purpose.
    @Override
    protected void onStart() {
        super.onStart();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
    }

    public void startPayment() {
        /*
          You need to pass current activity in order to let Razorpay create CheckoutActivity
         */
        final Activity activity = this;

        final Checkout co = new Checkout();

        try {
            JSONObject options = new JSONObject();
            options.put("name", "XervePure");
            options.put("description", "Adding money from user");
            //You can omit the image option to fetch the image from dashboard
            options.put("image", "https://s3.amazonaws.com/rzp-mobile/images/rzp.png");
            options.put("currency", "INR");
            options.put("amount", amount);

            JSONObject preFill = new JSONObject();
            preFill.put("email", email);
            preFill.put("contact", phone);
            options.put("prefill", preFill);

            co.open(activity, options);
        } catch (Exception e) {
            Toast.makeText(activity, "Error in payment: " + e.getMessage(), Toast.LENGTH_SHORT)
                    .show();
            e.printStackTrace();
        }
    }

    public void onStartTransaction() {
        PaytmPGService Service = PaytmPGService.getProductionService();

        Map<String, String> paramMap = new HashMap<String, String>();
        paramMap.put("MID", "Neonin72860660685906");
        paramMap.put("ORDER_ID", txnid);
        paramMap.put("CUST_ID", "CUST_" + userId);
        paramMap.put("INDUSTRY_TYPE_ID", "Retail109");
        paramMap.put("CHANNEL_ID", "WAP");
        paramMap.put("TXN_AMOUNT", amount);
        paramMap.put("WEBSITE", "NeoninWAP");
        paramMap.put("CALLBACK_URL", "https://securegw.paytm.in/theia/paytmCallback?ORDER_ID=" + txnid);
        paramMap.put("EMAIL", email);
        paramMap.put("MOBILE_NO", phone);
        paramMap.put("CHECKSUMHASH", checkSumHash);

        logTesting("paramMap", paramMap.toString(), Log.ERROR);

        PaytmOrder Order = new PaytmOrder(paramMap);

        Service.initialize(Order, null);

        Service.startPaymentTransaction(this, true, true,
                new PaytmPaymentTransactionCallback() {

                    @Override
                    public void someUIErrorOccurred(String inErrorMessage) {
                        // Some UI Error Occurred in Payment Gateway Activity.
                        // // This may be due to initialization of views in
                        // Payment Gateway Activity or may be due to //
                        // initialization of webview. // Error Message details
                        // the error occurred.
                    }

                    @Override
                    public void onTransactionResponse(Bundle inResponse) {
                        Log.d("LOG", "PaymentTransaction : " + inResponse);
                        //Toast.makeText(getApplicationContext(), "Payment Transaction response " + inResponse.toString(), Toast.LENGTH_LONG).show();
                        String status = inResponse.getString("STATUS");
                        if (!TextUtils.isEmpty(status) && status.equalsIgnoreCase("TXN_SUCCESS")) {
                            Intent intent = new Intent();
                            intent.putExtra(TRANSACTION_ID, txnid);
                            setResult(RESULT_OK, intent);
                            finish();
                        } else {
                            alert(currentActivity, "", inResponse.toString(), getString(R.string.labelOk), getString(R.string.labelCancel), false, false, ALERT_TYPE_NO_NETWORK);
                            //alert(currentActivity, getString(R.string.message_order_not_placed_popuop), getString(R.string.message_order_not_placed_popuop), getString(R.string.labelOk), getString(R.string.labelCancel), false, false, ALERT_TYPE_NO_NETWORK);
                        }
                        //toast("onTransactionResponseSucees", true);
                        //transactionStatusAPI(inResponse);
                    }

                    @Override
                    public void networkNotAvailable() {
                        // If network is not
                        // available, then this
                        // method gets called.
                    }

                    @Override
                    public void clientAuthenticationFailed(String inErrorMessage) {
                        // This method gets called if client authentication
                        // failed. // Failure may be due to following reasons //
                        // 1. Server error or downtime. // 2. Server unable to
                        // generate checksum or checksum response is not in
                        // proper format. // 3. Server failed to authenticate
                        // that client. That is value of payt_STATUS is 2. //
                        // Error Message describes the reason for failure.
                    }

                    @Override
                    public void onErrorLoadingWebPage(int iniErrorCode,
                                                      String inErrorMessage, String inFailingUrl) {

                    }

                    // had to be added: NOTE
                    @Override
                    public void onBackPressedCancelTransaction() {
                        // TODO Auto-generated method stub
                        finish();
                    }

                    @Override
                    public void onTransactionCancel(String inErrorMessage, Bundle inResponse) {
                        Log.d("LOG", "Payment Transaction Failed " + inErrorMessage);
                        Toast.makeText(getBaseContext(), "Payment Transaction Failed ", Toast.LENGTH_LONG).show();
                    }

                });
    }

    @Override
    public void onClick(View v) {

    }

    @Override
    public void onAlertClicked(int alertType) {
        switch (alertType) {
            case ALERT_TYPE_CANCEL_TRANSCATION: {
                finish();
            }
        }
    }

    @Override
    public void onPaymentSuccess(String s) {
        Log.e("onPaymentSuccess = ", s);
        Intent intent = new Intent();
        intent.putExtra(TRANSACTION_ID, s);
        setResult(RESULT_OK, intent);
        finish();
    }

    @Override
    public void onPaymentError(int i, String s) {
        Log.e("onPaymentError = ", s + " i=" + i);
        alert(currentActivity, getString(R.string.message_order_not_placed_popuop), getString(R.string.message_order_not_placed_popuop), getString(R.string.labelOk), getString(R.string.labelCancel), false, false, ALERT_TYPE_CANCEL_TRANSCATION);
    }

    @Override
    public void onBackPressed() {
        alert(currentActivity, getString(R.string.title_cancel_transaction), getString(R.string.message_cancel_transaction), getString(R.string.alert_ok_button_text_no_network), getString(R.string.alert_cancel_button_text_no_network), true, true, ALERT_TYPE_CANCEL_TRANSCATION);
    }
}
