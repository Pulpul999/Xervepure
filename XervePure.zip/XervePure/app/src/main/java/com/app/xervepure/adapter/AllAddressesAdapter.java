package com.app.xervepure.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.xervepure.R;
import com.app.xervepure.activity.AllAddressesActivity;
import com.app.xervepure.activity.BaseActivity;
import com.app.xervepure.activity.EditAddressActivity;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.model.AddressModel;
import com.app.xervepure.utils.FontUtils;

import java.util.List;


public class AllAddressesAdapter extends RecyclerView.Adapter<AllAddressesAdapter.ViewHolder> {

    Activity currentActivity;
    List<AddressModel> addressModelList;

    Bundle bundle;

    public AllAddressesAdapter(Activity currentActivity, List<AddressModel> addressModelList) {
        this.currentActivity = currentActivity;
        this.addressModelList = addressModelList;
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(currentActivity).inflate(R.layout.items_address, parent, false);

        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        final int pos = position;
        if (addressModelList != null && addressModelList.size() > pos) {
            holder.textAddressType.setText(addressModelList.get(pos).getAddressTitle());
            holder.textUserName.setText(addressModelList.get(pos).getName());

            String compleateAddress = addressModelList.get(pos).getAddressLine1();
            if (!TextUtils.isEmpty(addressModelList.get(pos).getAddressLine2())) {
                compleateAddress += ", " + addressModelList.get(pos).getAddressLine2();
            }
            if (!TextUtils.isEmpty(addressModelList.get(pos).getLandmark())) {
                compleateAddress += ", " + addressModelList.get(pos).getLandmark();
            }
            if (!TextUtils.isEmpty(addressModelList.get(pos).getCityName())) {
                compleateAddress += ", " + addressModelList.get(pos).getCityName();
            }
            if (!TextUtils.isEmpty(addressModelList.get(pos).getLocalityName())) {
                compleateAddress += ", " + addressModelList.get(pos).getLocalityName();
            }
            if (!TextUtils.isEmpty(addressModelList.get(pos).getPincode())) {
                compleateAddress += " " + addressModelList.get(pos).getPincode();
            }
            holder.textAddress.setText(compleateAddress);

            holder.textPhoneNo.setText("" + addressModelList.get(pos).getPhoneNumber());
            if (addressModelList.get(pos).isSelected()) {
                holder.radioIV.setImageResource(R.drawable.radio_selected_btn);
            } else {
                holder.radioIV.setImageResource(R.drawable.radio_unselected_btn);
            }
            holder.textEditAddress.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (bundle == null) {
                        bundle = new Bundle();
                    }
                    bundle.putParcelable(AppConstants.ADDRESS_MODEL, addressModelList.get(pos));

                    ((BaseActivity) currentActivity).startActivity(currentActivity, EditAddressActivity.class, bundle, true, AppConstants.REQUEST_TAG_EDIT_ADDRESS_ACTIVITY, true, AppConstants.ANIMATION_SLIDE_LEFT);

                }
            });

            holder.containerAddress.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (currentActivity == null) return;
                    /*if (((AllAddressesActivity) currentActivity).isSubscription) {

                        alert(currentActivity, currentActivity.getString(R.string.titlePlaceSubscription), currentActivity.getString(R.string.messagePlaceSubscription), currentActivity.getString(R.string.labelOk), currentActivity.getString(R.string.labelCancel), true, true, AppConstants.ALERT_TYPE_NO_NETWORK, pos);

                    } else {

                        alert(currentActivity, currentActivity.getString(R.string.titlePlaceOrder), currentActivity.getString(R.string.messagePlaceOrder), currentActivity.getString(R.string.labelOk), currentActivity.getString(R.string.labelCancel), true, true, AppConstants.ALERT_TYPE_NO_NETWORK, pos);
                    }*/

                    for (int i = 0; i < addressModelList.size(); i++) {
                        addressModelList.get(i).setSelected(false);
                    }
                    addressModelList.get(pos).setSelected(true);
                    notifyDataSetChanged();
                }
            });
        }
    }


    @Override
    public int getItemCount() {
        return addressModelList.size();
    }

    public void alert(Context context, String title, String message, String positiveButton, String negativeButton, boolean isNegativeButton, boolean isTitle, final int alertType, final int pos) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        if (isTitle) {
            builder.setTitle(title);
        }


        builder.setMessage(message);
        builder.setPositiveButton(positiveButton, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                if (((AllAddressesActivity) currentActivity).isSubscription) {
                    ((AllAddressesActivity) currentActivity).placeSubscription(addressModelList.get(pos).getId());
                } else {
                    ((AllAddressesActivity) currentActivity).placeOrder(addressModelList.get(pos).getId());
                }

            }
        });
        if (isNegativeButton) {
            builder.setNegativeButton(negativeButton, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    if (((AllAddressesActivity) currentActivity).isSubscription) {
                        ((AllAddressesActivity) currentActivity).toast(currentActivity.getResources().getString(R.string.messageSubscriptionCancelled), false);
                    } else {
                        ((AllAddressesActivity) currentActivity).toast(currentActivity.getResources().getString(R.string.messageOrderCancelled), false);
                    }

                    ((AllAddressesActivity) currentActivity).finish();
                }
            });
        }

        builder.show();


    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textAddressType;
        TextView textUserName;
        TextView textAddress;
        TextView textPhoneNo;
        CardView containerAddress;
        TextView textEditAddress;
        ImageView radioIV;

        public ViewHolder(View itemView) {
            super(itemView);

            textAddressType = (TextView) itemView.findViewById(R.id.textAddressType);
            textUserName = (TextView) itemView.findViewById(R.id.textUserName);
            textAddress = (TextView) itemView.findViewById(R.id.textAddress);
            textPhoneNo = (TextView) itemView.findViewById(R.id.textPhoneNo);
            containerAddress = (CardView) itemView.findViewById(R.id.containerAddress);
            textEditAddress = (TextView) itemView.findViewById(R.id.textEditAddress);
            radioIV = itemView.findViewById(R.id.radioIV);

            FontUtils.changeFont(currentActivity, textAddressType, AppConstants.FONT_ROBOTO_MEDIUM);
            FontUtils.changeFont(currentActivity, textUserName, AppConstants.FONT_ROBOTO_REGULAR);
            FontUtils.changeFont(currentActivity, textAddress, AppConstants.FONT_ROBOTO_REGULAR);
            FontUtils.changeFont(currentActivity, textPhoneNo, AppConstants.FONT_ROBOTO_REGULAR);
            FontUtils.changeFont(currentActivity, textEditAddress, AppConstants.FONT_ROBOTO_MEDIUM);
        }
    }


}
