package com.app.xervepure.adapter;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.app.xervepure.R;
import com.app.xervepure.activity.BaseActivity;

import com.app.xervepure.activity.ProductDetailsActivity;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.model.ProductModel;

import com.app.xervepure.utils.FontUtils;
import com.squareup.picasso.Picasso;

import java.util.List;


public class ProductsAdapter extends RecyclerView.Adapter<ProductsAdapter.ViewHolder> implements AppConstants {

    Activity currentActivity;
    List<ProductModel> productModelList;

    Bundle bundle;

    public ProductsAdapter(Activity currentActivity, List<ProductModel> productModelList) {
        this.currentActivity = currentActivity;
        this.productModelList = productModelList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(currentActivity).inflate(R.layout.items_products, parent, false);
        //int height = parent.getMeasuredHeight() / 2;
        //view.setMinimumHeight(height);
        ViewHolder holder = new ViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final int pos = position;
        holder.textProductName.setText(productModelList.get(pos).getName()+" >>");
        holder.textProductName.setSelected(true);
        FontUtils.changeFont(currentActivity, holder.textProductName, AppConstants.FONT_ROBOTO_MEDIUM);

        Log.e("product name", productModelList.get(pos).getName());
        if (productModelList.get(pos) != null) {
            String imageUrl = AppConstants.BASE_URL_IMAGES + "/" + productModelList.get(pos).getImage();
            Picasso.with(currentActivity).load(imageUrl).placeholder(R.drawable.applogo).error(R.drawable.applogo).into(holder.imageProduct);
        }
        holder.containerProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                /*if (!productModelList.get(pos).getIsCommingSoon().equalsIgnoreCase(IS_COMINGSOON)) {

                } else {
                    ((BaseActivity) currentActivity).alert(currentActivity, ((BaseActivity) currentActivity).getString(R.string.alert_product_coming_soon), ((BaseActivity) currentActivity).getString(R.string.alert_product_coming_soon), ((BaseActivity) currentActivity).getString(R.string.labelOk), ((BaseActivity) currentActivity).getString(R.string.labelCancel), false, false, ALERT_TYPE_NO_NETWORK);
                }*/
                if (bundle == null) {
                    bundle = new Bundle();
                }

                bundle.putParcelable(PRODUCT_DETAILS, productModelList.get(pos));
                ((BaseActivity) currentActivity).startActivity(currentActivity, ProductDetailsActivity.class, bundle, true, AppConstants.REQUEST_TAG_NO_RESULT, true, AppConstants.ANIMATION_SLIDE_LEFT);


            }
        });

    }

    @Override
    public int getItemCount() {
        return productModelList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView imageProduct;
        TextView textProductName;
        LinearLayout containerProduct;

        public ViewHolder(View itemView) {
            super(itemView);

            imageProduct = (ImageView) itemView.findViewById(R.id.imageProduct);
            textProductName = (TextView) itemView.findViewById(R.id.textProductName);
            containerProduct = (LinearLayout) itemView.findViewById(R.id.containerProduct);
        }
    }
}
