package com.app.xervepure.activity;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.app.xervepure.R;
import com.app.xervepure.adapter.EditCartAdapter;
import com.app.xervepure.application.VyaanApplication;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.model.CartModel;
import com.app.xervepure.model.RequestModel;
import com.app.xervepure.model.UpdateCartModel;
import com.app.xervepure.utils.DeviceUtils;
import com.app.xervepure.utils.FontUtils;
import com.app.xervepure.utils.SharedPreferenceUtils;
import com.app.xervepure.utils.Validator;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EditCartActivity extends BaseActivity {


    private TextView textTotalAmount;
    private TextView labelTotalAmtTV;
    private RecyclerView recyclerCartItems;
    private LinearLayoutManager linearLayoutManager;
    private ArrayList<CartModel> cartModelList;
    private Button btnSave;
    private EditCartAdapter cartAdapter;

    private TextView textNoItemsInCart;

    private LinearLayout containerCart;

    private boolean isCheckOut;
    private int pos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_cart);
    }

    @Override
    protected void initViews() {

        linearLayoutManager = new LinearLayoutManager(currentActivity);

        cartModelList = new ArrayList<>();
        textNoItemsInCart = (TextView) findViewById(R.id.textNoItemsInCart);
        textTotalAmount = (TextView) findViewById(R.id.textTotalAmount);
        labelTotalAmtTV = (TextView) findViewById(R.id.labelTotalAmtTV);
        recyclerCartItems = (RecyclerView) findViewById(R.id.recyclerCartItems);
        containerCart = (LinearLayout) findViewById(R.id.containerCart);

        cartAdapter = new EditCartAdapter(currentActivity, cartModelList);

        recyclerCartItems.setAdapter(cartAdapter);
        recyclerCartItems.setLayoutManager(linearLayoutManager);
        FontUtils.changeFont(currentActivity, labelTotalAmtTV, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, textTotalAmount, AppConstants.FONT_ROBOTO_REGULAR);
        getSupportActionBar().setTitle(R.string.title_edit_cart);

        getCartItems();

        btnSave = (Button) findViewById(R.id.btnSave);
    }

    @Override
    protected void initContext() {
        currentActivity = EditCartActivity.this;
        context = EditCartActivity.this;
    }

    @Override
    protected void initListners() {
        btnSave.setOnClickListener(this);

        cartAdapter.setOnItemClickListener(new EditCartAdapter.RecyclerClickListner() {
            @Override
            public void onItemClick(int position, View v, TextView quantityTV) {
                switch (v.getId()) {
                    case R.id.deleteTextView: {
                        pos = position;
                        if (cartModelList != null && cartModelList.size() > position) {
                            alert(currentActivity, "", currentActivity.getString(R.string.alert_message_remove_item_from_cart), currentActivity.getString(R.string.labelOk), currentActivity.getString(R.string.labelCancel), true, true, AppConstants.ALERT_TYPE_CART_ITEM_REMOVE);
                        }
                        break;
                    }
                    case R.id.plusImageView: {
                        if (cartModelList != null && cartModelList.size() > position) {
                            CartModel cartModel = cartModelList.get(position);
                            if (cartModel == null) return;
                            int count = cartModel.getProductQuantity();
                            cartModel.setProductQuantity(++count);
                            cartAdapter.notifyDataSetChanged();
                            displayTotalAmt();
                        }
                        break;
                    }
                    case R.id.minusImageView: {
                        if (cartModelList != null && cartModelList.size() > position) {
                            CartModel cartModel = cartModelList.get(position);
                            if (cartModel == null) return;
                            int count = cartModel.getProductQuantity();
                            int minQuantity = 0;
                            if (cartModel.getProductType() == PRODUCT_TYPE_MILK) {
                                minQuantity = MILK_MIN_ORDER_QTY;
                            } else {
                                minQuantity = OTHER_MIN_ORDER_QTY;
                            }
                            if (count <= minQuantity) return;
                            cartModel.setProductQuantity(--count);
                            cartAdapter.notifyDataSetChanged();
                            displayTotalAmt();
                        }
                        break;
                    }
                }
            }

            @Override
            public void onItemLongClick(int position, View v) {

            }
        });
    }

    @Override
    protected boolean isActionBar() {
        return true;
    }

    @Override
    protected boolean isHomeButton() {
        return true;
    }


    @Override
    public void onAlertClicked(int alertType) {
        if (alertType == ALERT_TYPE_CART_ITEM_REMOVE) {
            if (cartModelList.size() > pos) {
                cartModelList.remove(pos);
                cartAdapter.notifyDataSetChanged();
                displayTotalAmt();
            }
        }
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {

            case R.id.btnSave: {
                if (Validator.isNetworkAvailable(currentActivity)) {
                    initUpdateCartModel();
                } else {
                    alert(currentActivity, getString(R.string.alert_message_no_network), getString(R.string.alert_message_no_network), getString(R.string.labelOk), getString(R.string.labelCancel), false, false, ALERT_TYPE_NO_NETWORK);
                }
                break;
            }
        }

    }


    private void displayTotalAmt() {
        int totalAmount = 0;
        for (int i = 0; i < cartModelList.size(); i++) {
            CartModel cartModel = cartModelList.get(i);
            totalAmount += (cartModel.getProductPrice() * cartModel.getProductQuantity());
        }
        textTotalAmount.setText(currentActivity.getString(R.string.rupees_symbol) + " " + totalAmount + "/-");
    }

    private void initRequestModel() {
        RequestModel.getInstance().setDeviceType(DEVICE_TYPE);
        RequestModel.getInstance().setLoginId(SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_MOBILE_NO));
        RequestModel.getInstance().setAccessToken(DeviceUtils.getDeviceKey());
        RequestModel.getInstance().setIpAddress(DeviceUtils.getDeviceIpAddress(context));
    }

    public void getCartItems() {

        progressDialog(currentActivity, currentActivity.getString(R.string.pdialog_message_loading), currentActivity.getString(R.string.pdialog_message_loading), false, false);

        initRequestModel();
        int userId = SharedPreferenceUtils.getInstance(currentActivity).getInteger(AppConstants.USER_ID);
        JSONObject jsons = null;
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        try {
            jsons = new JSONObject(gson.toJson(RequestModel.getInstance()));
            jsons.put("user_id", userId);
            Log.e("jsonGetCartItems", jsons.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_GET_CART_ITEMS, jsons, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                logTesting("get cart item responce is", response.toString(), Log.ERROR);
                try {
                    cancelProgressDialog();
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                        cartModelList.clear();
                        Gson gson = new Gson();
                        List<CartModel> cartModelListTemp = Arrays.asList(gson.fromJson(response.getJSONArray(RESPONCE_MESSAGE).toString(), CartModel[].class));

                        if (cartModelListTemp.size() > 0) {
                            int totalAmount = 0;
                            for (int i = 0; i < cartModelListTemp.size(); i++) {
                                CartModel cartModel = cartModelListTemp.get(i);
                                totalAmount += (cartModel.getProductPrice() * cartModel.getProductQuantity());
                            }

                            textTotalAmount.setText(currentActivity.getString(R.string.rupees_symbol) + " " + totalAmount + "/-");
                            isCheckOut = true;
                            containerCart.setVisibility(View.VISIBLE);
                            textNoItemsInCart.setVisibility(View.GONE);
                            cartModelList.addAll(cartModelListTemp);
                            cartAdapter.notifyDataSetChanged();
                            invalidateOptionsMenu();
                        } else {
                            isCheckOut = false;
                            containerCart.setVisibility(View.GONE);
                            textNoItemsInCart.setVisibility(View.VISIBLE);
                            invalidateOptionsMenu();
                        }
                    } else {
                        isCheckOut = false;
                        containerCart.setVisibility(View.GONE);
                        textNoItemsInCart.setVisibility(View.VISIBLE);
                        invalidateOptionsMenu();
                    }


                } catch (JSONException e) {
                    logTesting("get cart item json exeption is", e.toString(), Log.ERROR);
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                logTesting("error is", error.toString(), Log.ERROR);
                toast(currentActivity.getResources().getString(R.string.errorCartItems), true);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();

                params.put("Content-Type", "application/json");


                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_cart, menu);
        if (isCheckOut) {
            menu.getItem(0).setVisible(true);
        } else {
            menu.getItem(0).setVisible(false);
        }


        menu.getItem(0).setVisible(false);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_check_out: {
                if (cartModelList.size() > 0) {

                    if (bundle == null) {
                        bundle = new Bundle();
                    }
                    bundle.putParcelableArrayList(CART_MODEL_LIST, cartModelList);

                    startActivity(currentActivity, AllAddressesActivity.class, bundle, false, REQUEST_TAG_NO_RESULT, true, ANIMATION_SLIDE_LEFT);

                } else {
                    invalidateOptionsMenu();
                    ((BaseActivity) currentActivity).toast(currentActivity.getResources().getString(R.string.errorAddAtLeastOneItem), true);
                }

                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    private void initUpdateCartModel() {
        UpdateCartModel updateCartModel = new UpdateCartModel();
        updateCartModel.setUserId(SharedPreferenceUtils.getInstance(context).getInteger(AppConstants.USER_ID));
        updateCartModel.setCartModelArrayList(cartModelList);
        updateCart(updateCartModel);
    }

    public void updateCart(UpdateCartModel updateCartModel) {

        progressDialog(currentActivity, currentActivity.getString(R.string.pdialog_message_loading), currentActivity.getString(R.string.pdialog_message_loading), false, false);

        updateCartModel.setDeviceType(DEVICE_TYPE);
        updateCartModel.setLoginId(SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_MOBILE_NO));
        updateCartModel.setAccessToken(DeviceUtils.getDeviceKey());
        updateCartModel.setIpAddress(DeviceUtils.getDeviceIpAddress(context));

        JSONObject jsons = null;
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        try {
            jsons = new JSONObject(gson.toJson(updateCartModel));
            Log.e("jsonUpdateCartItems", jsons.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_UPDATE_CART, jsons, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                logTesting("responce is", response.toString(), Log.ERROR);
                try {
                    logTesting("is successfull UPDATE CART", "hi" + response.getBoolean(AppConstants.KEY_ERROR), Log.ERROR);
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                        setResult(RESULT_OK);
                        finish();
                    } else {
                        cancelProgressDialog();
                        logTesting("UPDATE CART error", "true", Log.ERROR);
                    }

                } catch (JSONException e) {
                    logTesting("UPDATE CART json exeption is", e.toString(), Log.ERROR);
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                logTesting("error is", error.toString(), Log.ERROR);
                toast(getResources().getString(R.string.errorLogin), true);

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Accept", "application/json");
                params.put("Content-Type", "application/json");
                params.put("type", "M");
                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }

}
