package com.app.xervepure.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by Codeslay-03 on 9/20/2017.
 */

public class CreateOrderModel extends BaseRequestModel implements Parcelable {

    @SerializedName("user_id")
    private int userId;
    @SerializedName("order_type")
    private int orderType;
    @SerializedName("address_id")
    private int addressId;
    @SerializedName("order_status")
    private int orderStatus;
    @SerializedName("total_amout")
    private String totalAmout;
    @SerializedName("array_order_product")
    private ArrayList<CartModel> cartModelArrayList;

    public CreateOrderModel() {

    }

    protected CreateOrderModel(Parcel in) {
        userId = in.readInt();
        cartModelArrayList = in.createTypedArrayList(CartModel.CREATOR);
    }

    public static final Creator<CreateOrderModel> CREATOR = new Creator<CreateOrderModel>() {
        @Override
        public CreateOrderModel createFromParcel(Parcel in) {
            return new CreateOrderModel(in);
        }

        @Override
        public CreateOrderModel[] newArray(int size) {
            return new CreateOrderModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(userId);
        dest.writeTypedList(cartModelArrayList);
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public ArrayList<CartModel> getCartModelArrayList() {
        return cartModelArrayList;
    }

    public void setCartModelArrayList(ArrayList<CartModel> cartModelArrayList) {
        this.cartModelArrayList = cartModelArrayList;
    }

    public int getOrderType() {
        return orderType;
    }

    public void setOrderType(int orderType) {
        this.orderType = orderType;
    }

    public int getAddressId() {
        return addressId;
    }

    public void setAddressId(int addressId) {
        this.addressId = addressId;
    }

    public int getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(int orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getTotalAmout() {
        return totalAmout;
    }

    public void setTotalAmout(String totalAmout) {
        this.totalAmout = totalAmout;
    }
}
