package com.app.xervepure.constants;

/**
 * Created by Codeslay-03 on 4/06/2017.
 */

public interface DbConstants {

    /* Sqlite Db*/
    public static final String DATABASE_NAME = "vyaan.db";
    public static final int DATABASE_VERSION = 2;

    /* Tables*/
    public static final String TABLE_USER_TRANSACTION = "tbl_user_tnx";

    /*Table User Columns */
    public static final String COLUMN_TRANSACTION_ID = "transaction_id";
    public static final String COLUMN_USER_ID = "user_id";
    public static final String COLUMN_BALANCE = "balance";
    public static final String COLUMN_CHECKSUMHASH = "checksumhash";
    public static final String COLUMN_PAYMENT_METHOD = "payment_method";

}

