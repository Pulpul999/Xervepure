package com.app.xervepure.interfaces;

/**
 * Created by sac on 25/7/15.
 */
public interface CancellingResendOtpThread {
    public void cancelHandler(boolean iscancel);
}
