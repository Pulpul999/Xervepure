package com.app.xervepure.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

/**
 * Created by Codeslay-03 on 9/20/2017.
 */

public class UpdateCartModel extends BaseRequestModel implements Parcelable {

    @SerializedName("user_id")
    private int userId;
    @SerializedName("array_product")
    private ArrayList<CartModel> cartModelArrayList;

    public UpdateCartModel() {
        super();
    }

    protected UpdateCartModel(Parcel in) {
        userId = in.readInt();
        cartModelArrayList = in.createTypedArrayList(CartModel.CREATOR);
    }

    public static final Creator<UpdateCartModel> CREATOR = new Creator<UpdateCartModel>() {
        @Override
        public UpdateCartModel createFromParcel(Parcel in) {
            return new UpdateCartModel(in);
        }

        @Override
        public UpdateCartModel[] newArray(int size) {
            return new UpdateCartModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(userId);
        dest.writeTypedList(cartModelArrayList);
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public ArrayList<CartModel> getCartModelArrayList() {
        return cartModelArrayList;
    }

    public void setCartModelArrayList(ArrayList<CartModel> cartModelArrayList) {
        this.cartModelArrayList = cartModelArrayList;
    }
}
