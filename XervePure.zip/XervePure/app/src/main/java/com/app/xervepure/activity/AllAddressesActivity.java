package com.app.xervepure.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.app.xervepure.R;
import com.app.xervepure.adapter.AllAddressesAdapter;
import com.app.xervepure.adapter.CheckoutProductAdapter;
import com.app.xervepure.adapter.SubscriptionAdapter;
import com.app.xervepure.application.VyaanApplication;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.model.AddressModel;
import com.app.xervepure.model.CartModel;
import com.app.xervepure.model.CreateOrderModel;
import com.app.xervepure.model.PlaceSubscriptionModel;
import com.app.xervepure.model.ProfileDetailsModel;
import com.app.xervepure.model.RequestModel;
import com.app.xervepure.utils.DeviceUtils;
import com.app.xervepure.utils.FontUtils;
import com.app.xervepure.utils.SharedPreferenceUtils;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AllAddressesActivity extends BaseActivity {

    public ArrayList<CartModel> cartModelList;
    public PlaceSubscriptionModel subscriptionModel;
    public boolean isSubscription;
    private TextView textTotalAmount;
    private TextView labelTotalAmtTV;
    private RecyclerView recyclerAddresses;
    private LinearLayoutManager linearLayoutManager;
    private TextView textNoAddress;
    private TextView textSelectAddress;
    private List<AddressModel> addressModelList = new ArrayList<>();
    private AllAddressesAdapter allAddressesAdapter;
    private CreateOrderModel createOrderModel;

    private Button buttonAddNewAddress;
    private Button buttonPlaceOrder;
    private int orderType;
    private String addressId;
    private int walletRechargeType;
    private double totalAmount;

    private RecyclerView recyclerCartItems;
    private CheckoutProductAdapter cartAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_addresses);
    }

    @Override
    protected void initViews() {
        getSupportActionBar().setTitle(R.string.title_all_addresses);
        buttonPlaceOrder = findViewById(R.id.buttonPlaceOrder);
        if (getIntent().hasExtra(SUBSCRIPTION)) {
            isSubscription = true;
            subscriptionModel = getIntent().getExtras().getParcelable(SUBSCRIPTION_MODEL);
            int qty = Integer.parseInt(subscriptionModel.getDaySubscriptionModels().get(0).getQuantity());
            totalAmount = subscriptionModel.getProductPrice() * qty;
        } else {
            isSubscription = false;
            cartModelList = getIntent().getExtras().getParcelableArrayList(CART_MODEL_LIST);
            orderType = getIntent().getExtras().getInt("order_type");
            initCreateOrderModel();
        }
        recyclerCartItems = (RecyclerView) findViewById(R.id.recyclerCartItems);
        recyclerAddresses = (RecyclerView) findViewById(R.id.recyclerAddresses);
        textNoAddress = (TextView) findViewById(R.id.textNoAddress);
        buttonAddNewAddress = (Button) findViewById(R.id.buttonAddNewAddress);
        textTotalAmount = (TextView) findViewById(R.id.textTotalAmount);
        labelTotalAmtTV = (TextView) findViewById(R.id.labelTotalAmtTV);
        textSelectAddress = findViewById(R.id.textSelectAddress);
        linearLayoutManager = new LinearLayoutManager(currentActivity);
        recyclerAddresses.setLayoutManager(linearLayoutManager);
        allAddressesAdapter = new AllAddressesAdapter(currentActivity, addressModelList);
        recyclerAddresses.setAdapter(allAddressesAdapter);
        recyclerAddresses.setNestedScrollingEnabled(false);

        if (!isSubscription) {
            recyclerCartItems.setVisibility(View.VISIBLE);
            cartAdapter = new CheckoutProductAdapter(currentActivity, cartModelList);
            recyclerCartItems.setAdapter(cartAdapter);
            recyclerCartItems.setLayoutManager(new LinearLayoutManager(currentActivity));
        } else {
            if (subscriptionModel != null) {
                SubscriptionAdapter subscriptionAdapter;
                ArrayList<PlaceSubscriptionModel> subscriptionDetailsModels = new ArrayList<>();
                subscriptionDetailsModels.add(subscriptionModel);
                recyclerCartItems.setVisibility(View.VISIBLE);
                subscriptionAdapter = new SubscriptionAdapter(currentActivity, subscriptionDetailsModels,1);
                recyclerCartItems.setAdapter(subscriptionAdapter);
                recyclerCartItems.setLayoutManager(new LinearLayoutManager(currentActivity));
            }
        }


        FontUtils.changeFont(currentActivity, labelTotalAmtTV, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, textTotalAmount, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, textNoAddress, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, buttonAddNewAddress, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, buttonPlaceOrder, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, textSelectAddress, AppConstants.FONT_ROBOTO_MEDIUM);

        textTotalAmount.setText(currentActivity.getString(R.string.rupees_symbol) + " " + totalAmount + "/-");
        getWalletBalance();
        myAdresses();
    }

    @Override
    protected void initContext() {
        currentActivity = AllAddressesActivity.this;
        context = AllAddressesActivity.this;
    }

    @Override
    protected void initListners() {
        buttonAddNewAddress.setOnClickListener(this);
        buttonPlaceOrder.setOnClickListener(this);
    }

    @Override
    protected boolean isActionBar() {
        return true;
    }

    @Override
    protected boolean isHomeButton() {
        return true;
    }


    @Override
    public void onAlertClicked(int alertType) {
        String addressId = "0";
        for (int i = 0; i < addressModelList.size(); i++) {
            AddressModel addressModel = addressModelList.get(i);
            if (addressModel == null) continue;
            if (addressModel.isSelected()) {
                addressId = addressModel.getId();
                break;
            }
        }
        if (alertType == ALERT_TYPE_ADD_AMOUNT) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putBoolean("isCart", true);
            startActivity(currentActivity, WalletActivity.class, bundle, true, REQUEST_TAG_WALLET_ACTIVITY, true, ANIMATION_SLIDE_UP);
        } else if (alertType == ALERT_TYPE_PLACE_SUBSCRIPTIPN) {
            placeSubscription(addressId);
        } else if (alertType == ALERT_TYPE_PLACE_ORDER) {
            placeOrder(addressId);
        }
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.buttonAddNewAddress: {

                ((BaseActivity) currentActivity).startActivity(currentActivity, NewAddressActivity.class, bundle, true, AppConstants.REQUEST_TAG_NEW_ADDRESS_ACTIVITY, true, AppConstants.ANIMATION_SLIDE_LEFT);

                break;
            }
            case R.id.buttonPlaceOrder: {
                if (!addressModelList.isEmpty()) {
                    if (isSubscription) {

                        alert(currentActivity, currentActivity.getString(R.string.titlePlaceSubscription), currentActivity.getString(R.string.messagePlaceSubscription), currentActivity.getString(R.string.labelOk), currentActivity.getString(R.string.labelCancel), true, true, AppConstants.ALERT_TYPE_PLACE_SUBSCRIPTIPN);

                    } else {

                        alert(currentActivity, currentActivity.getString(R.string.titlePlaceOrder), currentActivity.getString(R.string.messagePlaceOrder), currentActivity.getString(R.string.labelOk), currentActivity.getString(R.string.labelCancel), true, true, AppConstants.ALERT_TYPE_PLACE_ORDER);
                    }
                    return;
                } else {
                    toast("Please add the address first", true);
                }
                break;
            }
        }

    }

    private void initCreateOrderModel() {
        createOrderModel = new CreateOrderModel();
        createOrderModel.setUserId(SharedPreferenceUtils.getInstance(context).getInteger(USER_ID));
        double totalAmount = 0;
        for (int i = 0; i < cartModelList.size(); i++) {
            CartModel cartModel = cartModelList.get(i);
            if (cartModel == null) continue;
            totalAmount += (cartModel.getProductPrice() * cartModel.getProductQuantity());
        }
        this.totalAmount = totalAmount;
        createOrderModel.setCartModelArrayList(cartModelList);
        createOrderModel.setTotalAmout(totalAmount + "");
        createOrderModel.setOrderType(orderType);
    }

    private void initRequestModel() {
        RequestModel.getInstance().setDeviceType(DEVICE_TYPE);
        RequestModel.getInstance().setLoginId(SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_MOBILE_NO));
        RequestModel.getInstance().setAccessToken(DeviceUtils.getDeviceKey());
        RequestModel.getInstance().setIpAddress(DeviceUtils.getDeviceIpAddress(context));
    }

    public void myAdresses() {

        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);
        int userId = SharedPreferenceUtils.getInstance(currentActivity).getInteger(AppConstants.USER_ID);
        initRequestModel();
        JSONObject jsons = null;
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        try {
            jsons = new JSONObject(gson.toJson(RequestModel.getInstance()));
            jsons.put("user_id", userId);
            Log.e("jsonMyAdresses", jsons.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        String complaeteUrlAllAddresses = URL_ALL_ADDRESSES;

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, complaeteUrlAllAddresses, jsons, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                ((BaseActivity) currentActivity).logTesting("addresses responce is", response.toString(), Log.ERROR);

                try {
                    cancelProgressDialog();
                    ((BaseActivity) currentActivity).logTesting("is successfull fetch addresses", "hi" + response.getBoolean(AppConstants.KEY_ERROR), Log.ERROR);
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                        addressModelList.clear();
                        Gson gson = new Gson();
                        List<AddressModel> addressModelListTemp = Arrays.asList(gson.fromJson(response.getJSONArray(MESSAGE).toString(), AddressModel[].class));
                        Log.e("addresses list size", "" + addressModelListTemp.size());

                        if (addressModelListTemp.size() > 0) {

                            AddressModel addressModel = addressModelListTemp.get(0);

                            if (addressModel != null) {
                                addressModel.setSelected(true);
                                boolean isEmpty = false;
                                String userName = SharedPreferenceUtils.getInstance(context).getString(USER_NAME);
                                if (TextUtils.isEmpty(userName)) {
                                    userName = addressModel.getName();
                                    SharedPreferenceUtils.getInstance(currentActivity).putString(USER_NAME, userName);
                                    isEmpty = true;
                                }
                                String email = SharedPreferenceUtils.getInstance(context).getString(USER_EMAIL);
                                if (TextUtils.isEmpty(email)) {
                                    email = addressModel.getPhoneNumber();
                                    if (email != null && email.matches("[0-9]+") && email.length() > 2) {
                                        // phone number
                                        email = "";
                                    } else {
                                        SharedPreferenceUtils.getInstance(currentActivity).putString(AppConstants.USER_EMAIL, userName);
                                    }
                                    isEmpty = true;
                                }
                                if (isEmpty) {
                                    initProfileDetailsModel(userName, email);
                                    updateProfile();
                                }
                            }

                            recyclerAddresses.setVisibility(View.VISIBLE);
                            textSelectAddress.setVisibility(View.VISIBLE);
                            textNoAddress.setVisibility(View.GONE);
                            addressModelList.addAll(addressModelListTemp);
                            allAddressesAdapter.notifyDataSetChanged();
                            if (addressModelListTemp.size() >= 2) {
                                buttonAddNewAddress.setVisibility(View.VISIBLE);
                            } else {
                                buttonAddNewAddress.setVisibility(View.VISIBLE);
                            }
                        } else {
                            recyclerAddresses.setVisibility(View.GONE);
                            textSelectAddress.setVisibility(View.GONE);
                            textNoAddress.setVisibility(View.VISIBLE);
                            buttonAddNewAddress.setVisibility(View.VISIBLE);
                        }

                    } else {
                        cancelProgressDialog();
                        ((BaseActivity) currentActivity).logTesting("fetch addresses error", "true", Log.ERROR);
                    }


                } catch (JSONException e) {
                    recyclerAddresses.setVisibility(View.GONE);
                    textSelectAddress.setVisibility(View.GONE);
                    textNoAddress.setVisibility(View.VISIBLE);
                    ((BaseActivity) currentActivity).logTesting("fetch addresses json exeption is", e.toString(), Log.ERROR);
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                ((BaseActivity) currentActivity).logTesting("error is", error.toString(), Log.ERROR);
                ((BaseActivity) currentActivity).toast(getResources().getString(R.string.errorMyAddresses), true);

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();

                params.put("Content-Type", "application/json");

                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }

    private void initProfileDetailsModel(String name, String email) {
        ProfileDetailsModel.getInstance().setDeviceType(DEVICE_TYPE);
        ProfileDetailsModel.getInstance().setLoginId(SharedPreferenceUtils.getInstance(context).getString(USER_MOBILE_NO));
        ProfileDetailsModel.getInstance().setAccessToken(DeviceUtils.getDeviceKey());
        ProfileDetailsModel.getInstance().setIpAddress(DeviceUtils.getDeviceIpAddress(context));
        ProfileDetailsModel.getInstance().setUserId(SharedPreferenceUtils.getInstance(context).getInteger(USER_ID));
        ProfileDetailsModel.getInstance().setName(name);
        ProfileDetailsModel.getInstance().setEmailId(email);
        String userImage = SharedPreferenceUtils.getInstance(context).getString(USER_PROFILE_IMAGE);
        if (TextUtils.isEmpty(userImage)) {
            ProfileDetailsModel.getInstance().setUserImageName("");
        }
    }


    private void updateProfile() {

        JSONObject jsonUpdateUser = null;
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        try {
            jsonUpdateUser = new JSONObject(gson.toJson(ProfileDetailsModel.getInstance()));
            Log.e("jsonUpdateUser", jsonUpdateUser.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest profileUpdateRequest = new JsonObjectRequest(Request.Method.POST, UPDATE_USER_PROFILE, jsonUpdateUser, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                logTesting(getResources().getString(R.string.nwk_response_edit_profile), response.toString(), Log.ERROR);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                logTesting(getResources().getString(R.string.nwk_error_edit_profile), error.toString(), Log.ERROR);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                return super.getHeaders();
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(profileUpdateRequest);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_TAG_EDIT_ADDRESS_ACTIVITY) {
                myAdresses();
            } else if (requestCode == REQUEST_TAG_NEW_ADDRESS_ACTIVITY) {
                myAdresses();
            } else if (requestCode == REQUEST_TAG_WALLET_ACTIVITY) {
                if (walletRechargeType == TYPE_SUBSCRIPTION) {
                    placeSubscription(this.addressId);
                } else if (walletRechargeType == TYPE_ORDER) {
                    placeOrder(addressId);
                }
            }
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    private boolean isLowOrderbalance() {
        String walletBalance = SharedPreferenceUtils.getInstance(context).getString(USER_WALLET_BALANCE);
        if (!TextUtils.isEmpty(walletBalance)) {
            Double totalBalance = Double.parseDouble(walletBalance);
            if (totalBalance < totalAmount) {
                return true;
            }
        } else {
            return true;
        }
        return false;
    }

    private boolean isLowSubscriptionbalance() {
        String walletBalance = SharedPreferenceUtils.getInstance(context).getString(USER_WALLET_BALANCE);
        if (!TextUtils.isEmpty(walletBalance)) {
            Double totalBalance = Double.parseDouble(walletBalance);
            if (totalBalance < MIN_SUBSCRIPTION_AMOUNT) {
                return true;
            }
        } else {
            return true;
        }
        return false;
    }

    public void placeSubscription(String addressId) {
        if (TextUtils.isEmpty(addressId) || subscriptionModel == null) return;
        this.addressId = addressId;
        walletRechargeType = TYPE_SUBSCRIPTION;

        if (isLowSubscriptionbalance()) {
            alert(currentActivity, getString(R.string.alert_low_balance), getString(R.string.msg_low_subscription_balance), getResources().getString(R.string.alert_add_amount), getResources().getString(R.string.alert_cancel_button_text_no_network), true, true, ALERT_TYPE_ADD_AMOUNT);
            return;
        }
        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);

        subscriptionModel.setDeviceType(DEVICE_TYPE);
        subscriptionModel.setLoginId(SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_MOBILE_NO));
        subscriptionModel.setAccessToken(DeviceUtils.getDeviceKey());
        subscriptionModel.setIpAddress(DeviceUtils.getDeviceIpAddress(context));
        subscriptionModel.setAddressId(Integer.parseInt(addressId));
        String json = new Gson().toJson(subscriptionModel);
        logTesting("placeSubscriptionrequestjson", json, Log.ERROR);
        JSONObject jsons = null;
        try {
            jsons = new JSONObject(json);
            new Gson().toJson(json);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_PLACE_SUSCRIPTION, jsons, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                cancelProgressDialog();
                logTesting("placeSubscriptionresp", response.toString(), Log.ERROR);

                try {
                    logTesting("is successfull place Subscription", "hi" + response.getBoolean(AppConstants.KEY_ERROR), Log.ERROR);
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                        String message = response.getString(RESPONCE_MESSAGE);
                        JSONObject messageJson = new JSONObject(message);

                        if (bundle == null) {
                            bundle = new Bundle();
                        }
                        bundle.putString(KEY_SUBSCRIPTION_ID, messageJson.getString(KEY_SUBSCRIPTION_ID));
                        startActivity(currentActivity, OrderInfoActivity.class, bundle, false, REQUEST_TAG_NO_RESULT, true, ANIMATION_SLIDE_LEFT);
                        finish();

                    } else {
                        alert(currentActivity, "", "Failed to place your subscription.", currentActivity.getString(R.string.labelOk), currentActivity.getString(R.string.labelCancel), false, true, AppConstants.ALERT_TYPE_NO_NETWORK);

                        logTesting("place Subscription error", "true", Log.ERROR);
                    }


                } catch (JSONException e) {
                    logTesting("place Subscription json exeption is", e.toString(), Log.ERROR);
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                logTesting("error is", error.toString(), Log.ERROR);
                toast(getResources().getString(R.string.errorAddSubscription), true);

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Accept", "application/json");
                params.put("Content-Type", "application/json");
                params.put("type", "M");

                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }

    public void placeOrder(String addressId) {
        if (TextUtils.isEmpty(addressId) || createOrderModel == null) return;
        this.addressId = addressId;
        walletRechargeType = TYPE_ORDER;
        if (isLowOrderbalance()) {
            alert(currentActivity, getString(R.string.alert_low_balance), getString(R.string.msg_low_balance), getResources().getString(R.string.alert_add_amount), getResources().getString(R.string.alert_cancel_button_text_no_network), true, true, ALERT_TYPE_ADD_AMOUNT);
            return;
        }

        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);

        createOrderModel.setDeviceType(DEVICE_TYPE);
        createOrderModel.setLoginId(SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_MOBILE_NO));
        createOrderModel.setAccessToken(DeviceUtils.getDeviceKey());
        createOrderModel.setIpAddress(DeviceUtils.getDeviceIpAddress(context));

        createOrderModel.setAddressId(Integer.parseInt(addressId));
        String json = new Gson().toJson(createOrderModel);
        logTesting("placeOrderRequestJson", json, Log.ERROR);
        JSONObject jsons = null;
        try {
            jsons = new JSONObject(json);
            new Gson().toJson(json);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_ADD_ORDER, jsons, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                cancelProgressDialog();
                logTesting("place Order is", response.toString(), Log.ERROR);

                try {
                    logTesting("is successfull place Order", "hi" + response.getBoolean(AppConstants.KEY_ERROR), Log.ERROR);
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                        //toast(getString(R.string.message_order_placed), true);
                        String message = response.getString(RESPONCE_MESSAGE);
                        JSONObject messageJson = new JSONObject(message);

                        if (bundle == null) {
                            bundle = new Bundle();
                        }
                        bundle.putString(KEY_ORDER_ID, messageJson.getString(KEY_ORDER_ID));
                        startActivity(currentActivity, OrderInfoActivity.class, bundle, false, REQUEST_TAG_NO_RESULT, true, ANIMATION_SLIDE_LEFT);
                        finish();

                    } else {
                        logTesting("place Order error", "true", Log.ERROR);
                        alert(currentActivity, "", "Failed to place your order.", currentActivity.getString(R.string.labelOk), currentActivity.getString(R.string.labelCancel), false, true, AppConstants.ALERT_TYPE_NO_NETWORK);
                    }


                } catch (JSONException e) {
                    logTesting("place Order json exeption is", e.toString(), Log.ERROR);
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                logTesting("error is", error.toString(), Log.ERROR);
                toast(getResources().getString(R.string.errorPlaceOrder), true);

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Accept", "application/json");
                params.put("Content-Type", "application/json");
                params.put("type", "M");

                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }

    private void getWalletBalance() {
        initRequestModel();
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        JSONObject jsonGetBalanceRequest = null;
        try {
            jsonGetBalanceRequest = new JSONObject(gson.toJson(RequestModel.getInstance()));
            jsonGetBalanceRequest.put(KEY_USER_ID, SharedPreferenceUtils.getInstance(context).getInteger(USER_ID));
            Log.e("jsonGetBalanceRequest", jsonGetBalanceRequest.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_GET_WALLET_BALANCE, jsonGetBalanceRequest, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                        String message = response.getString(RESPONCE_MESSAGE);
                        JSONObject messageJson = new JSONObject(message);
                        String totalBalance = messageJson.getString(USER_WALLET_BALANCE);
                        SharedPreferenceUtils.getInstance(context).putString(USER_WALLET_BALANCE, totalBalance);
                    } else {
                        ((BaseActivity) currentActivity).logTesting("GETWalletBalance", "true", Log.ERROR);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                ((BaseActivity) currentActivity).logTesting("error is", error.toString(), Log.ERROR);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();

                params.put("Content-Type", "application/json");

                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }
}
