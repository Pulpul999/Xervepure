package com.app.xervepure.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.app.xervepure.R;
import com.app.xervepure.adapter.CartAdapter;
import com.app.xervepure.application.VyaanApplication;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.model.CartModel;
import com.app.xervepure.model.RequestModel;
import com.app.xervepure.utils.DeviceUtils;
import com.app.xervepure.utils.FontUtils;
import com.app.xervepure.utils.SharedPreferenceUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CartActivity extends BaseActivity {


    private TextView textTotalAmount;
    private TextView labelTotalAmtTV;
    private TextView updateTextView;
    private RecyclerView recyclerCartItems;
    private LinearLayoutManager linearLayoutManager;
    private ArrayList<CartModel> cartModelList;
    private Button buttonCheckOut;
    private CartAdapter cartAdapter;

    private TextView textNoItemsInCart;
    private LinearLayout totalItemLL;
    private LinearLayout containerCart;

    private boolean isCheckOut;
    private double totalAmount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
    }

    @Override
    protected void initViews() {

        linearLayoutManager = new LinearLayoutManager(currentActivity);

        cartModelList = new ArrayList<>();
        textNoItemsInCart = (TextView) findViewById(R.id.textNoItemsInCart);
        textTotalAmount = (TextView) findViewById(R.id.textTotalAmount);
        labelTotalAmtTV = (TextView) findViewById(R.id.labelTotalAmtTV);
        updateTextView = (TextView) findViewById(R.id.updateTextView);
        recyclerCartItems = (RecyclerView) findViewById(R.id.recyclerCartItems);
        containerCart = (LinearLayout) findViewById(R.id.containerCart);
        totalItemLL = (LinearLayout) findViewById(R.id.totalItemLL);
        cartAdapter = new CartAdapter(currentActivity, cartModelList);

        recyclerCartItems.setAdapter(cartAdapter);
        recyclerCartItems.setLayoutManager(linearLayoutManager);
        FontUtils.changeFont(currentActivity, labelTotalAmtTV, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, textTotalAmount, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, updateTextView, AppConstants.FONT_ROBOTO_MEDIUM);
        getSupportActionBar().setTitle(R.string.title_cart);
        getCartItems();

        buttonCheckOut = (Button) findViewById(R.id.buttonCheckOut);

    }

    @Override
    protected void initContext() {
        currentActivity = CartActivity.this;
        context = CartActivity.this;
    }

    @Override
    protected void initListners() {
        buttonCheckOut.setOnClickListener(this);
        //updateTextView.setOnClickListener(this);
    }

    @Override
    protected boolean isActionBar() {
        return true;
    }

    @Override
    protected boolean isHomeButton() {
        return true;
    }


    @Override
    public void onAlertClicked(int alertType) {
        if (alertType == ALERT_TYPE_ADD_AMOUNT) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            bundle.putBoolean("isCart", true);
            startActivity(currentActivity, Dashboard.class, bundle, false, REQUEST_TAG_NO_RESULT, false, ANIMATION_SLIDE_UP);
            finish();
        }
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.updateTextView: {
                startActivity(currentActivity, EditCartActivity.class, bundle, true, REQUEST_TAG_EDIT_CART_ACTIVITY, true, ANIMATION_SLIDE_LEFT);
                break;
            }
            case R.id.buttonCheckOut: {
                if (cartModelList.size() > 0) {
                    /*String walletBalance = SharedPreferenceUtils.getInstance(context).getString(USER_WALLET_BALANCE);
                    if (!TextUtils.isEmpty(walletBalance)) {
                        Double totalBalance = Double.parseDouble(walletBalance);
                        if (totalBalance < totalAmount) {
                            alert(currentActivity, getString(R.string.alert_low_balance), getString(R.string.msg_low_balance), getResources().getString(R.string.alert_add_amount), getResources().getString(R.string.alert_cancel_button_text_no_network), true, true, ALERT_TYPE_ADD_AMOUNT);
                            return;
                        }
                    } else {
                        alert(currentActivity, getString(R.string.alert_low_balance), getString(R.string.msg_low_balance), getResources().getString(R.string.alert_add_amount), getResources().getString(R.string.alert_cancel_button_text_no_network), true, true, ALERT_TYPE_ADD_AMOUNT);
                        return;
                    }*/
                    if (bundle == null) {
                        bundle = new Bundle();
                    }
                    bundle.putInt("order_type", TYPE_ORDER);
                    bundle.putParcelableArrayList(CART_MODEL_LIST, cartModelList);
                    startActivity(currentActivity, AllAddressesActivity.class, bundle, false, REQUEST_TAG_NO_RESULT, true, ANIMATION_SLIDE_LEFT);
                } else {
                    ((BaseActivity) currentActivity).toast(currentActivity.getResources().getString(R.string.errorAddAtLeastOneItem), true);
                }
                break;
            }
        }

    }

    private void initRequestModel() {
        RequestModel.getInstance().setDeviceType(DEVICE_TYPE);
        RequestModel.getInstance().setLoginId(SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_MOBILE_NO));
        RequestModel.getInstance().setAccessToken(DeviceUtils.getDeviceKey());
        RequestModel.getInstance().setIpAddress(DeviceUtils.getDeviceIpAddress(context));
    }

    public void getCartItems() {


        progressDialog(currentActivity, currentActivity.getString(R.string.pdialog_message_loading), currentActivity.getString(R.string.pdialog_message_loading), false, false);

        int userId = SharedPreferenceUtils.getInstance(currentActivity).getInteger(AppConstants.USER_ID);
        initRequestModel();
        JSONObject jsons = null;
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        try {
            jsons = new JSONObject(gson.toJson(RequestModel.getInstance()));
            jsons.put("user_id", userId);
            Log.e("jsonGetCartItems", jsons.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_GET_CART_ITEMS, jsons, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                logTesting("get cart item responce is", response.toString(), Log.ERROR);
                try {
                    cancelProgressDialog();
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                        cartModelList.clear();
                        Gson gson = new Gson();
                        List<CartModel> cartModelListTemp = Arrays.asList(gson.fromJson(response.getJSONArray(RESPONCE_MESSAGE).toString(), CartModel[].class));

                        if (cartModelListTemp.size() > 0) {
                            totalAmount = 0;
                            for (int i = 0; i < cartModelListTemp.size(); i++) {
                                CartModel cartModel = cartModelListTemp.get(i);
                                if (cartModel == null) continue;
                                totalAmount += (cartModel.getProductPrice() * cartModel.getProductQuantity());
                            }

                            textTotalAmount.setText(currentActivity.getString(R.string.rupees_symbol) + " " + totalAmount + "/-");
                            isCheckOut = true;
                            containerCart.setVisibility(View.VISIBLE);
                            textNoItemsInCart.setVisibility(View.GONE);
                            totalItemLL.setVisibility(View.VISIBLE);
                            cartModelList.addAll(cartModelListTemp);
                            cartAdapter.notifyDataSetChanged();
                            invalidateOptionsMenu();
                        } else {
                            isCheckOut = false;
                            containerCart.setVisibility(View.GONE);
                            totalItemLL.setVisibility(View.GONE);
                            textNoItemsInCart.setVisibility(View.VISIBLE);
                            invalidateOptionsMenu();
                        }
                    } else {
                        isCheckOut = false;
                        containerCart.setVisibility(View.GONE);
                        totalItemLL.setVisibility(View.GONE);
                        textNoItemsInCart.setVisibility(View.VISIBLE);
                        invalidateOptionsMenu();
                    }


                } catch (JSONException e) {
                    logTesting("get cart item json exeption is", e.toString(), Log.ERROR);
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                totalItemLL.setVisibility(View.GONE);
                isCheckOut = false;
                logTesting("error is", error.toString(), Log.ERROR);
                toast(currentActivity.getResources().getString(R.string.errorCartItems), true);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();

                params.put("Content-Type", "application/json");


                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_cart, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_check_out: {
                startActivity(currentActivity, EditCartActivity.class, bundle, true, REQUEST_TAG_EDIT_CART_ACTIVITY, true, ANIMATION_SLIDE_LEFT);
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (resultCode == RESULT_OK) {
            switch (requestCode) {

                case REQUEST_TAG_EDIT_CART_ACTIVITY: {
                    getCartItems();
                    break;
                }
            }
        }
        super.onActivityResult(requestCode, resultCode, data);

    }

    @Override
    public void onStart() {
        super.onStart();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
    }
}
