package com.app.xervepure.fragments;


import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.app.xervepure.R;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.utils.FontUtils;
import com.app.xervepure.utils.SharedPreferenceUtils;

import java.io.ByteArrayOutputStream;

/**
 * A simple {@link Fragment} subclass.
 */
public class ReferEarnFragment extends BaseFragment {


    private TextView text1;
    private TextView text2;
    private TextView text3;
    private Button valRefCode;
    private Button referButton;

    public ReferEarnFragment() {
        // Required empty public constructor
    }


    @Override
    public void alertOkClicked() {

    }

    @Override
    protected void initViews() {
        text1 = view.findViewById(R.id.text1);
        text2 = view.findViewById(R.id.text2);
        text3 = view.findViewById(R.id.text3);
        referButton = view.findViewById(R.id.referButton);
        valRefCode = view.findViewById(R.id.valRefCode);
        FontUtils.changeFont(context, referButton, FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(context, valRefCode, FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(context, text1, FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(context, text3, FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(context, text2, FONT_ROBOTO_REGULAR);
        valRefCode.setText(SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_REF_CODE));
    }

    @Override
    protected void initContext() {
        context = getActivity();
        currentActivity = getActivity();
    }

    @Override
    protected void initListners() {
        referButton.setOnClickListener(this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return view = inflater.inflate(R.layout.fragment_refer_earn, container, false);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.referButton: {
                goToWhatsApp();
                break;
            }
        }
    }

    public void goToWhatsApp() {
        try {
            String refCode = SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_REF_CODE);
            String shareText = "Install the XervePure milk app here - https://bit.ly/2Jx6g1F with my referral code " + refCode+
                    " and get cash back!!!";
            Intent whatsappIntent = new Intent(Intent.ACTION_SEND);
            whatsappIntent.setType("text/plain");
            //whatsappIntent.setPackage("com.whatsapp");
            whatsappIntent.putExtra(Intent.EXTRA_TEXT, shareText);
            whatsappIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            try {
                startActivity(whatsappIntent);
            } catch (android.content.ActivityNotFoundException ex) {
                Toast.makeText(currentActivity, "Whatsapp have not been installed.", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
