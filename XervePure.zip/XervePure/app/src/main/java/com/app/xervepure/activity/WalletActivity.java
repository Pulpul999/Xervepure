package com.app.xervepure.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.app.xervepure.R;
import com.app.xervepure.application.VyaanApplication;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.dao.UserDataSource;
import com.app.xervepure.model.RequestModel;
import com.app.xervepure.model.WalletModel;
import com.app.xervepure.utils.DeviceUtils;
import com.app.xervepure.utils.FontUtils;
import com.app.xervepure.utils.SharedPreferenceUtils;
import com.app.xervepure.utils.Validator;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class WalletActivity extends BaseActivity {

    private UserDataSource userDataSource;
    private TextView labelwalletBalanceTV;
    private TextView currentBalanceTV;
    private TextView labelWalletHistoryTV;
    private TextView labelSelectAmtTV;
    private TextView rupees100TV;
    private TextView rupees500TV;
    private TextView rupees1000TV;
    private EditText editAmount;
    private TextView labelSelectPaymentTV;

    private ImageView chequeIV;
    private TextView chequeTV;
    private ImageView onlineIV;
    private TextView onlineTV;
    private ImageView paytmIV;
    private TextView paytmTV;
    private Button btnAddAmount;

    private int paymentMethod = PAYMENT_METHOD_PAYTM;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_wallet);
    }

    @Override
    protected void initViews() {
        settingTitle(getString(R.string.title_wallet));
        userDataSource = new UserDataSource(context);

        labelwalletBalanceTV = (TextView) findViewById(R.id.labelwalletBalanceTV);
        currentBalanceTV = (TextView) findViewById(R.id.currentBalanceTV);
        labelWalletHistoryTV = (TextView) findViewById(R.id.labelWalletHistoryTV);
        labelSelectAmtTV = (TextView) findViewById(R.id.labelSelectAmtTV);
        rupees100TV = (TextView) findViewById(R.id.rupees100TV);
        rupees500TV = (TextView) findViewById(R.id.rupees500TV);
        rupees1000TV = (TextView) findViewById(R.id.rupees1000TV);
        editAmount = (EditText) findViewById(R.id.editAmount);
        labelSelectPaymentTV = (TextView) findViewById(R.id.labelSelectPaymentTV);

        chequeIV = (ImageView) findViewById(R.id.chequeIV);
        chequeTV = (TextView) findViewById(R.id.chequeTV);
        onlineIV = (ImageView) findViewById(R.id.onlineIV);
        onlineTV = (TextView) findViewById(R.id.onlineTV);
        paytmIV = (ImageView) findViewById(R.id.paytmIV);
        paytmTV = (TextView) findViewById(R.id.paytmTV);
        btnAddAmount = (Button) findViewById(R.id.btnAddAmount);

        String walletBalance = SharedPreferenceUtils.getInstance(context).getString(USER_WALLET_BALANCE);
        if (TextUtils.isEmpty(walletBalance)) {
            walletBalance = "0";
        }
        currentBalanceTV.setText(getString(R.string.rupees_symbol) + walletBalance);

        FontUtils.changeFont(context, labelwalletBalanceTV, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(context, currentBalanceTV, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(context, labelWalletHistoryTV, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(context, labelSelectAmtTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(context, rupees100TV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(context, rupees500TV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(context, rupees1000TV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(context, editAmount, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(context, labelSelectPaymentTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(context, chequeTV, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(context, onlineTV, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(context, paytmTV, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(context, btnAddAmount, AppConstants.FONT_ROBOTO_MEDIUM);

        getWalletBalance();
    }

    @Override
    protected void initContext() {
        context = WalletActivity.this;
        currentActivity = WalletActivity.this;
    }

    @Override
    protected void initListners() {
        chequeIV.setOnClickListener(this);
        onlineIV.setOnClickListener(this);
        paytmIV.setOnClickListener(this);
        rupees100TV.setOnClickListener(this);
        rupees500TV.setOnClickListener(this);
        rupees1000TV.setOnClickListener(this);
        btnAddAmount.setOnClickListener(this);
        labelWalletHistoryTV.setOnClickListener(this);
    }

    @Override
    protected boolean isActionBar() {
        return true;
    }

    @Override
    protected boolean isHomeButton() {
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.chequeIV: {
                chequeIV.setImageResource(R.drawable.cheque_blue_icon);
                onlineIV.setImageResource(R.drawable.payu_un_icon);
                paytmIV.setImageResource(R.drawable.paytm_un_icon);
                chequeTV.setTextColor(ContextCompat.getColor(context, R.color.colorSecondary));
                onlineTV.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                paytmTV.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                paymentMethod = PAYMENT_METHOD_CHEQUE;
                break;
            }
            case R.id.onlineIV: {
                chequeIV.setImageResource(R.drawable.cheque_icon);
                onlineIV.setImageResource(R.drawable.payu_icon);
                paytmIV.setImageResource(R.drawable.paytm_un_icon);
                chequeTV.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                onlineTV.setTextColor(ContextCompat.getColor(context, R.color.colorSecondary));
                paytmTV.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                paymentMethod = PAYMENT_METHOD_ONLINE;
                break;
            }
            case R.id.paytmIV: {
                chequeIV.setImageResource(R.drawable.cheque_icon);
                onlineIV.setImageResource(R.drawable.payu_un_icon);
                paytmIV.setImageResource(R.drawable.paytm_icon);
                chequeTV.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                onlineTV.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                paytmTV.setTextColor(ContextCompat.getColor(context, R.color.colorSecondary));
                paymentMethod = PAYMENT_METHOD_PAYTM;
                break;
            }
            case R.id.rupees100TV: {
                editAmount.setText(AMOUNT_100);
                break;
            }
            case R.id.rupees500TV: {
                editAmount.setText(AMOUNT_500);
                break;
            }
            case R.id.rupees1000TV: {
                editAmount.setText(AMOUNT_1000);
                break;
            }
            case R.id.btnAddAmount: {
                toHideKeyboard();
                if (Validator.isNetworkAvailable(currentActivity)) {
                    if (isMandatoryFields()) {
                        if (paymentMethod == PAYMENT_METHOD_ONLINE) {
                            Bundle bundle = new Bundle();
                            bundle.putString(KEY_AMOUNT, editAmount.getText().toString());
                            ((BaseActivity) currentActivity).startActivity(currentActivity, PayUActivity.class, bundle, true, REQUEST_TAG_PAYU_PAYMENT_ACTIVITY, true, ANIMATION_SLIDE_UP);
                        } else if (paymentMethod == PAYMENT_METHOD_PAYTM) {
                            Bundle bundle = new Bundle();
                            bundle.putString(KEY_AMOUNT, editAmount.getText().toString());
                            ((BaseActivity) currentActivity).startActivity(currentActivity, RazorpayWalletActivity.class, bundle, true, REQUEST_TAG_PAYTM_PAYMENT_ACTIVITY, true, ANIMATION_SLIDE_UP);
                        } else {
                            Bundle bundle = new Bundle();
                            bundle.putString(KEY_AMOUNT, editAmount.getText().toString());
                            ((BaseActivity) currentActivity).startActivity(currentActivity, SubmitChequeActivity.class, bundle, true, REQUEST_TAG_CHEQUE_PAYMENT_ACTIVITY, true, ANIMATION_SLIDE_UP);
                        }
                    }
                } else {
                    alert(currentActivity, getString(R.string.alert_message_no_network), getString(R.string.alert_message_no_network), getString(R.string.labelOk), getString(R.string.labelCancel), false,false,ALERT_TYPE_NO_NETWORK);
                }
                break;
            }
            case R.id.labelWalletHistoryTV: {
                ((BaseActivity) currentActivity).startActivity(currentActivity, WalletHistoryActivity.class, bundle, true, REQUEST_TAG_NO_RESULT, true, ANIMATION_SLIDE_UP);
                break;
            }
        }
    }

    private boolean isMandatoryFields() {

        editAmount.setError(null);

        if (editAmount.getText().toString().isEmpty()) {
            editAmount.setError(getResources().getString(R.string.error_enter_amt));
            editAmount.requestFocus();
            return false;
        } else if (paymentMethod == 0) {
            toast(getResources().getString(R.string.error_select_method), true);
            return false;
        }
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_TAG_PAYU_PAYMENT_ACTIVITY && resultCode == RESULT_OK) {
            if (data == null) return;
            String transactionId = data.getStringExtra(TRANSACTION_ID);
            initWalletModel(transactionId);
        } else if (requestCode == REQUEST_TAG_CHEQUE_PAYMENT_ACTIVITY && resultCode == RESULT_OK) {
            chequeIV.setImageResource(R.drawable.cheque_icon);
            chequeTV.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
            editAmount.setText("");
        } else if (requestCode == REQUEST_TAG_PAYTM_PAYMENT_ACTIVITY && resultCode == RESULT_OK) {
            if (data == null) return;
            String transactionId = data.getStringExtra(TRANSACTION_ID);
            initWalletModel(transactionId);
        }
    }

    private void initRequestModel() {
        RequestModel.getInstance().setDeviceType(DEVICE_TYPE);
        RequestModel.getInstance().setLoginId(SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_MOBILE_NO));
        RequestModel.getInstance().setAccessToken(DeviceUtils.getDeviceKey());
        RequestModel.getInstance().setIpAddress(DeviceUtils.getDeviceIpAddress(context));
    }

    private void getWalletBalance() {

        initRequestModel();
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        JSONObject jsonGetBalanceRequest = null;
        try {
            jsonGetBalanceRequest = new JSONObject(gson.toJson(RequestModel.getInstance()));
            jsonGetBalanceRequest.put(KEY_USER_ID, SharedPreferenceUtils.getInstance(context).getInteger(USER_ID));
            Log.e("jsonGetBalanceRequest", jsonGetBalanceRequest.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_GET_WALLET_BALANCE, jsonGetBalanceRequest, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                        String message = response.getString(RESPONCE_MESSAGE);
                        JSONObject messageJson = new JSONObject(message);
                        String totalBalance = messageJson.getString(USER_WALLET_BALANCE);
                        Log.e("jsonGetBalanceRequest", totalBalance);
                        SharedPreferenceUtils.getInstance(context).putString(USER_WALLET_BALANCE, totalBalance);
                        currentBalanceTV.setText(getString(R.string.rupees_symbol) + " " + totalBalance);
                    } else {
                        ((BaseActivity) currentActivity).logTesting("GETWalletBalance", "true", Log.ERROR);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                ((BaseActivity) currentActivity).logTesting("error is", error.toString(), Log.ERROR);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();

                params.put("Content-Type", "application/json");

                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }

    private void initWalletModel(String transactionId) {
        WalletModel walletModel = new WalletModel();

        walletModel.setDeviceType(DEVICE_TYPE);
        walletModel.setLoginId(SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_MOBILE_NO));
        walletModel.setAccessToken(DeviceUtils.getDeviceKey());
        walletModel.setIpAddress(DeviceUtils.getDeviceIpAddress(context));

        walletModel.setUserId(SharedPreferenceUtils.getInstance(context).getInteger(USER_ID));
        walletModel.setBalance(editAmount.getText().toString());
        walletModel.setPaymentMethod(paymentMethod);
        walletModel.setTransactionId(transactionId);
        walletModel.setImageName("");
        addWalletBalance(walletModel);
    }

    private void addWalletBalance(final WalletModel walletModel) {

        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);
        JSONObject jsonAddBalanceRequest = null;
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();

        try {
            jsonAddBalanceRequest = new JSONObject(gson.toJson(walletModel));
            Log.e("jsonAddBalanceRequest", jsonAddBalanceRequest.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_ADD_WALLET_BALANCE, jsonAddBalanceRequest, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                cancelProgressDialog();
                try {
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                        String message = response.getString(RESPONCE_MESSAGE);
                        JSONObject messageJson = new JSONObject(message);
                        String totalBalance = messageJson.getString(USER_WALLET_BALANCE);
                        SharedPreferenceUtils.getInstance(context).putString(USER_WALLET_BALANCE, totalBalance);
                        currentBalanceTV.setText(getString(R.string.rupees_symbol) + " " + totalBalance);
                        onlineIV.setImageResource(R.drawable.payu_un_icon);
                        onlineTV.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                        paytmIV.setImageResource(R.drawable.paytm_un_icon);
                        paytmTV.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                        editAmount.setText("");
                        toast(getString(R.string.message_added_to_wallet),true);
                        setResult(RESULT_OK);
                        finish();
                    } else {
                        if (userDataSource != null) {
                            userDataSource.addUserTransaction(walletModel);
                        }
                        alert(currentActivity, getString(R.string.title_payment_failed), getString(R.string.message_payment_failed), getString(R.string.labelOk), getString(R.string.labelCancel), false,true,ALERT_TYPE_NO_NETWORK);
                        ((BaseActivity) currentActivity).logTesting("addWalletBalance", "true", Log.ERROR);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                if (userDataSource != null) {
                    userDataSource.addUserTransaction(walletModel);
                }
                alert(currentActivity, getString(R.string.title_payment_failed), getString(R.string.message_payment_failed), getString(R.string.labelOk), getString(R.string.labelCancel), false,true,ALERT_TYPE_NO_NETWORK);
                ((BaseActivity) currentActivity).logTesting("error is", error.toString(), Log.ERROR);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();

                params.put("Content-Type", "application/json");


                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }

    @Override
    public void onAlertClicked(int alertType) {

    }
}
