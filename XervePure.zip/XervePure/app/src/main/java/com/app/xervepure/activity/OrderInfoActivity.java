package com.app.xervepure.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.app.xervepure.R;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.utils.FontUtils;

public class OrderInfoActivity extends BaseActivity {

    private TextView thanksTV;
    private TextView msgOrderPlacedTV;
    private TextView lblOrderIdTV;
    private TextView orderIdTV;
    private Button buttonHome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_info);
    }

    @Override
    protected void initViews() {

        getSupportActionBar().setTitle(getString(R.string.title_order_placed));
        thanksTV = (TextView) findViewById(R.id.thanksTV);
        msgOrderPlacedTV = (TextView) findViewById(R.id.msgOrderPlacedTV);
        lblOrderIdTV = (TextView) findViewById(R.id.lblOrderIdTV);
        orderIdTV = (TextView) findViewById(R.id.orderIdTV);
        buttonHome = (Button) findViewById(R.id.buttonHome);
        FontUtils.changeFont(currentActivity, thanksTV, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, msgOrderPlacedTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, lblOrderIdTV, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, orderIdTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, buttonHome, AppConstants.FONT_ROBOTO_MEDIUM);
        if (getIntent().getExtras() != null) {
            if (getIntent().hasExtra(KEY_ORDER_ID)) {
                orderIdTV.setText("#" + getIntent().getExtras().getString(KEY_ORDER_ID));
            } else if (getIntent().hasExtra(KEY_SUBSCRIPTION_ID)) {
                getSupportActionBar().setTitle(getString(R.string.title_subscription_placed));
                msgOrderPlacedTV.setText(getString(R.string.message_subscription_placed));
                lblOrderIdTV.setText(getString(R.string.labelSubscriptionId));
                orderIdTV.setText("#" + getIntent().getExtras().getString(KEY_SUBSCRIPTION_ID));
                thanksTV.setText("Thanks for placing an order with XervePure");
            }
        }
    }

    @Override
    protected void initContext() {
        context = OrderInfoActivity.this;
        currentActivity = OrderInfoActivity.this;
    }

    @Override
    protected void initListners() {
        buttonHome.setOnClickListener(this);
    }

    @Override
    protected boolean isActionBar() {
        return true;
    }

    @Override
    protected boolean isHomeButton() {
        return false;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.buttonHome: {
                startActivity(currentActivity, Dashboard.class, bundle, false, REQUEST_TAG_NO_RESULT, false, ANIMATION_SLIDE_UP);
                finish();
                break;
            }
        }
    }

    @Override
    public void onAlertClicked(int alertType) {

    }

    @Override
    public void onBackPressed() {

    }
}
