package com.app.xervepure.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.app.xervepure.R;
import com.app.xervepure.utils.FontUtils;
import com.app.xervepure.utils.Validator;

public class LoginActivity extends BaseActivity implements View.OnClickListener {

    private EditText mobileNumberEditText;
    private Button sendButton;


    @Override
    protected void initViews() {
        settingTitle(getString(R.string.label_login));
        mobileNumberEditText = (EditText) findViewById(R.id.mobileNumberEditText);
        sendButton = (Button) findViewById(R.id.sendButton);
        FontUtils.changeFont(this, mobileNumberEditText, FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(this, sendButton, FONT_ROBOTO_MEDIUM);
    }

    @Override
    protected void initContext() {

        currentActivity = LoginActivity.this;
        context = LoginActivity.this;

    }

    @Override
    protected void initListners() {
        sendButton.setOnClickListener(this);


    }

    @Override
    protected boolean isActionBar() {
        return true;
    }

    @Override
    protected boolean isHomeButton() {
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //getSupportActionBar().setTitle(R.string.title_activity_login);
    }

    @Override
    public void onAlertClicked(int alertType) {

    }


    private boolean isMandatoryFields() {

        mobileNumberEditText.setError(null);

        if (!Validator.getInstance().validateNumber(context, mobileNumberEditText.getText().toString()).equals("")) {
            String numberError = Validator.getInstance().validateNumber(context, mobileNumberEditText.getText().toString());
            mobileNumberEditText.setError(numberError);
            mobileNumberEditText.requestFocus();
            return false;

        }
        return true;
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {

            case R.id.sendButton: {

                toHideKeyboard();
                if (Validator.getInstance().isNetworkAvailable(currentActivity)) {
                    if (isMandatoryFields()) {
                        if (bundle == null) {
                            bundle = new Bundle();
                        }
                        bundle.putString(USER_MOBILE_NO, mobileNumberEditText.getText().toString());
                        startActivity(currentActivity, OtpValidation.class, bundle, false, REQUEST_TAG_NO_RESULT, true, ANIMATION_SLIDE_LEFT);
                    }
                } else {
                    alert(currentActivity, getResources().getString(R.string.alert_message_no_network), getResources().getString(R.string.alert_message_no_network), getResources().getString(R.string.alert_ok_button_text_no_network), getResources().getString(R.string.alert_cancel_button_text_no_network), true, false, ALERT_TYPE_NO_NETWORK);
                }
                break;

            }
        }

    }


    @Override
    public void onStart() {
        super.onStart();

    }


}
