package com.app.xervepure.activity;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.app.xervepure.R;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.model.DaySubscriptionModel;
import com.app.xervepure.model.PlaceSubscriptionModel;
import com.app.xervepure.model.ProductDetailModel;
import com.app.xervepure.utils.FontUtils;
import com.app.xervepure.utils.SharedPreferenceUtils;
import com.app.xervepure.utils.Validator;
import com.squareup.picasso.Picasso;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class SubscriptionActivity extends BaseActivity {

    private ImageView productImageView;
    private TextView productNameTextView;
    private TextView productQuantityTextView;
    private TextView rupeesTextView;

    private LinearLayout everydayLL;
    private ImageView everydayIV;
    private TextView everydayTV;

    private LinearLayout alternateDayLL;
    private ImageView alternateDayIV;
    private TextView alternateDayTV;

    private LinearLayout customizeLL;
    private ImageView customizeIV;
    private TextView customizeTV;

    private ImageView plusImageView;
    private ImageView minusImageView;
    private TextView numberOfProductTV;

    private LinearLayout repeatweeklyLL;
    private ImageView repeatweeklyIV;
    private TextView repeatweeklyTV;

    private TextView lblStartTV;
    private TextView lblEndTV;
    private TextView dateTextView;
    private TextView endDateTextView;
    private CardView startDateCV;
    private CardView endDateCV;

    private LinearLayout weekDaysLL;
    private TextView sundayTextView;
    private TextView sundayQuantityTextView;
    private TextView mondayTextVIew;
    private TextView mondayQuantityTextView;
    private TextView tuesdayTextView;
    private TextView tuesdayQuantityTextView;
    private TextView wensdayTextView;
    private TextView wenesdayQuantityTextView;
    private TextView thursdayTextView;
    private TextView thrusdayQuantityTextView;
    private TextView fridayTextView;
    private TextView fridayQuantityTextView;
    private TextView saturdayTextView;
    private TextView saturdayQuantityTextView;

    private Button btnConfrimSubscription;

    private ProductDetailModel productDetailModel;
    private int subscriptionType = TYPE_SUBSCRIPTION_EVERYDAY;
    private boolean isRepeatWeekly;
    private Calendar mCalendar;
    private Calendar tomorrowCalendar;
    private String productQuantityCount;
    private int dayArray[];
    private int arrayPossition = -1;
    private PlaceSubscriptionModel subscriptionModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subscription);
    }

    @Override
    protected void initViews() {
        settingTitle(getString(R.string.subscribe));
        productDetailModel = getIntent().getParcelableExtra(PRODUCT_MODEL);
        productQuantityCount = getIntent().getStringExtra("productQuantityCount");
        mCalendar = Calendar.getInstance();
        dayArray = new int[7];
        isRepeatWeekly = true;
        productImageView = (ImageView) findViewById(R.id.productImageView);
        productNameTextView = (TextView) findViewById(R.id.productNameTextView);
        productQuantityTextView = (TextView) findViewById(R.id.productQuantityTextView);
        rupeesTextView = (TextView) findViewById(R.id.rupeesTextView);

        everydayLL = (LinearLayout) findViewById(R.id.everydayLL);
        everydayIV = (ImageView) findViewById(R.id.everydayIV);
        everydayTV = (TextView) findViewById(R.id.everydayTV);

        alternateDayLL = (LinearLayout) findViewById(R.id.alternateDayLL);
        alternateDayIV = (ImageView) findViewById(R.id.alternateDayIV);
        alternateDayTV = (TextView) findViewById(R.id.alternateDayTV);

        customizeLL = (LinearLayout) findViewById(R.id.customizeLL);
        customizeIV = (ImageView) findViewById(R.id.customizeIV);
        customizeTV = (TextView) findViewById(R.id.customizeTV);

        plusImageView = (ImageView) findViewById(R.id.plusImageView);
        minusImageView = (ImageView) findViewById(R.id.minusImageView);
        numberOfProductTV = (TextView) findViewById(R.id.numberOfProductTV);

        repeatweeklyLL = (LinearLayout) findViewById(R.id.repeatweeklyLL);
        repeatweeklyIV = (ImageView) findViewById(R.id.repeatweeklyIV);
        repeatweeklyTV = (TextView) findViewById(R.id.repeatweeklyTV);

        lblStartTV = (TextView) findViewById(R.id.lblStartTV);
        lblEndTV = (TextView) findViewById(R.id.lblEndTV);
        dateTextView = (TextView) findViewById(R.id.dateTextView);
        endDateTextView = findViewById(R.id.endDateTextView);
        startDateCV = (CardView) findViewById(R.id.startDateCV);
        endDateCV = findViewById(R.id.endDateCV);

        weekDaysLL = (LinearLayout) findViewById(R.id.weekDaysLL);
        sundayTextView = (TextView) findViewById(R.id.sundayTextView);
        sundayQuantityTextView = (TextView) findViewById(R.id.sundayQuantityTextView);
        mondayTextVIew = (TextView) findViewById(R.id.mondayTextVIew);
        mondayQuantityTextView = (TextView) findViewById(R.id.mondayQuantityTextView);
        tuesdayTextView = (TextView) findViewById(R.id.tuesdayTextView);
        tuesdayQuantityTextView = (TextView) findViewById(R.id.tuesdayQuantityTextView);
        wensdayTextView = (TextView) findViewById(R.id.wensdayTextView);
        wenesdayQuantityTextView = (TextView) findViewById(R.id.wenesdayQuantityTextView);
        thursdayTextView = (TextView) findViewById(R.id.thursdayTextView);
        thrusdayQuantityTextView = (TextView) findViewById(R.id.thrusdayQuantityTextView);
        fridayTextView = (TextView) findViewById(R.id.fridayTextView);
        fridayQuantityTextView = (TextView) findViewById(R.id.fridayQuantityTextView);
        saturdayTextView = (TextView) findViewById(R.id.saturdayTextView);
        saturdayQuantityTextView = (TextView) findViewById(R.id.saturdayQuantityTextView);

        btnConfrimSubscription = (Button) findViewById(R.id.btnConfrimSubscription);

        FontUtils.changeFont(currentActivity, productNameTextView, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, productQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, rupeesTextView, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivity, everydayTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, alternateDayTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, customizeTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, numberOfProductTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, repeatweeklyTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, lblStartTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, lblEndTV, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, dateTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, endDateTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, sundayTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, sundayQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, mondayTextVIew, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, mondayQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, tuesdayTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, tuesdayQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, wensdayTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, wenesdayQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, thursdayTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, thrusdayQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, fridayTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, fridayQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, saturdayTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, saturdayQuantityTextView, AppConstants.FONT_ROBOTO_REGULAR);
        FontUtils.changeFont(currentActivity, btnConfrimSubscription, AppConstants.FONT_ROBOTO_MEDIUM);

        everydayLL.setOnClickListener(this);
        alternateDayLL.setOnClickListener(this);
        customizeLL.setOnClickListener(this);
        plusImageView.setOnClickListener(this);
        minusImageView.setOnClickListener(this);
        repeatweeklyLL.setOnClickListener(this);
        startDateCV.setOnClickListener(this);
        endDateCV.setOnClickListener(this);
        weekDaysLL.setOnClickListener(this);
        sundayTextView.setOnClickListener(this);
        mondayTextVIew.setOnClickListener(this);
        tuesdayTextView.setOnClickListener(this);
        wensdayTextView.setOnClickListener(this);
        thursdayTextView.setOnClickListener(this);
        fridayTextView.setOnClickListener(this);
        saturdayTextView.setOnClickListener(this);
        btnConfrimSubscription.setOnClickListener(this);
        setTextOnViews();
    }

    @Override
    protected void initContext() {
        currentActivity = SubscriptionActivity.this;
        context = SubscriptionActivity.this;
    }

    @Override
    protected void initListners() {

    }

    @Override
    protected boolean isActionBar() {
        return true;
    }

    @Override
    protected boolean isHomeButton() {
        return true;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.everydayLL: {
                //isRepeatWeekly = true;
                weekDaysLL.setVisibility(View.GONE);
                repeatweeklyLL.setVisibility(View.VISIBLE);
                subscriptionType = TYPE_SUBSCRIPTION_EVERYDAY;
                everydayIV.setImageResource(R.drawable.radio_selected_btn);
                alternateDayIV.setImageResource(R.drawable.radio_unselected_btn);
                customizeIV.setImageResource(R.drawable.radio_unselected_btn);
                numberOfProductTV.setText(productQuantityCount);
                break;
            }
            case R.id.alternateDayLL: {
                weekDaysLL.setVisibility(View.GONE);
                repeatweeklyLL.setVisibility(View.VISIBLE);
                subscriptionType = TYPE_SUBSCRIPTION_ALTERNATEDAY;
                everydayIV.setImageResource(R.drawable.radio_unselected_btn);
                alternateDayIV.setImageResource(R.drawable.radio_selected_btn);
                customizeIV.setImageResource(R.drawable.radio_unselected_btn);
                numberOfProductTV.setText(productQuantityCount);
                break;
            }
            case R.id.customizeLL: {
                for (int i = 0; i < dayArray.length; i++) {
                    dayArray[i] = 0;
                }

                weekDaysLL.setVisibility(View.VISIBLE);
                repeatweeklyLL.setVisibility(View.VISIBLE);
                subscriptionType = TYPE_SUBSCRIPTION_CUSTOMIZE;
                everydayIV.setImageResource(R.drawable.radio_unselected_btn);
                alternateDayIV.setImageResource(R.drawable.radio_unselected_btn);
                customizeIV.setImageResource(R.drawable.radio_selected_btn);
                numberOfProductTV.setText("0");
                break;
            }
            case R.id.repeatweeklyLL: {
                if (isRepeatWeekly) {
                    isRepeatWeekly = false;
                    repeatweeklyIV.setImageResource(R.drawable.check_box_unselected_btn);
                } else {
                    isRepeatWeekly = true;
                    repeatweeklyIV.setImageResource(R.drawable.check_box_selected_btn);
                }
                break;
            }
            case R.id.plusImageView: {
                int count = 0;
                if (!TextUtils.isEmpty(numberOfProductTV.getText().toString())) {
                    count = Integer.parseInt(numberOfProductTV.getText().toString());
                }
                ++count;
                if (subscriptionType == TYPE_SUBSCRIPTION_CUSTOMIZE) {
                    if (arrayPossition < 0) {
                        return;
                    }
                    setDayWiseQuantity(count);
                }
                numberOfProductTV.setText(count + "");
                productQuantityCount = count+"";
                break;
            }
            case R.id.minusImageView: {

                int count = 0;
                if (!TextUtils.isEmpty(numberOfProductTV.getText().toString())) {
                    count = Integer.parseInt(numberOfProductTV.getText().toString());
                }
                --count;
                if (subscriptionType == TYPE_SUBSCRIPTION_CUSTOMIZE) {
                    if (count < 0) return;
                    if (arrayPossition < 0) {
                        return;
                    }
                    setDayWiseQuantity(count);
                } else {
                    int minQuantity = 0;
                    if (productDetailModel.getProductType() == PRODUCT_TYPE_MILK) {
                        minQuantity = MILK_MIN_ORDER_QTY;
                    } else {
                        minQuantity = OTHER_MIN_ORDER_QTY;
                    }
                    if (count < minQuantity) return;
                }
                numberOfProductTV.setText(count + "");
                productQuantityCount = count+"";
                break;
            }
            case R.id.startDateCV: {
                toOpenDatePicker();
                break;
            }
            case R.id.endDateCV: {
                toOpenEndDatePicker();
                break;
            }
            case R.id.sundayTextView: {
                numberOfProductTV.setText(String.valueOf(dayArray[0]));
                arrayPossition = 0;
                sundayTextView.setBackgroundResource(R.drawable.rounded_textview);
                sundayTextView.setTextColor(Color.WHITE);
                mondayTextVIew.setBackgroundResource(0);
                mondayTextVIew.setTextColor(mondayQuantityTextView.getTextColors());
                tuesdayTextView.setBackgroundResource(0);
                tuesdayTextView.setTextColor(tuesdayQuantityTextView.getTextColors());
                wensdayTextView.setBackgroundResource(0);
                wensdayTextView.setTextColor(wenesdayQuantityTextView.getTextColors());
                thursdayTextView.setBackgroundResource(0);
                thursdayTextView.setTextColor(thrusdayQuantityTextView.getTextColors());
                fridayTextView.setBackgroundResource(0);
                fridayTextView.setTextColor(fridayQuantityTextView.getTextColors());
                saturdayTextView.setBackgroundResource(0);
                saturdayTextView.setTextColor(saturdayQuantityTextView.getTextColors());
                break;
            }
            case R.id.mondayTextVIew: {
                numberOfProductTV.setText(String.valueOf(dayArray[1]));
                arrayPossition = 1;
                sundayTextView.setBackgroundResource(0);
                sundayTextView.setTextColor(sundayQuantityTextView.getTextColors());
                mondayTextVIew.setBackgroundResource(R.drawable.rounded_textview);
                mondayTextVIew.setTextColor(Color.WHITE);
                tuesdayTextView.setBackgroundResource(0);
                tuesdayTextView.setTextColor(tuesdayQuantityTextView.getTextColors());
                wensdayTextView.setBackgroundResource(0);
                wensdayTextView.setTextColor(wenesdayQuantityTextView.getTextColors());
                thursdayTextView.setBackgroundResource(0);
                thursdayTextView.setTextColor(thrusdayQuantityTextView.getTextColors());
                fridayTextView.setBackgroundResource(0);
                fridayTextView.setTextColor(fridayQuantityTextView.getTextColors());
                saturdayTextView.setBackgroundResource(0);
                saturdayTextView.setTextColor(saturdayQuantityTextView.getTextColors());
                break;
            }
            case R.id.tuesdayTextView: {
                numberOfProductTV.setText(String.valueOf(dayArray[2]));
                arrayPossition = 2;
                sundayTextView.setBackgroundResource(0);
                sundayTextView.setTextColor(sundayQuantityTextView.getTextColors());
                mondayTextVIew.setBackgroundResource(0);
                mondayTextVIew.setTextColor(mondayQuantityTextView.getTextColors());
                tuesdayTextView.setBackgroundResource(R.drawable.rounded_textview);
                tuesdayTextView.setTextColor(Color.WHITE);
                wensdayTextView.setBackgroundResource(0);
                wensdayTextView.setTextColor(wenesdayQuantityTextView.getTextColors());
                thursdayTextView.setBackgroundResource(0);
                thursdayTextView.setTextColor(thrusdayQuantityTextView.getTextColors());
                fridayTextView.setBackgroundResource(0);
                fridayTextView.setTextColor(fridayQuantityTextView.getTextColors());
                saturdayTextView.setBackgroundResource(0);
                saturdayTextView.setTextColor(saturdayQuantityTextView.getTextColors());
                break;
            }
            case R.id.wensdayTextView: {
                numberOfProductTV.setText(String.valueOf(dayArray[3]));
                arrayPossition = 3;
                sundayTextView.setBackgroundResource(0);
                sundayTextView.setTextColor(sundayQuantityTextView.getTextColors());
                mondayTextVIew.setBackgroundResource(0);
                mondayTextVIew.setTextColor(mondayQuantityTextView.getTextColors());
                tuesdayTextView.setBackgroundResource(0);
                tuesdayTextView.setTextColor(tuesdayQuantityTextView.getTextColors());
                wensdayTextView.setBackgroundResource(R.drawable.rounded_textview);
                wensdayTextView.setTextColor(Color.WHITE);
                thursdayTextView.setBackgroundResource(0);
                thursdayTextView.setTextColor(thrusdayQuantityTextView.getTextColors());
                fridayTextView.setBackgroundResource(0);
                fridayTextView.setTextColor(fridayQuantityTextView.getTextColors());
                saturdayTextView.setBackgroundResource(0);
                saturdayTextView.setTextColor(saturdayQuantityTextView.getTextColors());
                break;
            }
            case R.id.thursdayTextView: {
                numberOfProductTV.setText(String.valueOf(dayArray[4]));
                arrayPossition = 4;
                sundayTextView.setBackgroundResource(0);
                sundayTextView.setTextColor(sundayQuantityTextView.getTextColors());
                mondayTextVIew.setBackgroundResource(0);
                mondayTextVIew.setTextColor(mondayQuantityTextView.getTextColors());
                tuesdayTextView.setBackgroundResource(0);
                tuesdayTextView.setTextColor(tuesdayQuantityTextView.getTextColors());
                wensdayTextView.setBackgroundResource(0);
                wensdayTextView.setTextColor(wenesdayQuantityTextView.getTextColors());
                thursdayTextView.setBackgroundResource(R.drawable.rounded_textview);
                thursdayTextView.setTextColor(Color.WHITE);
                fridayTextView.setBackgroundResource(0);
                fridayTextView.setTextColor(fridayQuantityTextView.getTextColors());
                saturdayTextView.setBackgroundResource(0);
                saturdayTextView.setTextColor(saturdayQuantityTextView.getTextColors());
                break;
            }
            case R.id.fridayTextView: {
                numberOfProductTV.setText(String.valueOf(dayArray[5]));
                arrayPossition = 5;
                sundayTextView.setBackgroundResource(0);
                sundayTextView.setTextColor(sundayQuantityTextView.getTextColors());
                mondayTextVIew.setBackgroundResource(0);
                mondayTextVIew.setTextColor(mondayQuantityTextView.getTextColors());
                tuesdayTextView.setBackgroundResource(0);
                tuesdayTextView.setTextColor(tuesdayQuantityTextView.getTextColors());
                wensdayTextView.setBackgroundResource(0);
                wensdayTextView.setTextColor(wenesdayQuantityTextView.getTextColors());
                thursdayTextView.setBackgroundResource(0);
                thursdayTextView.setTextColor(thrusdayQuantityTextView.getTextColors());
                fridayTextView.setBackgroundResource(R.drawable.rounded_textview);
                fridayTextView.setTextColor(Color.WHITE);
                saturdayTextView.setBackgroundResource(0);
                saturdayTextView.setTextColor(saturdayQuantityTextView.getTextColors());
                break;
            }
            case R.id.saturdayTextView: {
                numberOfProductTV.setText(String.valueOf(dayArray[6]));
                arrayPossition = 6;
                sundayTextView.setBackgroundResource(0);
                sundayTextView.setTextColor(sundayQuantityTextView.getTextColors());
                mondayTextVIew.setBackgroundResource(0);
                mondayTextVIew.setTextColor(mondayQuantityTextView.getTextColors());
                tuesdayTextView.setBackgroundResource(0);
                tuesdayTextView.setTextColor(tuesdayQuantityTextView.getTextColors());
                wensdayTextView.setBackgroundResource(0);
                wensdayTextView.setTextColor(wenesdayQuantityTextView.getTextColors());
                thursdayTextView.setBackgroundResource(0);
                thursdayTextView.setTextColor(thrusdayQuantityTextView.getTextColors());
                fridayTextView.setBackgroundResource(0);
                fridayTextView.setTextColor(fridayQuantityTextView.getTextColors());
                saturdayTextView.setBackgroundResource(R.drawable.rounded_textview);
                saturdayTextView.setTextColor(Color.WHITE);
                break;
            }
            case R.id.btnConfrimSubscription: {
                if (subscriptionType == TYPE_SUBSCRIPTION_CUSTOMIZE) {
                    int minQuantity = 0;
                    if (productDetailModel.getProductType() == PRODUCT_TYPE_MILK) {
                        minQuantity = MILK_MIN_ORDER_QTY;
                    } else {
                        minQuantity = OTHER_MIN_ORDER_QTY;
                    }
                    int qtyCount = 0;
                    for (int i = 0; i < dayArray.length; i++) {
                        qtyCount = dayArray[i];
                        if (qtyCount > 0) break;
                    }

                    if (qtyCount == 0) {
                        alert(currentActivity, "", getString(R.string.message_singel_day_subscription), getResources().getString(R.string.alert_ok_button_text_no_network), getResources().getString(R.string.alert_cancel_button_text_no_network), false, false, ALERT_TYPE_NO_NETWORK);
                        return;
                    }

                    for (int i = 0; i < dayArray.length; i++) {
                        qtyCount = dayArray[i];
                        if (qtyCount < minQuantity) {
                            if (qtyCount != 0) {
                                String message = getString(R.string.message_min_qty);
                                message.replace("2", "" + minQuantity);
                                alert(currentActivity, "", message, getResources().getString(R.string.alert_ok_button_text_no_network), getResources().getString(R.string.alert_cancel_button_text_no_network), false, false, ALERT_TYPE_NO_NETWORK);
                                return;
                            }
                        }
                    }

                }

                if (Validator.isNetworkAvailable(currentActivity)) {
                    initSubscriptionModel();
                    if (bundle == null) {
                        bundle = new Bundle();
                    }
                    bundle.putParcelable(SUBSCRIPTION_MODEL, subscriptionModel);
                    bundle.putBoolean(SUBSCRIPTION, true);
                    startActivity(currentActivity, AllAddressesActivity.class, bundle, false, REQUEST_TAG_NO_RESULT, true, ANIMATION_SLIDE_LEFT);
                } else {
                    alert(currentActivity, getString(R.string.alert_message_no_network), getString(R.string.alert_message_no_network), getString(R.string.labelOk), getString(R.string.labelCancel), false, false, ALERT_TYPE_NO_NETWORK);

                }
                break;
            }
        }

    }

    @Override
    public void onAlertClicked(int alertType) {

    }

    private void setDayWiseQuantity(int count) {
        dayArray[arrayPossition] = count;
        switch (arrayPossition) {
            case 0: {
                sundayQuantityTextView.setText("" + count);
                if (count == 0) {
                    sundayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                } else {
                    sundayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                }
                break;
            }
            case 1: {
                mondayQuantityTextView.setText("" + count);
                if (count == 0) {
                    mondayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                } else {
                    mondayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                }
                break;
            }
            case 2: {
                tuesdayQuantityTextView.setText("" + count);
                if (count == 0) {
                    tuesdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                } else {
                    tuesdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                }
                break;
            }
            case 3: {
                wenesdayQuantityTextView.setText("" + count);
                if (count == 0) {
                    wenesdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                } else {
                    wenesdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                }
                break;
            }
            case 4: {
                thrusdayQuantityTextView.setText("" + count);
                if (count == 0) {
                    thrusdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                } else {
                    thrusdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                }
                break;
            }
            case 5: {
                fridayQuantityTextView.setText("" + count);
                if (count == 0) {
                    fridayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                } else {
                    fridayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                }
                break;
            }
            case 6: {
                saturdayQuantityTextView.setText("" + count);
                if (count == 0) {
                    saturdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.colorText80));
                } else {
                    saturdayQuantityTextView.setTextColor(ContextCompat.getColor(context, R.color.btnBackground));
                }
                break;
            }

        }
    }

    private void initSubscriptionModel() {
        subscriptionModel = new PlaceSubscriptionModel();
        subscriptionModel.setUserId(SharedPreferenceUtils.getInstance(context).getInteger(USER_ID));
        subscriptionModel.setProductId(productDetailModel.getId());
        subscriptionModel.setProductName(productDetailModel.getName());
        subscriptionModel.setImageName(productDetailModel.getImage());
        subscriptionModel.setProductQuantity(productDetailModel.getQuantity());
        subscriptionModel.setSubscriptionType(subscriptionType);
        subscriptionModel.setIsRepeatWeekly(isRepeatWeekly ? 1 : 0);
        subscriptionModel.setStartDate(dateTextView.getText().toString());
        subscriptionModel.setEndDate(endDateTextView.getText().toString());
        if (!TextUtils.isEmpty(productDetailModel.getPrice())) {
            subscriptionModel.setProductPrice(Integer.parseInt(productDetailModel.getPrice()));
        } else {
            subscriptionModel.setProductPrice(0);
        }
        ArrayList<DaySubscriptionModel> daySubscriptionModels = new ArrayList<>();

        if (subscriptionType == TYPE_SUBSCRIPTION_ALTERNATEDAY) {
            int dayOfWeek = 0;
            Date date = null;
            SimpleDateFormat inFormat = new SimpleDateFormat("dd/MM/yyyy");
            try {
                date = inFormat.parse(dateTextView.getText().toString());
                Calendar c = Calendar.getInstance();
                c.setTime(date);
                dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            for (int i = 0; i < 7; i++) {
                DaySubscriptionModel daySubscriptionModel = new DaySubscriptionModel();
                int day = 0;
                if (dayOfWeek > 7) {
                    day = dayOfWeek - 7;
                } else {
                    day = dayOfWeek;
                }
                switch (day) {
                    case 1: {
                        daySubscriptionModel.setDay("Sunday");
                        break;
                    }
                    case 2: {
                        daySubscriptionModel.setDay("Monday");
                        break;
                    }
                    case 3: {
                        daySubscriptionModel.setDay("Tuesday");
                        break;
                    }
                    case 4: {
                        daySubscriptionModel.setDay("Wednesday");
                        break;
                    }
                    case 5: {
                        daySubscriptionModel.setDay("Thursday");
                        break;
                    }
                    case 6: {
                        daySubscriptionModel.setDay("Friday");
                        break;
                    }
                    case 7: {
                        daySubscriptionModel.setDay("Saturday");
                        break;
                    }
                }
                dayOfWeek++;
                if (i % 2 == 0) {
                    daySubscriptionModel.setQuantity(productQuantityCount);
                } else {
                    daySubscriptionModel.setQuantity("0");
                }
                daySubscriptionModels.add(daySubscriptionModel);
            }
            subscriptionModel.setDaySubscriptionModels(daySubscriptionModels);
            return;
        }

        for (int i = 0; i < dayArray.length; i++) {
            DaySubscriptionModel daySubscriptionModel = new DaySubscriptionModel();
            switch (i) {
                case 0: {
                    daySubscriptionModel.setDay("Sunday");
                    break;
                }
                case 1: {
                    daySubscriptionModel.setDay("Monday");
                    break;
                }
                case 2: {
                    daySubscriptionModel.setDay("Tuesday");
                    break;
                }
                case 3: {
                    daySubscriptionModel.setDay("Wednesday");
                    break;
                }
                case 4: {
                    daySubscriptionModel.setDay("Thursday");
                    break;
                }
                case 5: {
                    daySubscriptionModel.setDay("Friday");
                    break;
                }
                case 6: {
                    daySubscriptionModel.setDay("Saturday");
                    break;
                }
            }
            if (subscriptionType == TYPE_SUBSCRIPTION_CUSTOMIZE) {
                daySubscriptionModel.setQuantity(dayArray[i] + "");
            } else if (subscriptionType == TYPE_SUBSCRIPTION_EVERYDAY) {
                daySubscriptionModel.setQuantity(productQuantityCount);
            }
            daySubscriptionModels.add(daySubscriptionModel);
        }
        subscriptionModel.setDaySubscriptionModels(daySubscriptionModels);
    }

    private void toOpenDatePicker() {
        int year = mCalendar.get(Calendar.YEAR);
        int month = mCalendar.get(Calendar.MONTH);
        int day = mCalendar.get(Calendar.DAY_OF_MONTH);
        String selectedDate = dateTextView.getText().toString();
        if (!TextUtils.isEmpty(selectedDate)) {
            String yearString = selectedDate.substring(6, 10);
            String monthString = selectedDate.substring(3, 5);
            String dayString = selectedDate.substring(0, 2);
            year = Integer.parseInt(yearString);
            month = Integer.parseInt(monthString);
            day = Integer.parseInt(dayString);
            month--;
        }
        DatePickerDialog dpDialog = new DatePickerDialog(currentActivity, subscriptionDate, year, month, day);
        dpDialog.updateDate(year, month, day);
        dpDialog.getDatePicker().setMinDate(tomorrowCalendar.getTimeInMillis());
        dpDialog.show();
    }

    DatePickerDialog.OnDateSetListener subscriptionDate = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            Calendar mCalendar = Calendar.getInstance();
            mCalendar.set(Calendar.YEAR, year);
            mCalendar.set(Calendar.MONTH, monthOfYear);
            mCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            String myFormat = "dd/MM/yyyy";
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
            dateTextView.setText(sdf.format(mCalendar.getTime()));
        }
    };


    private void toOpenEndDatePicker() {
        int year = mCalendar.get(Calendar.YEAR);
        int month = mCalendar.get(Calendar.MONTH);
        int day = mCalendar.get(Calendar.DAY_OF_MONTH);
        String selectedDate = endDateTextView.getText().toString();
        if (!TextUtils.isEmpty(selectedDate)) {
            String yearString = selectedDate.substring(6, 10);
            String monthString = selectedDate.substring(3, 5);
            String dayString = selectedDate.substring(0, 2);
            year = Integer.parseInt(yearString);
            month = Integer.parseInt(monthString);
            day = Integer.parseInt(dayString);
            month--;
        }
        DatePickerDialog dpDialog = new DatePickerDialog(currentActivity, subscriptionEndDate, year, month, day);
        dpDialog.updateDate(year, month, day);
        dpDialog.getDatePicker().setMinDate(tomorrowCalendar.getTimeInMillis());
        dpDialog.show();
    }

    DatePickerDialog.OnDateSetListener subscriptionEndDate = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            Calendar mCalendar = Calendar.getInstance();
            mCalendar.set(Calendar.YEAR, year);
            mCalendar.set(Calendar.MONTH, monthOfYear);
            mCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            String myFormat = "dd/MM/yyyy";
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
            endDateTextView.setText(sdf.format(mCalendar.getTime()));
        }
    };

    private void setTextOnViews() {
        if (productDetailModel == null) return;
        String imageUrl = AppConstants.BASE_URL_IMAGES + "/" + productDetailModel.getImage();
        Picasso.with(currentActivity).load(imageUrl).into(productImageView);
        productNameTextView.setText(productDetailModel.getName());
        productQuantityTextView.setText(productDetailModel.getQuantity());
        rupeesTextView.setText(productDetailModel.getPrice());
        numberOfProductTV.setText(productQuantityCount);

        String timeToCompare = SUBSCRIPTION_MAX_TIME;
        boolean isLate = checkTimeOutOrNot(timeToCompare);

        tomorrowCalendar = Calendar.getInstance();
        if (isLate) {
            tomorrowCalendar.add(Calendar.DAY_OF_YEAR, 2);
        } else {
            tomorrowCalendar.add(Calendar.DAY_OF_YEAR, 1);
        }
        Date tomorrow = tomorrowCalendar.getTime();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String tomorrowDate = sdf.format(tomorrow);
        dateTextView.setText(tomorrowDate);


        Calendar calendar = Calendar.getInstance();
        if (isLate) {
            calendar.add(Calendar.DAY_OF_YEAR, 2);
        } else {
            calendar.add(Calendar.DAY_OF_YEAR, 1);
        }
        calendar.add(Calendar.MONTH, 1);

        Date endDate = calendar.getTime();
        String endDateStr = sdf.format(endDate);
        endDateTextView.setText(endDateStr);
    }

    public static boolean checkTimeOutOrNot(String time) {
        boolean timeOutOrNot = false;
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(time.substring(0, 2)));
        cal.set(Calendar.MINUTE, Integer.parseInt(time.substring(3)));
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (Calendar.getInstance().after(cal)) {
            timeOutOrNot = true;
        }
        return timeOutOrNot;
    }


}
