package com.app.xervepure.adapter;


import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.app.xervepure.R;
import com.app.xervepure.activity.Dashboard;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.utils.FontUtils;
import com.app.xervepure.utils.LoginUtils;
import com.app.xervepure.utils.SharedPreferenceUtils;

import static com.app.xervepure.constants.AppConstants.USER_WALLET_BALANCE;


public class SideMenuListAdapter extends RecyclerView.Adapter<SideMenuListAdapter.ViewHolder> {

    String[] sideMenuArray;
    int[] sideMenuImages = {R.drawable.home_icon, R.drawable.subscription_icon, R.drawable.wallet_icon, R.drawable.order_history_icon, R.drawable.subscription_icon, R.drawable.subscription_icon, R.mipmap.ic_refer, R.mipmap.ic_feedback, R.drawable.about_us_icon, R.drawable.contact_us_icon, R.drawable.terms_icon, R.drawable.privacy_icon, R.drawable.log_out_icon};
    Activity currentActivty;

    public SideMenuListAdapter(Activity currentActivty) {
        this.currentActivty = currentActivty;
        sideMenuArray = currentActivty.getResources().getStringArray(R.array.sideBarItems);
    }

    @Override
    public SideMenuListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(currentActivty).inflate(R.layout.items_side_menu, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(SideMenuListAdapter.ViewHolder holder, int position) {
        final int pos = position;
        holder.textSideBarItem.setText(sideMenuArray[pos]);
        holder.itemLL.setSelected(holder.itemLL.isSelected() ? true : false);
        FontUtils.changeFont(currentActivty, holder.textSideBarItem, AppConstants.FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(currentActivty, holder.walletBalanceTV, AppConstants.FONT_ROBOTO_MEDIUM);

        if (pos == 2) {
            String walletBalance = SharedPreferenceUtils.getInstance(currentActivty).getString(USER_WALLET_BALANCE);
            if (TextUtils.isEmpty(walletBalance)) {
                walletBalance = "0";
            }
            holder.walletBalanceTV.setText(currentActivty.getString(R.string.rupees_symbol) + " " + walletBalance);
            holder.walletBalanceTV.setVisibility(View.VISIBLE);
        } else {
            holder.walletBalanceTV.setVisibility(View.GONE);
        }

        if (sideMenuArray[pos].equals("Logout")) {
            if (!LoginUtils.isLogin(currentActivty)) {
                holder.textSideBarItem.setText("Login");
            }
        }

        if (sideMenuArray[pos].equalsIgnoreCase("Hold Delivery")) {
            holder.view.setVisibility(View.VISIBLE);
        } else {
            holder.view.setVisibility(View.GONE);
        }

        holder.imageSideBarItem.setImageDrawable(currentActivty.getResources().getDrawable(sideMenuImages[pos]));
        holder.containerSideMenuItems.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((Dashboard) currentActivty).setSelection(pos);
            }
        });
    }

    @Override
    public int getItemCount() {
        return sideMenuImages.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageSideBarItem;
        TextView textSideBarItem;
        TextView walletBalanceTV;
        LinearLayout containerSideMenuItems;
        LinearLayout itemLL;
        View view;

        public ViewHolder(View itemView) {
            super(itemView);

            imageSideBarItem = (ImageView) itemView.findViewById(R.id.imageSideBarItem);
            itemLL = (LinearLayout) itemView.findViewById(R.id.listView);
            textSideBarItem = (TextView) itemView.findViewById(R.id.textSideBarItem);
            walletBalanceTV = (TextView) itemView.findViewById(R.id.walletBalanceTV);
            view = itemView.findViewById(R.id.view);
            containerSideMenuItems = (LinearLayout) itemView.findViewById(R.id.containerSideMenuItems);
        }
    }
}