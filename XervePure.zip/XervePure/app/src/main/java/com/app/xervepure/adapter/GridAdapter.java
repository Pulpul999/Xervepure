package com.app.xervepure.adapter;

import android.content.Context;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.app.xervepure.R;
import com.app.xervepure.model.CalendarProductModel;
import com.app.xervepure.model.EventObjects;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class GridAdapter extends ArrayAdapter {
    private static final String TAG = GridAdapter.class.getSimpleName();
    private ArrayList<CalendarProductModel> calendarProductModelArrayList;
    private Context context;
    private LayoutInflater mInflater;
    private List<Date> monthlyDates;
    private Calendar currentDate;
    private List<EventObjects> allEvents;
    public GridAdapter(Context context, List<Date> monthlyDates, Calendar currentDate,
                       List<EventObjects> allEvents,ArrayList<CalendarProductModel> calendarProductModels) {
        super(context, R.layout.single_cell_layout);
        this.context = context;
        this.monthlyDates = monthlyDates;
        this.currentDate = currentDate;
        this.allEvents = allEvents;
        mInflater = LayoutInflater.from(context);
        calendarProductModelArrayList = calendarProductModels;
    }
    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Date mDate = monthlyDates.get(position);
        Calendar dateCal = Calendar.getInstance();
        dateCal.setTime(mDate);
        int dayValue = dateCal.get(Calendar.DAY_OF_MONTH);
        int displayMonth = dateCal.get(Calendar.MONTH) + 1;
        int displayYear = dateCal.get(Calendar.YEAR);
        int displayDay = dateCal.get(Calendar.DAY_OF_MONTH);
        int currentMonth = currentDate.get(Calendar.MONTH) + 1;
        int currentYear = currentDate.get(Calendar.YEAR);
        int currentDay = currentDate.get(Calendar.DAY_OF_MONTH);
        View view = convertView;
        if(view == null){
            view = mInflater.inflate(R.layout.single_cell_layout, parent, false);
        }
        TextView cellNumber = view.findViewById(R.id.calendar_date_id);
        TextView descriptionTV = view.findViewById(R.id.descriptionTV);
        if(displayMonth == currentMonth && displayYear == currentYear){
            //view.setBackgroundColor(Color.parseColor("#FF5733"));
            /*if(displayDay == currentDay){
                cellNumber.setTextColor(ContextCompat.getColor(context,R.color.colorPrimaryDark));
            }else {
                cellNumber.setTextColor(ContextCompat.getColor(context,R.color.colorText80));
            }*/
            CalendarProductModel calendarProductModel = getCalendarObject(displayDay);
            if(calendarProductModel != null) {
                descriptionTV.setText(calendarProductModel.getDescription());

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    descriptionTV.setText(Html.fromHtml(calendarProductModel.getDescription(), Html.FROM_HTML_MODE_COMPACT));
                } else {
                    descriptionTV.setText(Html.fromHtml(calendarProductModel.getDescription()));
                }

                int status = calendarProductModel.getStatus();
                if(status == 1){
                    cellNumber.setTextColor(ContextCompat.getColor(context,R.color.green));
                    descriptionTV.setTextColor(ContextCompat.getColor(context,R.color.green));
                }else if(status == 2){
                    cellNumber.setTextColor(ContextCompat.getColor(context,R.color.color_google));
                    descriptionTV.setTextColor(ContextCompat.getColor(context,R.color.color_google));
                }else if(status == 3 || status == 0){
                    cellNumber.setTextColor(ContextCompat.getColor(context,R.color.colorAccent));
                    descriptionTV.setTextColor(ContextCompat.getColor(context,R.color.colorAccent));
                }
            }

        }else{
            //view.setBackgroundColor(Color.parseColor("#cccccc"));
            cellNumber.setTextColor(ContextCompat.getColor(context,R.color.grey));
            descriptionTV.setText("");
        }
        //Add day to calendar
        view.setTag(descriptionTV.getText().toString());
        cellNumber.setText(String.valueOf(dayValue));
        return view;
    }

    @Override
    public int getCount() {
        return monthlyDates.size();
    }

    @Nullable
    @Override
    public Object getItem(int position) {
        return monthlyDates.get(position);
    }

    @Override
    public int getPosition(Object item) {
        return monthlyDates.indexOf(item);
    }

    private CalendarProductModel getCalendarObject(int day){
        CalendarProductModel calendarProductModel = null;
        if(calendarProductModelArrayList != null){
            for(int i=0; i<calendarProductModelArrayList.size(); i++){
                calendarProductModel = calendarProductModelArrayList.get(i);
                if(calendarProductModel == null) continue;
                if(calendarProductModel.getDay() == day){
                    return calendarProductModel;
                }else {
                    calendarProductModel = null;
                }
            }
        }
        return calendarProductModel;
    }
}
