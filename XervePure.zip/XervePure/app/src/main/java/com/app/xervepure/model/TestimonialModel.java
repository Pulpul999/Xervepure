package com.app.xervepure.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

public class TestimonialModel implements Parcelable {
    @SerializedName("name")
    private String customerName;
    @SerializedName("description")
    private String customerReview;
    @SerializedName("image")
    private String customerImage;
    @SerializedName("rating")
    private String customerRating;
    private String designation;


    protected TestimonialModel(Parcel in) {
        customerName = in.readString();
        customerReview = in.readString();
        customerImage = in.readString();
        customerRating = in.readString();
        designation = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(customerName);
        dest.writeString(customerReview);
        dest.writeString(customerImage);
        dest.writeString(customerRating);
        dest.writeString(designation);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<TestimonialModel> CREATOR = new Creator<TestimonialModel>() {
        @Override
        public TestimonialModel createFromParcel(Parcel in) {
            return new TestimonialModel(in);
        }

        @Override
        public TestimonialModel[] newArray(int size) {
            return new TestimonialModel[size];
        }
    };

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerReview() {
        return customerReview;
    }

    public void setCustomerReview(String customerReview) {
        this.customerReview = customerReview;
    }

    public String getCustomerImage() {
        return customerImage;
    }

    public void setCustomerImage(String customerImage) {
        this.customerImage = customerImage;
    }

    public String getCustomerRating() {
        return customerRating;
    }

    public void setCustomerRating(String customerRating) {
        this.customerRating = customerRating;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }
}
