package com.app.xervepure.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.app.xervepure.R;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.dao.UserDataSource;
import com.app.xervepure.utils.DateTimeUtils;
import com.app.xervepure.utils.SharedPreferenceUtils;

import org.apache.http.util.EncodingUtils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


public class PayUActivity extends BaseActivity {

    private UserDataSource userDataSource;
    private static final String TAG = "MainActivity";
    WebView webviewPayment;
    String amount = "";
    String txnid = "";
    Bundle bundle;
    String hash = "";

    @Override
    protected void initViews() {

        getSupportActionBar().setTitle(getResources().getString(R.string.title_pay_u_activity));
        userDataSource = new UserDataSource(context);
    }

    @Override
    protected void initContext() {
        currentActivity = PayUActivity.this;
        context = PayUActivity.this;
    }

    @Override
    protected void initListners() {

    }

    @Override
    protected boolean isActionBar() {
        return true;
    }

    @Override
    protected boolean isHomeButton() {
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);

        try {
            amount = getIntent().getStringExtra("amount");
        } catch (Exception e) {
            e.printStackTrace();
        }

        webviewPayment = (WebView) findViewById(R.id.webviewPayment);
        webviewPayment.getSettings().setJavaScriptEnabled(true);
        webviewPayment.getSettings().setDomStorageEnabled(true);
        webviewPayment.getSettings().setLoadWithOverviewMode(true);
        webviewPayment.getSettings().setUseWideViewPort(true);

        StringBuilder url_s = new StringBuilder();
        url_s.append("https://secure.payu.in/_payment");
        //url_s.append("https://test.payu.in/_payment");
        Log.e(TAG, "call url " + url_s);

        webviewPayment.postUrl(url_s.toString(), EncodingUtils.getBytes(getPostString(), "utf-8"));

        webviewPayment.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);

                Log.e("page load for order", "finish!" + url);
            }

            @SuppressWarnings("unused")
            public void onReceivedSslError(WebView view) {
                Log.e("Error for orde", "Exception caught!");
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {

                if (url.toString().equals(AppConstants.URL_PAYMENT_SUCCESS)) {
                    //toast("Your payment has been received.", true);
                    Intent intent = new Intent();
                    intent.putExtra(TRANSACTION_ID, txnid);
                    setResult(RESULT_OK, intent);
                    finish();
                } else if (url.toString().equals(AppConstants.URL_PAYMENT_FAIL)) {
                    alert(currentActivity, getString(R.string.message_order_not_placed_popuop), getString(R.string.message_order_not_placed_popuop), getString(R.string.labelOk), getString(R.string.labelCancel), false, false, ALERT_TYPE_NO_NETWORK);
                } else {
                    super.onPageStarted(view, url, favicon);
                }

            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {

                Log.e("override page for orde", url.toString());

                return super.shouldOverrideUrlLoading(view, url);
            }

        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    private String getPostString() {

        /*  staging credenials*/
        //String key = "gtKFFx";
        //String salt = "eCwWELxi";

      /*  production credenials*/
        String key = "pBw27rBO";
        String salt = "toHYfPP18O";

        txnid = String.valueOf(DateTimeUtils.currentTimeMills());
        String amount = this.amount;
        String firstname = SharedPreferenceUtils.getInstance(PayUActivity.this).getString(AppConstants.USER_NAME);
        String email = SharedPreferenceUtils.getInstance(PayUActivity.this).getString(AppConstants.USER_EMAIL);
        if (TextUtils.isEmpty(email)) {
            email = "xyz@gmail.com";
        }
        String phone = SharedPreferenceUtils.getInstance(PayUActivity.this).getString(AppConstants.USER_MOBILE_NO);
        String productInfo = "Cart Value";

        Log.e("first name email", firstname + email);

        StringBuilder post = new StringBuilder();
        post.append("key=");
        post.append(key);
        post.append("&");
        post.append("txnid=");
        post.append(txnid);
        post.append("&");
        post.append("amount=");
        post.append(amount);
        post.append("&");
        post.append("productinfo=");
        post.append(productInfo);
        post.append("&");
        post.append("firstname=");
        post.append(firstname);
        post.append("&");
        post.append("email=");
        post.append(email);
        post.append("&");
        post.append("phone=");
        post.append(phone);
        post.append("&");
        post.append("surl=");
        post.append("http://vyaandairy.com/success.php");
        post.append("&");
        post.append("furl=");
        post.append("http://vyaandairy.com/fail.php");
        post.append("&");
        post.append("service_provider=");
        post.append("payu_paisa");
        post.append("&");

        StringBuilder checkSumStr = new StringBuilder();

        MessageDigest digest = null;
        try {
            digest = MessageDigest.getInstance("SHA-512");

            checkSumStr.append(key);
            checkSumStr.append("|");
            checkSumStr.append(txnid);
            checkSumStr.append("|");
            checkSumStr.append(amount);
            checkSumStr.append("|");
            checkSumStr.append(productInfo);
            checkSumStr.append("|");
            checkSumStr.append(firstname);
            checkSumStr.append("|");
            checkSumStr.append(email);
            checkSumStr.append("|||||||||||");
            checkSumStr.append(salt);

            digest.update(checkSumStr.toString().getBytes());

            hash = bytesToHexString(digest.digest());
            post.append("hash=");
            post.append(hash);
            post.append("&");
            Log.i(TAG, "SHA result is " + hash);
        } catch (NoSuchAlgorithmException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }

        return post.toString();
    }

    private static String bytesToHexString(byte[] bytes) {

        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < bytes.length; i++) {
            String hex = Integer.toHexString(0xFF & bytes[i]);
            if (hex.length() == 1) {
                sb.append('0');
            }
            sb.append(hex);
        }
        return sb.toString();
    }

    @Override
    public void onAlertClicked(int alertType) {

        switch (alertType) {
            case ALERT_TYPE_CANCEL_TRANSCATION: {
                /*Intent intent = new Intent();
                intent.putExtra(TRANSACTION_ID, txnid);
                setResult(RESULT_OK, intent);*/
                finish();
            }
        }
    }

    @Override
    public void onClick(View view) {

    }

    @Override
    public void onBackPressed() {
        alert(currentActivity, getString(R.string.title_cancel_transaction), getString(R.string.message_cancel_transaction), getString(R.string.labelOk), getString(R.string.labelCancel), true, true, ALERT_TYPE_CANCEL_TRANSCATION);
    }

}
