package com.app.xervepure.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.app.xervepure.R;
import com.app.xervepure.application.VyaanApplication;
import com.app.xervepure.utils.SharedPreferenceUtils;
import com.app.xervepure.utils.Validator;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 */
public class FeedbackFragment extends BaseFragment {

    private ImageView star1;
    private ImageView star2;
    private ImageView star3;
    private ImageView star4;
    private ImageView star5;
    private EditText editTitle;
    private EditText editDesc;
    private EditText editPhone;
    private Button submitButton;
    private int rating = 5;
    public FeedbackFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return view = inflater.inflate(R.layout.fragment_feedback, container, false);
    }

    @Override
    public void alertOkClicked() {

    }

    @Override
    protected void initViews() {
        editTitle = (EditText) view.findViewById(R.id.editTitle);
        editDesc = (EditText) view.findViewById(R.id.editDesc);
        star1 = view.findViewById(R.id.star1);
        star2 = view.findViewById(R.id.star2);
        star3 = view.findViewById(R.id.star3);
        star4 = view.findViewById(R.id.star4);
        star5 = view.findViewById(R.id.star5);

        submitButton = (Button) view.findViewById(R.id.submitButton);
    }

    @Override
    protected void initContext() {
        context = getActivity();
        currentActivity = getActivity();
    }

    @Override
    protected void initListners() {
        submitButton.setOnClickListener(this);
        star1.setOnClickListener(this);
        star2.setOnClickListener(this);
        star3.setOnClickListener(this);
        star4.setOnClickListener(this);
        star5.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.submitButton: {
                toHideKeyboard();
                if (Validator.isNetworkAvailable(currentActivity)) {
                    if (isMandatoryFields()) {
                        submitFeedback();
                    }
                } else {
                    alert(currentActivity, getResources().getString(R.string.alert_message_no_network), getResources().getString(R.string.alert_message_no_network), getResources().getString(R.string.alert_ok_button_text_no_network), getResources().getString(R.string.alert_cancel_button_text_no_network), false, false);
                }
                break;
            }
            case R.id.star1:{
                star1.setImageResource(R.drawable.ic_star_selected);
                star2.setImageResource(R.drawable.icon_star_unselected);
                star3.setImageResource(R.drawable.icon_star_unselected);
                star4.setImageResource(R.drawable.icon_star_unselected);
                star5.setImageResource(R.drawable.icon_star_unselected);
                rating = 1;
                break;
            }
            case R.id.star2:{
                star1.setImageResource(R.drawable.ic_star_selected);
                star2.setImageResource(R.drawable.ic_star_selected);
                star3.setImageResource(R.drawable.icon_star_unselected);
                star4.setImageResource(R.drawable.icon_star_unselected);
                star5.setImageResource(R.drawable.icon_star_unselected);
                rating = 2;
                break;
            }
            case R.id.star3:{
                star1.setImageResource(R.drawable.ic_star_selected);
                star2.setImageResource(R.drawable.ic_star_selected);
                star3.setImageResource(R.drawable.ic_star_selected);
                star4.setImageResource(R.drawable.icon_star_unselected);
                star5.setImageResource(R.drawable.icon_star_unselected);
                rating = 3;
                break;
            }
            case R.id.star4:{
                star1.setImageResource(R.drawable.ic_star_selected);
                star2.setImageResource(R.drawable.ic_star_selected);
                star3.setImageResource(R.drawable.ic_star_selected);
                star4.setImageResource(R.drawable.ic_star_selected);
                star5.setImageResource(R.drawable.icon_star_unselected);
                rating = 4;
                break;
            }
            case R.id.star5:{
                star1.setImageResource(R.drawable.ic_star_selected);
                star2.setImageResource(R.drawable.ic_star_selected);
                star3.setImageResource(R.drawable.ic_star_selected);
                star4.setImageResource(R.drawable.ic_star_selected);
                star5.setImageResource(R.drawable.ic_star_selected);
                rating = 5;
                break;
            }
        }
    }

    private boolean isMandatoryFields() {
        editDesc.setError(null);
        if (editDesc.getText().toString().isEmpty()) {
            editDesc.setError("Please enter your comments");
            editDesc.requestFocus();
            return false;
        }
        return true;
    }

    private void submitFeedback() {

        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);

        JSONObject jsonUpdateUser = null;
        try {
            jsonUpdateUser = new JSONObject();
            jsonUpdateUser.put("user_id", SharedPreferenceUtils.getInstance(context).getInteger(USER_ID));
            jsonUpdateUser.put("subject", String.valueOf(rating));
            jsonUpdateUser.put("message", editDesc.getText().toString());
            Log.e("jsonSubmitFeedback", jsonUpdateUser.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest profileUpdateRequest = new JsonObjectRequest(Request.Method.POST, URL_SUBMIT_FEEDBACK, jsonUpdateUser, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                cancelProgressDialog();
                try {
                    logTesting(getResources().getString(R.string.nwk_response_edit_profile), response.toString());
                    String message = response.getString(RESPONCE_MESSAGE);
                    if (response.getBoolean(RESPONCE_ERROR)) {
                        alert(currentActivity, "", "Failed to submit your feedback", getResources().getString(R.string.alert_ok_button_text_no_network), getResources().getString(R.string.alert_cancel_button_text_no_network), false, false);
                    } else {
                        toast(context, "Your feedback has been successfully submitted.");
                        editTitle.setText("");
                        editDesc.setText("");
                        editTitle.requestFocus();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                logTesting(getResources().getString(R.string.nwk_error_edit_profile), error.toString());

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                return super.getHeaders();
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(profileUpdateRequest);
    }
}
