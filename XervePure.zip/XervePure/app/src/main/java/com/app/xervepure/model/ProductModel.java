package com.app.xervepure.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

/**
 * Created by GARIMA on 9/15/2017.
 */

public class ProductModel  implements Parcelable{
    private int id;
    private String name;
    private String quantity;
    private String price;
    private String image;
    @SerializedName("is_bottle_product")
    private String isBottleProduct;
    @SerializedName("banner_image")
    private String bannerImage;
    @SerializedName("is_comming_soon")
    private String isCommingSoon;
    @SerializedName("is_sample_product")
    private String isSampleProduct;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getIsBottleProduct() {
        return isBottleProduct;
    }

    public void setIsBottleProduct(String isBottleProduct) {
        this.isBottleProduct = isBottleProduct;
    }

    public String getBannerImage() {
        return bannerImage;
    }

    public void setBannerImage(String bannerImage) {
        this.bannerImage = bannerImage;
    }

    public String getIsCommingSoon() {
        return isCommingSoon;
    }

    public void setIsCommingSoon(String isCommingSoon) {
        this.isCommingSoon = isCommingSoon;
    }

    public String getIsSampleProduct() {
        return isSampleProduct;
    }

    public void setIsSampleProduct(String isSampleProduct) {
        this.isSampleProduct = isSampleProduct;
    }

    public static Creator<ProductModel> getCREATOR() {
        return CREATOR;
    }




    protected ProductModel(Parcel in) {
        id = in.readInt();
        name = in.readString();
        quantity = in.readString();
        price = in.readString();
        image = in.readString();
        isBottleProduct = in.readString();
        bannerImage = in.readString();
        isCommingSoon = in.readString();
        isSampleProduct = in.readString();
    }

    public static final Creator<ProductModel> CREATOR = new Creator<ProductModel>() {
        @Override
        public ProductModel createFromParcel(Parcel in) {
            return new ProductModel(in);
        }

        @Override
        public ProductModel[] newArray(int size) {
            return new ProductModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(id);
        parcel.writeString(name);
        parcel.writeString(quantity);
        parcel.writeString(price);
        parcel.writeString(image);
        parcel.writeString(isBottleProduct);
        parcel.writeString(bannerImage);
        parcel.writeString(isCommingSoon);
        parcel.writeString(isSampleProduct);
    }
}
