package com.app.xervepure.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

public class CalendarProductModel implements Parcelable {

    private int day;
    private int status;
    @SerializedName("desc")
    private String description;

    protected CalendarProductModel(Parcel in) {
        day = in.readInt();
        status = in.readInt();
        description = in.readString();
    }

    public static final Creator<CalendarProductModel> CREATOR = new Creator<CalendarProductModel>() {
        @Override
        public CalendarProductModel createFromParcel(Parcel in) {
            return new CalendarProductModel(in);
        }

        @Override
        public CalendarProductModel[] newArray(int size) {
            return new CalendarProductModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(day);
        parcel.writeInt(status);
        parcel.writeString(description);
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
