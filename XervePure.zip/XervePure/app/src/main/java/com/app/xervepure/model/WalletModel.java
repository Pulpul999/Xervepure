package com.app.xervepure.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Codeslay-03 on 9/19/2017.
 */

public class WalletModel extends BaseRequestModel implements Parcelable {

    @SerializedName("user_id")
    private int userId;

    private String balance;

    @SerializedName("payment_method")
    private int paymentMethod;

    @SerializedName("reference_id")
    private String transactionId;

    @SerializedName("cheque_image")
    private String imageName;

    private String checkSumHash;

    public WalletModel() {
        super();
    }


    protected WalletModel(Parcel in) {
        userId = in.readInt();
        balance = in.readString();
        paymentMethod = in.readInt();
        transactionId = in.readString();
        imageName = in.readString();
        checkSumHash = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(userId);
        dest.writeString(balance);
        dest.writeInt(paymentMethod);
        dest.writeString(transactionId);
        dest.writeString(imageName);
        dest.writeString(checkSumHash);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<WalletModel> CREATOR = new Creator<WalletModel>() {
        @Override
        public WalletModel createFromParcel(Parcel in) {
            return new WalletModel(in);
        }

        @Override
        public WalletModel[] newArray(int size) {
            return new WalletModel[size];
        }
    };

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public int getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(int paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public String getCheckSumHash() {
        return checkSumHash;
    }

    public void setCheckSumHash(String checkSumHash) {
        this.checkSumHash = checkSumHash;
    }
}

