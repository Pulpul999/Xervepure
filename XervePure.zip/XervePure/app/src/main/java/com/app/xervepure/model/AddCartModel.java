package com.app.xervepure.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Mayank on 31/08/2016.
 */
public class AddCartModel extends BaseRequestModel implements Parcelable {

    @SerializedName("product_id")
    private int productId;
    @SerializedName("quantity")
    private int productQuantity;
    @SerializedName("user_id")
    private int userId;

    public AddCartModel() {
        super();
    }

    protected AddCartModel(Parcel in) {
        productId = in.readInt();
        productQuantity = in.readInt();
        userId = in.readInt();
    }

    public static final Creator<AddCartModel> CREATOR = new Creator<AddCartModel>() {
        @Override
        public AddCartModel createFromParcel(Parcel in) {
            return new AddCartModel(in);
        }

        @Override
        public AddCartModel[] newArray(int size) {
            return new AddCartModel[size];
        }
    };

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getProductQuantity() {
        return productQuantity;
    }

    public void setProductQuantity(int productQuantity) {
        this.productQuantity = productQuantity;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(productId);
        parcel.writeInt(productQuantity);
        parcel.writeInt(userId);
    }
}
