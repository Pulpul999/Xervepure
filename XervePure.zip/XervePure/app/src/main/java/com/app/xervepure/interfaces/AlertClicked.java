package com.app.xervepure.interfaces;

/**
 * Created by Mayank on 27/04/2016.
 */
public interface AlertClicked {


    public void onAlertClicked(int alertType);

}
