package com.app.xervepure.fragments;

import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.CardView;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.app.xervepure.adapter.TestimonialAdapter;
import com.app.xervepure.model.TestimonialModel;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.app.xervepure.R;
import com.app.xervepure.activity.BaseActivity;
import com.app.xervepure.activity.Dashboard;
import com.app.xervepure.adapter.ProductsAdapter;
import com.app.xervepure.adapter.SlidingImageAdapter;
import com.app.xervepure.application.VyaanApplication;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.dao.UserDataSource;
import com.app.xervepure.model.BannerImageModel;
import com.app.xervepure.model.ProductModel;
import com.app.xervepure.model.RequestModel;
import com.app.xervepure.model.WalletModel;
import com.app.xervepure.utils.DeviceUtils;
import com.app.xervepure.utils.SharedPreferenceUtils;
import com.app.xervepure.utils.Validator;
import com.viewpagerindicator.CirclePageIndicator;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class MainBoard extends BaseFragment {

    private UserDataSource userDataSource;
    View view;
    RecyclerView recyclerProducts;

    ProductsAdapter productsAdapter;
    ArrayList<ProductModel> productsModelList = new ArrayList<>();
    private ArrayList<BannerImageModel> bannerImageModelList = new ArrayList<>();
    int noOfItems;
    TextView textNoOfItemsInCart;
    private static ViewPager mPager;
    private static int currentPage = 0;
    private static int NUM_PAGES = 0;
    private CirclePageIndicator indicator;
    private SlidingImageAdapter slidingImageAdapter;
    private TextView testimonialTV;
    private CardView testimonialCV;
    private RecyclerView testmonialRecyclerView;
    private TestimonialAdapter testimonialAdapter;
    private List<TestimonialModel> testimonialModelList = new ArrayList<>();
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_main_board, container, false);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {

        super.onActivityCreated(savedInstanceState);

    }

    @Override
    public void alertOkClicked() {

    }

    @Override
    protected void initViews() {
        userDataSource = new UserDataSource(context);
        recyclerProducts = (RecyclerView) view.findViewById(R.id.recyclerProducts);
        mPager = (ViewPager) view.findViewById(R.id.viewPager);
        indicator = (CirclePageIndicator) view.findViewById(R.id.circleIndicator);
        testimonialCV = view.findViewById(R.id.testimonialCV);
        testimonialTV = view.findViewById(R.id.testimonialTV);
        testmonialRecyclerView = view.findViewById(R.id.recycler_testmonials);
        setTestimonialRecyclerView();
        if (Validator.isNetworkAvailable(currentActivity)) {
            //syncUserWalletTransactionToServer();
            getBannerList();
            getAllProducts();
            setProductRecyclerAdapter();
            getWalletBalance();
            //getTestimonialList();
        } else {
            alert(currentActivity, getString(R.string.alert_message_no_network), getString(R.string.alert_message_no_network), getString(R.string.labelOk), getString(R.string.labelCancel), false,false);
        }
    }

    private void setTestimonialRecyclerView() {
        testimonialAdapter = new TestimonialAdapter(currentActivity, testimonialModelList);
        testmonialRecyclerView.setAdapter(testimonialAdapter);
    }
    @Override
    protected void initContext() {
        currentActivity = getActivity();
        context = getActivity();
    }

    @Override
    protected void initListners() {

    }

    @Override
    public void onClick(View view) {

    }

    private void initRequestModel() {
        RequestModel.getInstance().setDeviceType(DEVICE_TYPE);
        RequestModel.getInstance().setLoginId(SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_MOBILE_NO));
        RequestModel.getInstance().setAccessToken(DeviceUtils.getDeviceKey());
        RequestModel.getInstance().setIpAddress(DeviceUtils.getDeviceIpAddress(context));
    }

    public void getAllProducts() {
        progressDialog(context, context.getString(R.string.pdialog_message_loading), context.getString(R.string.pdialog_message_loading), false, false);
        initRequestModel();
        JSONObject jsons = null;
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        try {
            jsons = new JSONObject(gson.toJson(RequestModel.getInstance()));
            Log.e("jsonGetAllProducts", jsons.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_GET_ALL_PRODUCTS, jsons, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                ((BaseActivity) currentActivity).logTesting("responce is", response.toString(), Log.ERROR);
                try {
                    cancelProgressDialog();
                    ((BaseActivity) currentActivity).logTesting("is successfull fetch Products", "hi" + response.getBoolean(AppConstants.KEY_ERROR), Log.ERROR);
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                        Gson gson = new Gson();
                        List<ProductModel> productsModelListTemp = Arrays.asList(gson.fromJson(response.getJSONArray(MESSAGE).toString(), ProductModel[].class));
                        productsModelList.clear();
                        productsModelList.addAll(productsModelListTemp);
                        productsAdapter.notifyDataSetChanged();

                    } else {
                        cancelProgressDialog();
                        ((BaseActivity) currentActivity).logTesting("fetch products error", "true", Log.ERROR);
                    }


                } catch (JSONException e) {
                    ((BaseActivity) currentActivity).logTesting("fetch products json exception is", e.toString(), Log.ERROR);
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                ((BaseActivity) currentActivity).logTesting("error is", error.toString(), Log.ERROR);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();

                params.put("Content-Type", "application/json");


                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }
    public void getBannerList() {
        JSONObject jsons = null;
        //urlgetbanner
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, URL_GET_BANNERIMG, jsons, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                ((BaseActivity) currentActivity).logTesting("responce is", response.toString(), Log.ERROR);
                try {
                    Gson gson = new Gson();
                    List<BannerImageModel> bannerImageModels = Arrays.asList(gson.fromJson(response.getJSONArray(RESPONCE_MESSAGE).toString(), BannerImageModel[].class));
                    if (bannerImageModels != null && !bannerImageModels.isEmpty()) {
                        bannerImageModelList.clear();
                        bannerImageModelList.addAll(bannerImageModels);
                        //bannerLL.setVisibility(View.VISIBLE);
                        setSliderImageAdapter();
                    } else {
                        //bannerLL.setVisibility(View.GONE);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                ((BaseActivity) currentActivity).logTesting("error is", error.toString(), Log.ERROR);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();

                params.put("Content-Type", "application/json");


                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }
    private void setProductRecyclerAdapter() {
        productsAdapter = new ProductsAdapter(currentActivity, productsModelList);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(currentActivity, 2);
        recyclerProducts.setLayoutManager(gridLayoutManager);
        recyclerProducts.setAdapter(productsAdapter);
    }


    private void setSliderImageAdapter() {
        slidingImageAdapter = new SlidingImageAdapter(getActivity(), bannerImageModelList);
        mPager.setAdapter(slidingImageAdapter);
        indicator.setViewPager(mPager);
        final float density = getResources().getDisplayMetrics().density;
        indicator.setRadius(5 * density);

        NUM_PAGES = productsModelList.size();
        final Handler handler = new Handler();
        final Runnable Update = new Runnable() {
            public void run() {
                if (currentPage == NUM_PAGES) {
                    currentPage = 0;
                }
                mPager.setCurrentItem(currentPage++, true);
            }
        };
        Timer swipeTimer = new Timer();
        swipeTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(Update);
            }
        }, 3000, 3000);
        indicator.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {

            @Override
            public void onPageSelected(int position) {
                currentPage = position;

            }

            @Override
            public void onPageScrolled(int pos, float arg1, int arg2) {

            }

            @Override
            public void onPageScrollStateChanged(int pos) {

            }
        });

    }

    private void getWalletBalance() {
        initRequestModel();
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        JSONObject jsonGetBalanceRequest = null;
        try {
            jsonGetBalanceRequest = new JSONObject(gson.toJson(RequestModel.getInstance()));
            jsonGetBalanceRequest.put(KEY_USER_ID, SharedPreferenceUtils.getInstance(context).getInteger(USER_ID));
            Log.e("jsonGetBalanceRequest", jsonGetBalanceRequest.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_GET_WALLET_BALANCE, jsonGetBalanceRequest, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                        String message = response.getString(RESPONCE_MESSAGE);
                        JSONObject messageJson = new JSONObject(message);
                        String totalBalance = messageJson.getString(USER_WALLET_BALANCE);
                        SharedPreferenceUtils.getInstance(context).putString(USER_WALLET_BALANCE, totalBalance);
                        ((Dashboard) currentActivity).sideMenuListAdapter.notifyDataSetChanged();
                    } else {
                        ((BaseActivity) currentActivity).logTesting("GETWalletBalance", "true", Log.ERROR);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                ((BaseActivity) currentActivity).logTesting("error is", error.toString(), Log.ERROR);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();

                params.put("Content-Type", "application/json");

                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }

    private void syncUserWalletTransactionToServer() {
        if (userDataSource == null) return;
        List<WalletModel> walletModelList = userDataSource.getUserTransactionList();
        Iterator<WalletModel> iterator = walletModelList.iterator();
        while (iterator.hasNext()) {
            WalletModel walletModel = iterator.next();
            if (walletModel == null) continue;
            walletModel.setImageName("");
            addWalletBalance(walletModel);
        }
    }

    private synchronized void addWalletBalance(final WalletModel walletModel) {

        JSONObject jsonAddBalanceRequest = null;
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();

        try {
            jsonAddBalanceRequest = new JSONObject(gson.toJson(walletModel));
            Log.e("jsonAddBalanceRequest", jsonAddBalanceRequest.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_ADD_WALLET_BALANCE, jsonAddBalanceRequest, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    Log.e("jsonAddBalanceResponse", response.toString());
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                        String message = response.getString(RESPONCE_MESSAGE);
                        JSONObject messageJson = new JSONObject(message);
                        String totalBalance = messageJson.getString("total_balance");
                        SharedPreferenceUtils.getInstance(context).putString(USER_WALLET_BALANCE, totalBalance);
                        String transactionId = messageJson.getString("reference_id");
                        if (userDataSource != null) {
                            boolean result = userDataSource.deleteUserTransaction(transactionId);
                            //((BaseActivity) currentActivity).logTesting("deleteUserTransaction result = ", result + " " + transactionId, Log.ERROR);
                        }
                        if (currentActivity != null) {
                            ((Dashboard) currentActivity).sideMenuListAdapter.notifyDataSetChanged();
                        }

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                ((BaseActivity) currentActivity).logTesting("error is", error.toString(), Log.ERROR);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();

                params.put("Content-Type", "application/json");

                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }

    public void getTestimonialList() {
        JSONObject jsons = null;
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, URL_GET_TESTIMONIAL, jsons, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                ((BaseActivity) currentActivity).logTesting("responce is", response.toString(), Log.ERROR);
                try {
                    Gson gson = new Gson();
                    List<TestimonialModel> testimonialModels = Arrays.asList(gson.fromJson(response.getJSONArray(RESPONCE_MESSAGE).toString(), TestimonialModel[].class));
                    testimonialModelList.clear();
                    testimonialModelList.addAll(testimonialModels);
                    testimonialAdapter.notifyDataSetChanged();
                    if (testimonialModelList.isEmpty()) {
                        testimonialCV.setVisibility(View.GONE);
                    } else {
                        testimonialCV.setVisibility(View.VISIBLE);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                ((BaseActivity) currentActivity).logTesting("error is", error.toString(), Log.ERROR);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();

                params.put("Content-Type", "application/json");


                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }

}
