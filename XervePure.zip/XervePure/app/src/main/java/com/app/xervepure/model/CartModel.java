package com.app.xervepure.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Mayank on 20/08/2016.
 */
public class CartModel implements Parcelable {

    @SerializedName("cart_id")
    private int cartId;
    @SerializedName("product_id")
    private int productId;
    @SerializedName("quantity")
    private int productQuantity;
    @SerializedName("product_price")
    private int productPrice;
    @SerializedName("product_name")
    private String productName;
    @SerializedName("product_actual_quantity")
    private String productPackQuantity;
    @SerializedName("product_image")
    private String productImage;
    @SerializedName("product_type")
    private int productType;

    public CartModel() {

    }

    protected CartModel(Parcel in) {
        cartId = in.readInt();
        productId = in.readInt();
        productQuantity = in.readInt();
        productPrice = in.readInt();
        productName = in.readString();
        productPackQuantity = in.readString();
        productImage = in.readString();
        productType = in.readInt();
    }

    public static final Creator<CartModel> CREATOR = new Creator<CartModel>() {
        @Override
        public CartModel createFromParcel(Parcel in) {
            return new CartModel(in);
        }

        @Override
        public CartModel[] newArray(int size) {
            return new CartModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(cartId);
        dest.writeInt(productId);
        dest.writeInt(productQuantity);
        dest.writeInt(productPrice);
        dest.writeString(productName);
        dest.writeString(productPackQuantity);
        dest.writeString(productImage);
        dest.writeInt(productType);
    }

    public int getCartId() {
        return cartId;
    }

    public void setCartId(int cartId) {
        this.cartId = cartId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getProductQuantity() {
        return productQuantity;
    }

    public void setProductQuantity(int productQuantity) {
        this.productQuantity = productQuantity;
    }

    public int getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(int productPrice) {
        this.productPrice = productPrice;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductPackQuantity() {
        return productPackQuantity;
    }

    public void setProductPackQuantity(String productPackQuantity) {
        this.productPackQuantity = productPackQuantity;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public int getProductType() {
        return productType;
    }

    public void setProductType(int productType) {
        this.productType = productType;
    }
}
