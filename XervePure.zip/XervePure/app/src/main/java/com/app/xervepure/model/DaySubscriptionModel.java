package com.app.xervepure.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Codeslay-03 on 9/22/2017.
 */

public class DaySubscriptionModel implements Parcelable {

    private String day;
    private String quantity;

    public DaySubscriptionModel() {

    }

    protected DaySubscriptionModel(Parcel in) {
        day = in.readString();
        quantity = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(day);
        dest.writeString(quantity);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<DaySubscriptionModel> CREATOR = new Creator<DaySubscriptionModel>() {
        @Override
        public DaySubscriptionModel createFromParcel(Parcel in) {
            return new DaySubscriptionModel(in);
        }

        @Override
        public DaySubscriptionModel[] newArray(int size) {
            return new DaySubscriptionModel[size];
        }
    };

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }
}
