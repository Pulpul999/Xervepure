package com.app.xervepure.activity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.app.xervepure.fragments.AboutUsFragment;
import com.app.xervepure.fragments.CalendarFragment;
import com.app.xervepure.fragments.ContsctUsFragment;
import com.app.xervepure.fragments.FeedbackFragment;
import com.app.xervepure.fragments.OrderHistoryFragment;
import com.app.xervepure.fragments.PrivacyPolicyFragment;
import com.app.xervepure.fragments.ReferEarnFragment;
import com.app.xervepure.fragments.SubscriptionFragment;
import com.app.xervepure.fragments.TermsAndServicesFragment;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.app.xervepure.R;
import com.app.xervepure.adapter.SideMenuListAdapter;
import com.app.xervepure.application.VyaanApplication;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.fragments.BaseFragment;
import com.app.xervepure.fragments.MainBoard;
import com.app.xervepure.fragments.WalletFragment;
import com.app.xervepure.model.RequestModel;
import com.app.xervepure.utils.DeviceUtils;
import com.app.xervepure.utils.FontUtils;
import com.app.xervepure.utils.SharedPreferenceUtils;
import com.app.xervepure.widgets.CircularImageView;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Dashboard extends BaseActivity {


    DrawerLayout drawerLayout;
    LinearLayout fragmentContainerWithToolbar;
    FrameLayout fragmentContainer;

    TextView textUserName;
    TextView textMobileNumber;
    RecyclerView recyclerNavigationDrawer;
    ActionBarDrawerToggle actionBarDrawerToggle;

    boolean isExitable;

    String tag;

    BaseFragment frag;

    public SideMenuListAdapter sideMenuListAdapter;
    LinearLayoutManager managerSideMenu;

    int fragmentType = 0;

    Fragment chatFragment;


    CircularImageView circleImageDrawerProfile;

    String userProfileUrl;


    LinearLayout containerImage;
    TextView textNoOfItemsInCart;
    int noOfItems;

    @Override
    protected void initViews() {

        toolbar = (Toolbar) findViewById(R.id.toolbars);
        setSupportActionBar(toolbar);
        applyFontForToolbarTitle();
        drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        fragmentContainerWithToolbar = (LinearLayout) findViewById(R.id.fragmentContainerWithToolbar);
        fragmentContainer = (FrameLayout) findViewById(R.id.fragmentContainer);
        //circleImageDrawerProfile = (CircularImageView) findViewById(R.id.circleImageDrawerProfile);
        textUserName = (TextView) findViewById(R.id.textUserName);
        textMobileNumber = (TextView) findViewById(R.id.textMobileNumber);
        recyclerNavigationDrawer = (RecyclerView) findViewById(R.id.recyclerNavigationDrawer);
        containerImage = (LinearLayout) findViewById(R.id.containerImage);

        containerImage.setOnClickListener(this);

        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar,
                R.string.app_name, R.string.app_name) {

            @Override
            public boolean onOptionsItemSelected(MenuItem item) {
                drawerLayout.openDrawer(Gravity.LEFT);

                return true;
            }

            @Override
            public void onDrawerOpened(View drawerView) {

                super.onDrawerOpened(drawerView);
                toHideKeyboard();

            }

            @Override
            public void onDrawerStateChanged(int newState) {

                super.onDrawerStateChanged(newState);
                if (newState == DrawerLayout.STATE_DRAGGING) {
                    toHideKeyboard();

                }
            }

        };
        actionBarDrawerToggle.syncState();
        drawerLayout.setDrawerListener(actionBarDrawerToggle);

        actionBarDrawerToggle.setToolbarNavigationClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
                actionBarDrawerToggle.setDrawerIndicatorEnabled(true);
            }
        });
        sideMenuListAdapter = new SideMenuListAdapter(currentActivity);
        managerSideMenu = new LinearLayoutManager(currentActivity);

        recyclerNavigationDrawer.setLayoutManager(managerSideMenu);
        recyclerNavigationDrawer.setAdapter(sideMenuListAdapter);

        if (getIntent().getExtras() != null) {
            boolean isCart = getIntent().getExtras().getBoolean(KEY_IS_CART);
            if (isCart) {
                fragmentType = 1;
            }
        }
        setSelection(fragmentType);

    }

    @Override
    protected void initContext() {
        currentActivity = Dashboard.this;
        context = Dashboard.this;
    }

    @Override
    protected void initListners() {

    }

    @Override
    protected boolean isActionBar() {
        return false;
    }

    @Override
    protected boolean isHomeButton() {
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard2);
    }

    @Override
    public void onAlertClicked(int alertType) {
        if (alertType == ALERT_TYPE_LOGOUT) {
            logout();
        }
    }


    public void logout() {
        SharedPreferenceUtils.getInstance(context).clearALl();
        startActivity(currentActivity, LoginActivity.class, bundle, false, REQUEST_TAG_NO_RESULT, true, ANIMATION_SLIDE_LEFT);
        finish();

    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.containerImage: {
                startActivity(currentActivity, ProfileActivity.class, bundle, true, REQUEST_TAG_EDIT_PROFILE_ACTIVITY, true, ANIMATION_SLIDE_LEFT);
            }
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        itemsInCart();
        displayProfile();
    }

    private void displayProfile() {
        String userName = SharedPreferenceUtils.getInstance(context).getString(USER_NAME);
        String userImage = SharedPreferenceUtils.getInstance(context).getString(USER_PROFILE_IMAGE);
        if (!TextUtils.isEmpty(userName)) {
            textUserName.setText(userName);
        }
        textMobileNumber.setText(SharedPreferenceUtils.getInstance(context).getString(USER_MOBILE_NO));
        if (!TextUtils.isEmpty(userImage)) {
            String imageUrl = BASE_URL_IMAGES + "/" + userImage;
            //Picasso.with(currentActivity).load(imageUrl).placeholder(R.drawable.iconprofile).error(R.drawable.iconprofile).into(circleImageDrawerProfile);
        }
        FontUtils.changeFont(this, textUserName, FONT_ROBOTO_MEDIUM);
        FontUtils.changeFont(this, textMobileNumber, FONT_ROBOTO_MEDIUM);
    }

    public void setSelection(int position) {
        fragmentType = position;
        drawerLayout.closeDrawer(Gravity.LEFT);


        frag = null;
        boolean isAddedBackStack = false;

        boolean isReplace = false;

        switch (position) {

            case HOME: {
                frag = new MainBoard();
                settingTitle(getResources().getString(R.string.title_main_board));
                removingHomeButton();
                isAddedBackStack = true;
                break;
            }
            case DASHBOARD: {
                frag = new CalendarFragment();
                settingTitle(getResources().getString(R.string.title_user_dashboard));
                removingHomeButton();
                isAddedBackStack = true;
                break;
            }

            case WALLET: {
                frag = new WalletFragment();
                settingTitle(getResources().getString(R.string.title_wallet));
                removingHomeButton();
                isAddedBackStack = true;
                break;
            }

            case ORDER_HISTORY: {
                frag = new OrderHistoryFragment();
                settingTitle(getResources().getString(R.string.title_view_orders));
                removingHomeButton();
                isAddedBackStack = true;
                break;
            }

            case KEY_SUBSCRIPTION: {
                frag = new SubscriptionFragment();
                settingTitle(getResources().getString(R.string.title_my_plans));
                removingHomeButton();
                isAddedBackStack = true;
                break;
            }
            case HOLD_SUBSCRIPTION: {
                bundle = new Bundle();
                frag = new SubscriptionFragment();
                settingTitle("Hold Delivery");
                removingHomeButton();
                isAddedBackStack = true;
                break;
            }
            case REFFER_EARN: {
                frag = new ReferEarnFragment();
                settingTitle(getResources().getString(R.string.title_refer_earn));
                removingHomeButton();
                isAddedBackStack = true;
                break;
            }
            case FEEDBACK: {
                frag = new FeedbackFragment();
                settingTitle(getResources().getString(R.string.title_feedback));
                removingHomeButton();
                isAddedBackStack = true;
                break;
            }

            case ABOUT_US: {
                frag = new AboutUsFragment();
                settingTitle(getResources().getString(R.string.title_about_us));
                removingHomeButton();
                isAddedBackStack = true;
                break;
            }
            case CONTACT_US: {
                frag = new ContsctUsFragment();
                settingTitle(getResources().getString(R.string.title_contact_us));
                removingHomeButton();
                isAddedBackStack = true;
                break;
            }
            case TERMS_AND_SERVICES: {
                frag = new TermsAndServicesFragment();
                settingTitle(getResources().getString(R.string.title_terms));
                removingHomeButton();
                isAddedBackStack = true;
                break;
            }
            case PRIVACY_POLICY: {
                frag = new PrivacyPolicyFragment();
                settingTitle(getResources().getString(R.string.title_privacy));
                removingHomeButton();
                isAddedBackStack = true;
                break;
            }
            case LOGOUT: {
                alert(currentActivity, getResources().getString(R.string.alert_title_logout), getResources().getString(R.string.alert_message_logout), getResources().getString(R.string.alert_ok_button_text_no_network), getResources().getString(R.string.alert_cancel_button_text_no_network), true, true, ALERT_TYPE_LOGOUT);

                break;
            }


        }

        if (frag != null) {
            switchContent(frag, false, isReplace, frag.getClass().getName());
        }
    }


    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        actionBarDrawerToggle.syncState();
        super.onPostCreate(savedInstanceState);

    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        actionBarDrawerToggle.onConfigurationChanged(newConfig);
        super.onConfigurationChanged(newConfig);

    }

    @Override
    public void onBackPressed() {

        if (isExitable) {
            super.onBackPressed();
        } else {
            toast(getResources().getString(R.string.message_app_exit), true);
            isExitable = true;


            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    isExitable = false;
                }
            }, APP_EXIT_TIME);
        }


    }


    //On click event for rate this app button
    public void btnRateAppOnClick() {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        //Try Google play
        intent.setData(Uri.parse("market://details?id=com.neon.vyan"));
        if (!MyStartActivity(intent)) {
            //Market (Google play) app seems not installed, let's try to open a webbrowser
            intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=com.neon.vyan"));
            if (!MyStartActivity(intent)) {
                //Well if this also fails, we have run out of options, inform the user.
                Toast.makeText(this, "Could not open Android market, please install the market app.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private boolean MyStartActivity(Intent aIntent) {
        try {
            startActivity(aIntent);
            return true;
        } catch (ActivityNotFoundException e) {
            return false;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.item_dashboard, menu);
        View menuView = menu.findItem(R.id.action_cart).getActionView();
        textNoOfItemsInCart = (TextView) menuView.findViewById(R.id.textNoOfItemsInCart);
        noOfItems = SharedPreferenceUtils.getInstance(context).getInteger(CART_ITEM_COUNT);
        if (noOfItems == 0) {
            textNoOfItemsInCart.setText("");
        } else {
            textNoOfItemsInCart.setText("" + String.valueOf(noOfItems));

        }

        final MenuItem filterMenuItem = menu.findItem(R.id.action_cart);
        filterMenuItem.getActionView().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dashboard.this.onOptionsItemSelected(filterMenuItem);
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Log.e("cart click ", "yes");
        switch (item.getItemId()) {
            case R.id.action_cart: {
                Log.e("cart click ", "yes");
                startActivity(currentActivity, CartActivity.class, bundle, false, REQUEST_TAG_NO_RESULT, true, ANIMATION_SLIDE_LEFT);
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    private void initRequestModel() {
        RequestModel.getInstance().setDeviceType(DEVICE_TYPE);
        RequestModel.getInstance().setLoginId(SharedPreferenceUtils.getInstance(context).getString(AppConstants.USER_MOBILE_NO));
        RequestModel.getInstance().setAccessToken(DeviceUtils.getDeviceKey());
        RequestModel.getInstance().setIpAddress(DeviceUtils.getDeviceIpAddress(context));
    }

    public void itemsInCart() {

        int userId = SharedPreferenceUtils.getInstance(currentActivity).getInteger(AppConstants.USER_ID);
        JSONObject jsons = null;
        initRequestModel();
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        try {
            jsons = new JSONObject(gson.toJson(RequestModel.getInstance()));
            jsons.put("user_id", userId);
            Log.e("jsonItemsInCart", jsons.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_NO_OF_ITEMS_IN_CART, jsons, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                ((BaseActivity) currentActivity).logTesting("items in cart responce is", response.toString(), Log.ERROR);

                try {

                    ((BaseActivity) currentActivity).logTesting("is successfull fetch items in cart", "hi" + response.getBoolean(AppConstants.KEY_ERROR), Log.ERROR);
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {
                        JSONObject messageJson = response.getJSONObject(RESPONCE_MESSAGE);
                        noOfItems = messageJson.getInt(CART_ITEM_COUNT);
                        ((BaseActivity) currentActivity).invalidateOptionsMenu();

                        if (textNoOfItemsInCart != null) {
                            textNoOfItemsInCart.setText("" + String.valueOf(noOfItems));
                            if (noOfItems == 0) {
                                textNoOfItemsInCart.setText("");
                            } else {
                                textNoOfItemsInCart.setText("" + String.valueOf(noOfItems));

                            }
                            textNoOfItemsInCart.refreshDrawableState();
                            SharedPreferenceUtils.getInstance(context).putInteger(CART_ITEM_COUNT, noOfItems);
                        }
                    } else {

                        textNoOfItemsInCart.setText("");
                        ((BaseActivity) currentActivity).logTesting("fetch items in cart error", "true", Log.ERROR);
                    }


                } catch (JSONException e) {

                    ((BaseActivity) currentActivity).logTesting("fetch items in cart json exeption is", e.toString(), Log.ERROR);
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                ((BaseActivity) currentActivity).logTesting("error is", error.toString(), Log.ERROR);
                //((BaseActivity) currentActivity).toast(getResources().getString(R.string.errorCartItems), true);

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();

                params.put("Content-Type", "application/json");


                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }

    public void myPlans() {
        //   ((MyPlans) frag).myPlans();
        // setSelection(3);

        //  super.onBackPressed();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        sideMenuListAdapter.notifyDataSetChanged();
        if (requestCode == REQUEST_TAG_MY_PLANS) {
            if (resultCode == RESULT_OK) {
                myPlans();
            }
        } else if (requestCode == REQUEST_TAG_PAYU_PAYMENT_ACTIVITY && resultCode == RESULT_OK) {
            if (frag != null) {
                frag.onActivityResult(requestCode, resultCode, data);
            }
        } else if (requestCode == REQUEST_TAG_PAYTM_PAYMENT_ACTIVITY && resultCode == RESULT_OK) {
            if (frag != null) {
                frag.onActivityResult(requestCode, resultCode, data);
            }
        } else if (requestCode == REQUEST_TAG_CHEQUE_PAYMENT_ACTIVITY && resultCode == RESULT_OK) {
            if (frag != null) {
                frag.onActivityResult(requestCode, resultCode, data);
            }
        } else if (requestCode == REQUEST_TAG_EDIT_PROFILE_ACTIVITY) {
            //displayProfile();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
