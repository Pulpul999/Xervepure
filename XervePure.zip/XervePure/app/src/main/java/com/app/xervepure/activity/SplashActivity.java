package com.app.xervepure.activity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.app.xervepure.R;
import com.app.xervepure.application.VyaanApplication;
import com.app.xervepure.constants.AppConstants;
import com.app.xervepure.utils.SharedPreferenceUtils;
import com.app.xervepure.utils.Validator;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class SplashActivity extends BaseActivity {

    @Override
    protected void initViews() {
        //updateGcmToken();
    }

    @Override
    protected void initContext() {
        currentActivity = SplashActivity.this;
        context = SplashActivity.this;
    }

    @Override
    protected void initListners() {

    }

    @Override
    protected boolean isActionBar() {
        return false;
    }

    @Override
    protected boolean isHomeButton() {
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                /*if (Build.VERSION.SDK_INT >= 23) {

                    if (!checkReceiveSmsPermission()) {
                        requestPermission();
                    } else {
                        moveToNextActivity();
                    }
                } else {
                    moveToNextActivity();
                }*/
                moveToNextActivity();
            }
        }, SPLASH_TIME);

    }

    @Override
    public void onAlertClicked(int alertType) {

    }

    @Override
    public void onClick(View view) {

    }


    public void updateGcmToken() {


        JSONObject jsons = null;
        try {
            jsons = new JSONObject();
            jsons.put("phone", "9736762838");
            jsons.put("password", "ankit");

            logTesting("updateGcmTokenjson", jsons.toString(), Log.ERROR);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        String url = "https://clicsha.com/clicsha_api/v1/index.php/loginUser";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, jsons, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                logTesting("responce is", response.toString(), Log.ERROR);

                try {
                    logTesting("is successfull update gcm token", "hi" + response.getBoolean(AppConstants.KEY_ERROR), Log.ERROR);
                    if (!response.getBoolean(AppConstants.KEY_ERROR)) {


                    } else {

                        logTesting("gcm token update error", "true", Log.ERROR);
                    }


                } catch (JSONException e) {
                    logTesting("gcm token json exeption is", e.toString(), Log.ERROR);
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                cancelProgressDialog();
                logTesting("error is", error.toString(), Log.ERROR);
                toast(getResources().getString(R.string.errorUpdateGcm), true);

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();

                params.put("Content-Type", "application/json");

                return params;
            }
        };

        VyaanApplication.getInstance().addToRequestQueue(request);
    }

    private boolean checkReceiveSmsPermission() {
        int result = ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS);
        if (result == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }

    private void moveToNextActivity() {
        if (Validator.isNetworkAvailable(currentActivity)) {
            boolean isUserLogin = SharedPreferenceUtils.getInstance(context).getBoolean(AppConstants.IS_USER_LOGIN);
            if (isUserLogin) {
                startActivity(currentActivity, Dashboard.class, bundle, false, REQUEST_TAG_NO_RESULT, true, ANIMATION_SLIDE_UP);
                finish();
            } else {
                startActivity(currentActivity, LoginActivity.class, bundle, false, REQUEST_TAG_NO_RESULT, true, ANIMATION_SLIDE_UP);
                finish();
            }
        } else {
            alert(currentActivity, getString(R.string.alert_message_no_network), getString(R.string.alert_message_no_network), getString(R.string.labelOk), getString(R.string.labelCancel), false, false, ALERT_TYPE_NO_NETWORK);

        }
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.RECEIVE_SMS, Manifest.permission.CAMERA}, RECEIVE_SMS_PERMISSION_REQUEST);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case RECEIVE_SMS_PERMISSION_REQUEST:
                moveToNextActivity();
                break;
        }
    }

}
